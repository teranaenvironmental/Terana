/* ============================================================
   Terana Hub. Plain JS single-page app. Data lives in the shared
   Google Sheet, reached through the same Apps Script Web App the
   field tools post to. Reads are cached on the device so the hub
   can still be looked at with no signal; writes need a connection.
   ============================================================ */
const CONFIG = {
  appsScriptUrl: "https://script.google.com/macros/s/AKfycbzRbG5p-D2OyDnUwLYNplcby7UUC2Pagl7B82gxtWMkI3eHl0_0UVmx9ZSDAG8M2vI3-g/exec",
  services: ["Fox den detection", "Pest management plan", "Fox control", "Rabbit control", "Feral cat control", "Feral deer control",
    "Feral pig control", "Bird management", "Native fauna management", "Habitat creation", "Monitoring", "Field necropsy",
    "GIS and mapping", "Snake removal", "Bee removal", "Local government program", "Other"],
  statuses: ["Enquiry", "Quoted", "Scheduled", "In Progress", "Completed", "Invoiced", "Cancelled"],
  activeStatuses: ["Scheduled", "In Progress"],
  priorities: ["Normal", "High", "Urgent"],
  clientTypes: ["Primary producer", "Agricultural supply chain", "Industrial or commercial", "Mine site", "Local government", "Land manager", "Residential", "Other"],
  mapCentre: [-31.95, 115.86], mapZoom: 9,
  cacheKey: "teranaHubCache", tokenKey: "teranaHubToken", userKey: "teranaHubUser"
};
const STATUS_COLOUR = { "Enquiry": "#6B6B6B", "Quoted": "#B26A00", "Scheduled": "#1565C0", "In Progress": "#C1440E", "Completed": "#2E7D32", "Invoiced": "#000", "Cancelled": "#9E9E9E" };

const state = { token: null, user: null, clients: [], jobs: [], reports: [], permissions: [], agreements: [], documents: [], technicians: [], activity: [], loadedAt: null, fromCache: false };
let bigMap = null, miniMap = null, miniMarker = null;

/* ---------- helpers ---------- */
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
function todayISO() { const d = new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
function addDays(iso, n) { const d = new Date(iso + "T00:00:00"); d.setDate(d.getDate() + n); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
function fmtDate(iso) {
  if (!iso) return "";
  const s = String(iso).slice(0, 10); const d = new Date(s + "T00:00:00");
  if (isNaN(d)) return String(iso);
  return d.toLocaleDateString("en-AU", { day: "numeric", month: "short", year: d.getFullYear() === new Date().getFullYear() ? undefined : "numeric" });
}
function fmtWhen(v) {
  if (!v) return ""; const d = new Date(v); if (isNaN(d)) return String(v);
  return d.toLocaleDateString("en-AU", { day: "numeric", month: "short" }) + " " + d.toLocaleTimeString("en-AU", { hour: "2-digit", minute: "2-digit" });
}
function money(v) { const n = Number(v); return v === "" || v == null || isNaN(n) ? "" : n.toLocaleString("en-AU", { style: "currency", currency: "AUD", maximumFractionDigits: 0 }); }
function toast(msg, err) { const t = $("#toast"); t.textContent = msg; t.className = "toast" + (err ? " err" : ""); t.hidden = false; clearTimeout(toast._t); toast._t = setTimeout(() => t.hidden = true, err ? 5000 : 2600); }
// Only ever link to a real https URL, in a new tab. An empty or relative href would navigate the app itself and strand the user.
function extLink(url, label, cls) { url = String(url || ""); return /^https?:\/\//.test(url) ? `<a class="${cls || "btn btn-sm"}" href="${esc(url)}" target="_blank" rel="noopener">${label}</a>` : `<span class="small muted">No PDF yet</span>`; }
// "Tidy wording" button beside a textarea: sends the text to Claude via the script and offers the result to accept or keep.
let _tidyOn = null;
async function tidyAvailable() { if (_tidyOn === null) { try { _tidyOn = !!(await api("tidyAvailable")).on; } catch (e) { _tidyOn = false; } } return _tidyOn; }
function tidyBtn(targetId, kind, section, service) { return `<button type="button" class="btn btn-sm btn-quiet tidy" data-tidy="${targetId}" data-kind="${esc(kind || "")}" data-section="${esc(section || "")}" data-service="${esc(service || "")}" hidden>Tidy wording</button>`; }
async function wireTidy(root) {
  const btns = [...(root || document).querySelectorAll("[data-tidy]")]; if (!btns.length) return;
  if (!(await tidyAvailable())) return;
  btns.forEach(b => { b.hidden = false; b.addEventListener("click", async () => {
    const ta = document.getElementById(b.dataset.tidy); if (!ta || !ta.value.trim()) { toast("Nothing to tidy yet.", true); return; }
    const before = ta.value; b.disabled = true; b.textContent = "Tidying";
    try { const out = await api("tidyText", { text: before, kind: b.dataset.kind, section: b.dataset.section, service: b.dataset.service }); ta.value = out.text; ta.dispatchEvent(new Event("input")); ta.dispatchEvent(new Event("change"));
      const undo = document.createElement("button"); undo.type = "button"; undo.className = "btn btn-sm btn-quiet"; undo.textContent = "Undo tidy"; undo.addEventListener("click", () => { ta.value = before; ta.dispatchEvent(new Event("input")); undo.remove(); }); b.after(undo); toast("Tidied. Read it over.");
    } catch (err) { toast(err.message, true); } finally { b.disabled = false; b.textContent = "Tidy wording"; }
  }); });
}
function pill(s) { return `<span class="pill" data-s="${esc(s)}">${esc(s || "Enquiry")}</span>`; }
function parseJson(v, fallback) { try { const o = JSON.parse(v || ""); return o == null ? fallback : o; } catch (e) { return fallback; } }
function stageStatusList() { return ["Planned", "Booked", "Done", "Skipped"]; }
/* Address suggestions as you type. Uses the free Photon service (OpenStreetMap
   data) biased to Perth. A Google Places key can be dropped in later. */
let _sugT = null;
function attachAddressSuggest(input, onPick) {
  const box = document.createElement("div"); box.className = "suggest"; box.hidden = true;
  input.parentNode.appendChild(box);
  const close = () => { box.hidden = true; box.innerHTML = ""; };
  input.addEventListener("input", () => {
    clearTimeout(_sugT);
    const q = input.value.trim();
    if (q.length < 3) { close(); return; }
    _sugT = setTimeout(async () => {
      try {
        const r = await fetch("https://photon.komoot.io/api/?limit=6&lang=en&lat=" + CONFIG.mapCentre[0] + "&lon=" + CONFIG.mapCentre[1] + "&q=" + encodeURIComponent(q));
        const data = await r.json();
        const items = (data.features || []).filter(f => (f.properties.countrycode || "").toUpperCase() === "AU").map(f => {
          const p = f.properties;
          const line1 = [p.housenumber, p.street || (p.name !== p.city ? p.name : "")].filter(Boolean).join(" ");
          const line2 = [p.city || p.town || p.village || p.county, p.state, p.postcode].filter(Boolean).join(" ");
          const ST = { "Western Australia": "WA", "New South Wales": "NSW", "Victoria": "VIC", "Queensland": "QLD", "South Australia": "SA", "Tasmania": "TAS", "Northern Territory": "NT", "Australian Capital Territory": "ACT" };
          return { label: [line1, line2].filter(Boolean).join(", "), lat: f.geometry.coordinates[1], lng: f.geometry.coordinates[0], street: line1, city: p.city || p.town || p.village || p.county || "", state: ST[p.state] || p.state || "", postcode: p.postcode || "" };
        }).filter(x => x.label);
        if (!items.length) { close(); return; }
        box.innerHTML = items.map((it, i) => `<button type="button" data-i="${i}">${esc(it.label)}</button>`).join("");
        box.hidden = false;
        box.querySelectorAll("button").forEach(b => b.addEventListener("click", () => { const it = items[Number(b.dataset.i)]; input.value = it.label; close(); onPick(it); }));
      } catch (e) { close(); }
    }, 350);
  });
  input.addEventListener("blur", () => setTimeout(close, 200));
}
/* ---------- map exports: KML (Google Earth, Garmin) and GPX (handheld GPS) ---------- */
function safeFile(x) { return String(x || "").replace(/[\\/:*?"<>|]/g, "").trim().slice(0, 80); }
function downloadText(name, text, type) {
  const blob = new Blob([text], { type: type || "text/plain" }); const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 2000);
}
function kmlFor(title, areas, excl, points) {
  const ring = pts => { const p = pts.map(q => q[1] + "," + q[0] + ",0"); if (p.length && p[0] !== p[p.length - 1]) p.push(p[0]); return p.join(" "); };
  const poly = (a, i, kind) => `<Placemark><name>${esc(a.name || (kind === "excl" ? "Exclusion " : "Permitted ") + (i + 1))}</name><styleUrl>#${kind}</styleUrl><Polygon><outerBoundaryIs><LinearRing><coordinates>${ring(a.points || [])}</coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>`;
  const pt = (p, i) => `<Placemark><name>${esc(p.name || "Point " + (i + 1))}</name>${p.notes ? `<description>${esc(p.notes)}</description>` : ""}<styleUrl>#pt</styleUrl><Point><coordinates>${p.lng},${p.lat},0</coordinates></Point></Placemark>`;
  return `<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>${esc(title)}</name>
<Style id="area"><LineStyle><color>ff32b23c</color><width>3</width></LineStyle><PolyStyle><color>5532b23c</color></PolyStyle></Style>
<Style id="excl"><LineStyle><color>ff1e26b3</color><width>3</width></LineStyle><PolyStyle><color>551e26b3</color></PolyStyle></Style>
<Style id="pt"><IconStyle><scale>1.1</scale><Icon><href>http://maps.google.com/mapfiles/kml/paddle/orange-circle.png</href></Icon></IconStyle></Style>
<Folder><name>Permitted areas</name>${areas.map((a, i) => poly(a, i, "area")).join("")}</Folder>
<Folder><name>Exclusion zones</name>${excl.map((a, i) => poly(a, i, "excl")).join("")}</Folder>
<Folder><name>Points</name>${points.map(pt).join("")}</Folder></Document></kml>`;
}
function gpxFor(title, areas, excl, points) {
  const trk = (a, i, kind) => { const pts = (a.points || []).slice(); if (pts.length && (pts[0][0] !== pts[pts.length - 1][0] || pts[0][1] !== pts[pts.length - 1][1])) pts.push(pts[0]); return `<trk><name>${esc((kind === "excl" ? "EXCL " : "OK ") + (a.name || (i + 1)))}</name><trkseg>${pts.map(q => `<trkpt lat="${q[0]}" lon="${q[1]}"></trkpt>`).join("")}</trkseg></trk>`; };
  const wpt = (p, i) => `<wpt lat="${p.lat}" lon="${p.lng}"><name>${esc(p.name || "Point " + (i + 1))}</name>${p.notes ? `<desc>${esc(p.notes)}</desc>` : ""}</wpt>`;
  return `<?xml version="1.0" encoding="UTF-8"?><gpx version="1.1" creator="Terana Hub" xmlns="http://www.topografix.com/GPX/1/1"><metadata><name>${esc(title)}</name></metadata>${points.map(wpt).join("")}${areas.map((a, i) => trk(a, i, "area")).join("")}${excl.map((a, i) => trk(a, i, "excl")).join("")}</gpx>`;
}
function exportButtons(id) { return `<span class="btnrow"><button type="button" class="btn btn-sm btn-quiet" data-export="kml" data-for="${id}">Download KML</button><button type="button" class="btn btn-sm btn-quiet" data-export="gpx" data-for="${id}">Download GPX</button></span>`; }
function dirLink(j, label) {
  const hasPin = j["Latitude"] !== "" && j["Latitude"] != null && !isNaN(Number(j["Latitude"]));
  const dest = hasPin ? Number(j["Latitude"]) + "," + Number(j["Longitude"]) : (j["Site Address"] || "");
  if (!dest) return "";
  return `<a class="dir" href="https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(dest)}" target="_blank" rel="noopener" title="Directions in Google Maps">${label || "Directions"}</a>`;
}
function option(list, selected, blank) { return (blank ? `<option value="">${esc(blank)}</option>` : "") + list.map(v => `<option ${v === selected ? "selected" : ""}>${esc(v)}</option>`).join(""); }

/* ---------- api ---------- */
async function api(action, data) {
  const body = Object.assign({ action, token: state.token }, data || {});
  const res = await fetch(CONFIG.appsScriptUrl, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(body) });
  const out = await res.json();
  if (out.status !== "success" && out.status !== "2fa") {
    if (out.code === "auth") { logout(true); throw new Error("Your login has expired. Log in again."); }
    throw new Error(out.message || "Something went wrong.");
  }
  return out;
}

/* ---------- cache ---------- */
function saveCache() {
  try { localStorage.setItem(CONFIG.cacheKey, JSON.stringify({ clients: state.clients, jobs: state.jobs, reports: state.reports, permissions: state.permissions, agreements: state.agreements, documents: state.documents, technicians: state.technicians, activity: state.activity, loadedAt: state.loadedAt })); } catch (e) { }
}
function loadCache() {
  try { const c = JSON.parse(localStorage.getItem(CONFIG.cacheKey) || "null"); if (!c) return false; Object.assign(state, c); state.fromCache = true; return true; } catch (e) { return false; }
}

async function bootstrap() {
  try {
    const out = await api("bootstrap");
    state.clients = out.clients || []; state.jobs = out.jobs || []; state.reports = out.reports || []; state.permissions = out.permissions || []; state.agreements = out.agreements || []; state.documents = out.documents || []; state.technicians = out.technicians || []; state.activity = out.activity || [];
    state.loadedAt = new Date().toISOString(); state.fromCache = false; state.user = out.user;
    saveCache(); showBanner("");
  } catch (err) {
    if (loadCache()) showBanner("No connection. Showing the copy saved " + fmtWhen(state.loadedAt) + ". Changes can't be saved until you're back online.");
    else showBanner("Couldn't load data: " + err.message);
  }
}
function showBanner(msg) { const b = $("#banner"); b.textContent = msg; b.hidden = !msg; }

/* ---------- auth ---------- */
function setLoggedIn(token, user) {
  state.token = token; state.user = user;
  localStorage.setItem(CONFIG.tokenKey, token); localStorage.setItem(CONFIG.userKey, JSON.stringify(user));
  $("#userName").textContent = user.name || user.email;
  $("#loginView").hidden = true; $("#shell").hidden = false;
}
function logout(silent) {
  state.token = null; state.user = null;
  localStorage.removeItem(CONFIG.tokenKey); localStorage.removeItem(CONFIG.userKey);
  // Clear everything cached on this device: client and job lists, field form caches.
  Object.keys(localStorage).forEach(k => { if (/^(terana|pestReport|fieldSurvey|firearmLog)/i.test(k) && !/queue/i.test(k) && k !== "teranaDevice") localStorage.removeItem(k); });
  state.clients = []; state.jobs = []; state.reports = []; state.permissions = []; state.activity = [];
  $("#shell").hidden = true; $("#loginView").hidden = false;
  if (!silent) toast("Logged out");
}
$("#logoutBtn").addEventListener("click", () => { const t = state.token; logout(true); if (t) fetch(CONFIG.appsScriptUrl, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ action: "logout", token: t }) }).catch(() => { }); });

let pending2fa = "";
$("#loginForm").addEventListener("submit", async ev => {
  ev.preventDefault();
  const btn = $("#loginBtn"), errEl = $("#loginError");
  btn.disabled = true; errEl.hidden = true;
  try {
    let out;
    if (pending2fa) {
      out = await api("login2fa", { pending: pending2fa, code: $("#loginCode").value.trim(), trustDevice: $("#trustDevice").checked });
    } else {
      out = await api("login", { email: $("#loginEmail").value, passcode: $("#loginPass").value, deviceToken: localStorage.getItem("teranaDevice") || "" });
      if (out.status === "2fa") { pending2fa = out.pending; $("#twoStepBox").hidden = false; $("#loginCode").value = ""; $("#loginCode").focus(); btn.textContent = "Confirm code"; btn.disabled = false; return; }
    }
    pending2fa = ""; $("#twoStepBox").hidden = true; btn.textContent = "Log in";
    if (out.deviceToken) { try { localStorage.setItem("teranaDevice", out.deviceToken); } catch (e) { } }
    setLoggedIn(out.token, out.user);
    $("#loginPass").value = "";
    await bootstrap();
    if (!location.hash || location.hash === "#/") location.hash = "#/dashboard"; else route();
  } catch (err) { errEl.textContent = err.message; errEl.hidden = false; }
  finally { btn.disabled = false; }
});

/* ---------- router ---------- */
function route() {
  if (!state.token) return;
  const raw = location.hash.replace(/^#\/?/, "") || "dashboard";
  const [path, query] = raw.split("?");
  state.query = new URLSearchParams(query || "");
  const [page, id] = path.split("/");
  document.querySelectorAll("[data-nav]").forEach(a => a.classList.toggle("active", a.dataset.nav === page));
  const top = ["dashboard", "jobs", "clients", "map", "chemicals", "documents", "team", "tools", "planner", "account", "culls", "sms"].includes(page) && !id;
  $("#backBtn").hidden = top;
  const v = $("#view");
  if (page === "dashboard") renderDashboard(v);
  else if (page === "jobs" && id === "new") renderJobForm(v, null);
  else if (page === "jobs" && id && path.split("/")[2] === "report") renderReport(v, id);
  else if (page === "jobs" && id && path.split("/")[2] === "permission") renderPermission(v, id);
  else if (page === "jobs" && id && path.split("/")[2] === "sign") renderSign(v, id, null);
  else if (page === "clients" && id && path.split("/")[2] === "sign") renderSign(v, null, id);
  else if (page === "clients" && id && path.split("/")[2] === "permission") renderPermission(v, null, id);
  else if (page === "chemicals") renderChemicals(v);
  else if (page === "team") renderTeam(v);
  else if (page === "planner") renderPlanner(v);
  else if (page === "account") renderAccount(v);
  else if (page === "culls") renderCulls(v);
  else if (page === "sms" && id) renderSmsDoc(v, id);
  else if (page === "sms") renderSms(v);
  else if (page === "registers" && id) renderRegister(v, id);
  else if (page === "documents") renderDocuments(v);
  else if (page === "jobs" && id) renderJobForm(v, id);
  else if (page === "jobs") renderJobs(v);
  else if (page === "clients" && id === "new") renderClientForm(v, null);
  else if (page === "clients" && id) renderClientForm(v, id);
  else if (page === "clients") renderClients(v);
  else if (page === "map") renderMap(v);
  else if (page === "tools") renderTools(v);
  else { location.hash = "#/dashboard"; return; }
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", route);
// Back: one step up (job form to jobs, report to its job), not browser history, so it always lands somewhere sensible.
$("#backBtn").addEventListener("click", () => {
  const raw = location.hash.replace(/^#\/?/, "").split("?")[0]; const parts = raw.split("/");
  if (parts.length >= 3) location.hash = "#/" + parts[0] + "/" + parts[1];
  else if (parts.length === 2) location.hash = "#/" + parts[0];
  else location.hash = "#/dashboard";
});

/* ---------- dashboard ---------- */
function jobsByClient(id) { return state.jobs.filter(j => j["Client ID"] === id); }
function liveDoc(r) { if (["Void", "Cancelled"].includes(r["Status"])) return false; const to = String(r["Valid To"] || "").slice(0, 10); return !to || to >= todayISO(); }
function standingPermission(clientId) { return (state.permissions || []).find(p => p["Scope"] === "Client" && p["Client ID"] === clientId && p["Status"] === "Signed" && liveDoc(p)) || null; }
function standingAgreements(clientId) { return (state.agreements || []).filter(a => a["Client ID"] === clientId && a["Status"] === "Signed" && liveDoc(a)); }
function permissionHeld(j) { return state.permissions.some(r => r["Job ID"] === j["Job ID"] && r["Status"] === "Signed") || !!standingPermission(j["Client ID"]); }
function clientName(id) { const c = state.clients.find(x => x["Client ID"] === id); return c ? c["Name"] : ""; }

function renderDashboard(v) {
  const today = todayISO(), week = addDays(today, 7), fortnight = addDays(today, 14);
  const live = state.jobs.filter(j => j["Status"] !== "Cancelled");
  const active = live.filter(j => CONFIG.activeStatuses.includes(j["Status"]));
  const awaiting = live.filter(j => ["Enquiry", "Quoted"].includes(j["Status"]));
  const thisWeek = live.filter(j => j["Start Date"] && j["Start Date"] >= today && j["Start Date"] <= week);
  const actions = live.filter(j => j["Next Action"] && j["Next Action Date"] && j["Next Action Date"] <= today && !["Completed", "Invoiced"].includes(j["Status"]));
  const upcoming = [];
  live.forEach(j => {
    const stages = parseJson(j["Stages"], []);
    if (Array.isArray(stages) && stages.length) stages.forEach(st => { if (st.start && st.start >= today && st.start <= fortnight && st.status !== "Done" && st.status !== "Skipped") upcoming.push(Object.assign({}, j, { "Start Date": st.start, "Title": j["Title"] + ": " + (st.name || "stage") })); });
    else if (j["Start Date"] && j["Start Date"] >= today && j["Start Date"] <= fortnight) upcoming.push(j);
  });
  upcoming.sort((a, b) => a["Start Date"].localeCompare(b["Start Date"]));
  const toInvoice = live.filter(j => j["Status"] === "Completed");
  const nextActions = live.filter(j => j["Next Action"] && !["Completed", "Invoiced"].includes(j["Status"])).sort((a, b) => String(a["Next Action Date"] || "9").localeCompare(String(b["Next Action Date"] || "9"))).slice(0, 8);

  v.innerHTML = `
    <div class="page-head"><div><h1>Dashboard</h1><p class="muted">${esc(new Date().toLocaleDateString("en-AU", { weekday: "long", day: "numeric", month: "long" }))}${state.fromCache ? " (saved copy)" : ""}</p></div>
      <div><a class="btn btn-primary" href="#/jobs/new">New job</a></div></div>
    <div class="grid kpis">
      <div class="card kpi"><div class="num">${active.length}</div><div class="lbl">Active jobs</div></div>
      <div class="card kpi"><div class="num">${thisWeek.length}</div><div class="lbl">Starting in the next 7 days</div></div>
      <div class="card kpi ${awaiting.length ? "alert" : ""}"><div class="num">${awaiting.length}</div><div class="lbl">Enquiries and quotes open</div></div>
      <div class="card kpi ${actions.length ? "alert" : ""}"><div class="num">${actions.length}</div><div class="lbl">Actions due</div></div>
    </div>
    <div class="grid cols-2" style="margin-top:16px">
      <div class="card"><div class="card-head"><h2>Coming up (14 days)</h2><a class="btn btn-sm" href="#/planner">Open planner</a></div>${jobList(upcoming, "Start Date")}</div>
      <div class="card"><h2>Next actions</h2>${actionList(nextActions)}${(function () { const due = reviewsDue(30); return due.length ? `<h3 style="margin:1em 0 .3em">Document reviews</h3><ul class="list">${due.map(d => `<li><span class="when">${esc(fmtDate(d["Review Date"]))}</span><div class="what"><a href="#/sms/${esc(d["Doc ID"])}">Review ${esc(d["Title"])}</a></div></li>`).join("")}</ul>` : ""; })()}</div>
      <div class="card"><h2>Completed, not yet invoiced</h2>${jobList(toInvoice, "End Date")}</div>
      <div class="card"><h2>Recent field reports</h2>${activityList(state.activity.slice(0, 10))}</div>
    </div>`;
}
function jobList(jobs, dateKey) {
  if (!jobs.length) return `<p class="empty">Nothing here.</p>`;
  return `<ul class="list">${jobs.map(j => `<li><span class="when">${esc(fmtDate(j[dateKey]))}</span><div class="what"><a href="#/jobs/${esc(j["Job ID"])}">${esc(j["Title"])}</a><div class="sub">${esc(j["Client Name"] || "")}${j["Site Name"] ? ", " + esc(j["Site Name"]) : ""} ${pill(j["Status"])}</div></div></li>`).join("")}</ul>`;
}
function actionList(jobs) {
  if (!jobs.length) return `<p class="empty">No actions recorded.</p>`;
  const today = todayISO();
  return `<ul class="list">${jobs.map(j => `<li><span class="when ${j["Next Action Date"] && j["Next Action Date"] <= today ? "due" : ""}">${esc(fmtDate(j["Next Action Date"]) || "No date")}</span><div class="what"><a href="#/jobs/${esc(j["Job ID"])}">${esc(j["Next Action"])}</a><div class="sub">${esc(j["Title"])}${j["Client Name"] ? ", " + esc(j["Client Name"]) : ""}</div></div></li>`).join("")}</ul>`;
}
function activityList(items) {
  if (!items.length) return `<p class="empty">No field reports yet.</p>`;
  return `<ul class="list">${items.map(a => `<li><span class="when">${esc(fmtWhen(a.when) || fmtDate(a.date))}</span><div class="what"><strong>${esc(a.type)}</strong>${a.where ? ", " + esc(a.where) : ""}<div class="sub">${esc([a.who, a.summary].filter(Boolean).join(": "))}</div></div></li>`).join("")}</ul>`;
}

/* ---------- jobs ---------- */
let jobFilter = { status: "Open", q: "" };
function renderJobs(v) {
  const filters = ["Open", "All"].concat(CONFIG.statuses);
  v.innerHTML = `
    <div class="page-head"><div><h1>Jobs</h1><p class="muted">${state.jobs.length} in total</p></div><div><a class="btn btn-primary" href="#/jobs/new">New job</a></div></div>
    <div class="toolbar"><input type="search" id="jobSearch" placeholder="Search title, client, site" value="${esc(jobFilter.q)}"><div class="chips">${filters.map(f => `<button type="button" class="chip ${jobFilter.status === f ? "on" : ""}" data-f="${esc(f)}">${esc(f)}</button>`).join("")}</div></div>
    <div id="jobTable"></div>`;
  const draw = () => {
    const q = jobFilter.q.toLowerCase();
    let rows = state.jobs.filter(j => {
      if (jobFilter.status === "Open") { if (["Completed", "Invoiced", "Cancelled"].includes(j["Status"])) return false; }
      else if (jobFilter.status !== "All" && j["Status"] !== jobFilter.status) return false;
      if (q && ![j["Title"], j["Client Name"], j["Site Name"], j["Site Address"], j["Service"]].join(" ").toLowerCase().includes(q)) return false;
      return true;
    });
    rows.sort((a, b) => String(a["Start Date"] || "9999").localeCompare(String(b["Start Date"] || "9999")));
    $("#jobTable").innerHTML = rows.length ? `<table class="tbl"><thead><tr><th>Job</th><th>Client</th><th>Status</th><th>Start</th><th class="hide-m">Assigned</th><th class="hide-m">Next action</th><th></th></tr></thead><tbody>
      ${rows.map(j => `<tr class="row" data-id="${esc(j["Job ID"])}"><td><a href="#/jobs/${esc(j["Job ID"])}">${esc(j["Title"])}</a><div class="small muted">${esc(j["Service"] || "")}${j["Site Name"] ? ", " + esc(j["Site Name"]) : ""}</div></td><td>${esc(j["Client Name"] || "")}</td><td>${pill(j["Status"])}</td><td>${esc(fmtDate(j["Start Date"]))}</td><td class="hide-m">${esc(j["Assigned To"] || "")}</td><td class="hide-m">${esc(j["Next Action"] || "")}${j["Next Action Date"] ? `<div class="small muted">${esc(fmtDate(j["Next Action Date"]))}</div>` : ""}</td><td class="right">${dirLink(j, "Go")}</td></tr>`).join("")}
      </tbody></table>` : `<p class="empty">No jobs match.</p>`;
    $("#jobTable").querySelectorAll("tr.row").forEach(tr => tr.addEventListener("click", ev => { if (ev.target.tagName !== "A") location.hash = "#/jobs/" + tr.dataset.id; }));
  };
  $("#jobSearch").addEventListener("input", e => { jobFilter.q = e.target.value; draw(); });
  v.querySelectorAll(".chip").forEach(c => c.addEventListener("click", () => { jobFilter.status = c.dataset.f; v.querySelectorAll(".chip").forEach(x => x.classList.toggle("on", x === c)); draw(); }));
  draw();
}

function renderJobForm(v, id) {
  const j = id ? state.jobs.find(x => x["Job ID"] === id) : null;
  if (id && !j) { v.innerHTML = `<p class="empty">Job not found.</p>`; return; }
  const d = j || { "Status": "Enquiry", "Priority": "Normal", "Start Date": "", "Client ID": state.query.get("client") || "" };
  const techs = state.technicians.map(t => t.name).filter(Boolean);
  v.innerHTML = `
    <div class="page-head"><div><p class="muted small"><a href="#/jobs">Jobs</a> / ${j ? esc(j["Job ID"]) : "New"}</p><h1>${j ? esc(j["Title"]) : "New job"}</h1>${j ? `<p class="muted small">Updated ${esc(fmtWhen(j["Updated"]))} by ${esc(j["Updated By"] || "")}</p>` : ""}</div>
      ${j ? `<div class="head-actions">${pill(j["Status"])} ${dirLink(j)} <a class="btn btn-sm" href="#/jobs/${esc(j["Job ID"])}/report">${state.reports.some(r => r["Job ID"] === j["Job ID"]) ? "Open report" : "Draft report"}</a> <a class="btn btn-sm" href="#/jobs/${esc(j["Job ID"])}/permission">${permissionHeld(j) ? "Firearm use held" : "Firearm use"}</a> <a class="btn btn-sm" href="#/jobs/${esc(j["Job ID"])}/sign">Forms to sign</a></div>
      ${standingAgreements(j["Client ID"]).length || standingPermission(j["Client ID"]) ? `<p class="small muted">Standing with this client: ${standingAgreements(j["Client ID"]).map(a => esc(a["Type"]) + " signed " + esc(fmtDate(a["Signed Date"]))).concat(standingPermission(j["Client ID"]) ? ["firearm use signed " + esc(fmtDate(standingPermission(j["Client ID"])["Signed Date"]))] : []).join(", ")}. <a href="#/clients/${esc(j["Client ID"])}">Client file</a></p>` : ""}` : ""}</div>
    <form id="jobForm" class="form">
      <div class="full"><label for="jTitle">Job title</label><input id="jTitle" required value="${esc(d["Title"] || "")}" placeholder="e.g. Rabbit baiting program, Smith property"></div>
      <div><label for="jClient">Client</label><select id="jClient">${option([], null, "No client yet")}${state.clients.filter(c => c["Status"] !== "Archived").map(c => `<option value="${esc(c["Client ID"])}" ${c["Client ID"] === d["Client ID"] ? "selected" : ""}>${esc(c["Name"])}</option>`).join("")}</select>
        <div class="inline-new" id="newClientRow" style="margin-top:6px"><div><input id="jNewClient" placeholder="Or type a new client name"></div></div></div>
      <div><label for="jService">Service</label><select id="jService">${option(CONFIG.services, d["Service"], "Choose a service")}</select></div>
      <div><label for="jStatus">Status</label><select id="jStatus">${option(CONFIG.statuses, d["Status"])}</select></div>
      <div><label for="jPriority">Priority</label><select id="jPriority">${option(CONFIG.priorities, d["Priority"] || "Normal")}</select></div>
      <div><label for="jStart">Start date</label><input id="jStart" type="date" value="${esc(String(d["Start Date"] || "").slice(0, 10))}"></div>
      <div><label for="jEnd">End date</label><input id="jEnd" type="date" value="${esc(String(d["End Date"] || "").slice(0, 10))}"></div>
      <div><label for="jAssigned">Assigned to</label><input id="jAssigned" list="techList" value="${esc(d["Assigned To"] || "")}"><datalist id="techList">${techs.map(t => `<option value="${esc(t)}">`).join("")}</datalist></div>
      <div><label for="jValue">Quote value ($, ex GST)</label><input id="jValue" type="number" min="0" step="1" value="${esc(d["Quote Value"] ?? "")}"></div>
      <div class="full"><label for="jSiteName">Site name</label><input id="jSiteName" value="${esc(d["Site Name"] || "")}" placeholder="Property or site name"></div>
      <div class="full"><label for="jAddress">Site address</label>
        <div class="locate"><div class="suggest-wrap"><textarea id="jAddress" rows="2" placeholder="Start typing an address and pick a match, or type anything and tap the map">${esc(d["Site Address"] || "")}</textarea></div><div class="locate-btns"><button type="button" class="btn" id="geocodeBtn">Find on map</button><button type="button" class="btn" id="gpsBtn" title="Use this device's location">My location</button></div></div>
        ${id ? `<div class="btnrow" style="margin:6px 0 0"><button type="button" class="btn btn-sm btn-quiet" id="jobKml">Download KML</button><button type="button" class="btn btn-sm btn-quiet" id="jobGpx">Download GPX</button><span class="small muted">Site pin, points of interest and any shooting areas, for Google Earth or a GPS.</span></div>` : ""}
        <div class="minimap" id="miniMap"></div>
        <div class="coords" id="coords">${d["Latitude"] ? `Site pin at ${Number(d["Latitude"]).toFixed(5)}, ${Number(d["Longitude"]).toFixed(5)}. Drag it to adjust.` : "No site pin yet. Pick an address, use your location, or tap the map."}</div>
        <input type="hidden" id="jLat" value="${esc(d["Latitude"] ?? "")}"><input type="hidden" id="jLng" value="${esc(d["Longitude"] ?? "")}">
        <div class="poi-box"><div class="poi-head"><strong>Points of interest</strong> <span class="muted small">Gates, sheds, dens, trap lines. Switch to "Add point" then tap the map.</span></div>
          <div class="chips" style="margin:6px 0"><button type="button" class="chip on" id="modeSite">Move site pin</button><button type="button" class="chip" id="modePoi">Add point</button></div>
          <ul class="list" id="poiList"></ul></div></div>
      <div class="full"><label>Stages</label><p class="muted small" style="margin:0 0 6px">Break the job into booked days or steps, for example night shoot, clean-up, deterrent install, monitoring. Each stage shows on the dashboard when it comes up.</p>
        <div id="stageList"></div><button type="button" class="btn btn-sm" id="addStage">Add stage</button></div>
      ${j ? `<div class="full planning card" id="planCard"><h2 style="margin:0 0 4px">Planning <span id="planBadge"></span></h2><p class="muted small" style="margin:0 0 10px">Fill in once the quote is accepted. Tick items as they are ready. The job is ready to start when every needed document is ticked.</p>
        <h3>Equipment</h3><div id="eqList"></div><button type="button" class="btn btn-sm" id="addEq">Add equipment</button>
        <h3 style="margin-top:14px">Consumables</h3><div id="conList"></div><button type="button" class="btn btn-sm" id="addCon">Add consumable</button>
        <h3 style="margin-top:14px">Documents needed to start</h3><p class="muted small" style="margin:0 0 6px">SWMS and procedures come from the SMS. Shoot plan and site-specific JHA are made per job from the templates.</p><div id="docList"></div><div class="btnrow"><button type="button" class="btn btn-sm" id="addDoc">Add a document</button><select id="addSmsDoc" style="width:auto;display:inline-block;margin:0"><option value="">Add from SMS</option>${(state.documents || []).filter(x => x["Category"] === "SMS").map(x => `<option value="${esc(x["Doc ID"])}">${esc(x["Doc No"] ? x["Doc No"] + " " : "")}${esc(x["Title"])}</option>`).join("")}</select></div>
        <label for="planNotes" style="margin-top:10px">Planning notes</label><textarea id="planNotes" placeholder="Access arrangements, who is coming, timing"></textarea></div>` : ""}
      <div class="full"><label for="jDesc">Description ${tidyBtn("jDesc", "job scope description")}</label><textarea id="jDesc" placeholder="What the client wants, scope, animals, area">${esc(d["Description"] || "")}</textarea></div>
      <div><label for="jNextAction">Next action</label><input id="jNextAction" value="${esc(d["Next Action"] || "")}" placeholder="e.g. Send quote, Call client, Apply for permit"></div>
      <div><label for="jNextDate">Next action date</label><input id="jNextDate" type="date" value="${esc(String(d["Next Action Date"] || "").slice(0, 10))}"></div>
      <div class="full"><label for="jNotes">Notes</label><textarea id="jNotes">${esc(d["Notes"] || "")}</textarea></div>
      <div class="full form-actions">
        <button class="btn btn-primary" type="submit" id="jobSave">${j ? "Save changes" : "Create job"}</button>
        <a class="btn btn-quiet" href="#/jobs">Cancel</a>
        <span class="spacer"></span>
        ${j ? `<button type="button" class="btn btn-danger btn-sm" id="jobDelete">Delete job</button>` : ""}
      </div>
    </form>`;

  // points of interest
  let pois = parseJson(d["POIs"], []); if (!Array.isArray(pois)) pois = [];
  let poiMode = false; const poiMarkers = [];
  const poiIcon = () => L.divIcon({ className: "", html: `<div class="poi-dot"></div>`, iconSize: [12, 12], iconAnchor: [6, 6], popupAnchor: [0, -8] });
  function drawPois() {
    poiMarkers.forEach(m => m.remove()); poiMarkers.length = 0;
    pois.forEach((p, i) => { const m = L.marker([p.lat, p.lng], { icon: poiIcon(), draggable: true }).addTo(miniMap).bindTooltip(p.name || ("Point " + (i + 1)), { permanent: true, direction: "right", offset: [8, 0], className: "poi-label" }); m.on("dragend", () => { const ll = m.getLatLng(); p.lat = ll.lat; p.lng = ll.lng; }); poiMarkers.push(m); });
    $("#poiList").innerHTML = pois.length ? pois.map((p, i) => `<li><div class="what"><input class="poi-name" data-i="${i}" value="${esc(p.name || "")}" placeholder="Name this point"><div class="sub">${Number(p.lat).toFixed(5)}, ${Number(p.lng).toFixed(5)} ${dirLink({ Latitude: p.lat, Longitude: p.lng })}</div></div><button type="button" class="btn btn-quiet btn-sm" data-rm="${i}">Remove</button></li>`).join("") : `<li class="empty">No points yet.</li>`;
    $("#poiList").querySelectorAll(".poi-name").forEach(inp => inp.addEventListener("input", () => { pois[Number(inp.dataset.i)].name = inp.value; poiMarkers[Number(inp.dataset.i)].setTooltipContent(inp.value || "Point"); }));
    $("#poiList").querySelectorAll("[data-rm]").forEach(b => b.addEventListener("click", () => { pois.splice(Number(b.dataset.rm), 1); drawPois(); }));
  }
  $("#modeSite").addEventListener("click", () => { poiMode = false; $("#modeSite").classList.add("on"); $("#modePoi").classList.remove("on"); });
  $("#modePoi").addEventListener("click", () => { poiMode = true; $("#modePoi").classList.add("on"); $("#modeSite").classList.remove("on"); });

  // stages
  let stages = parseJson(d["Stages"], []); if (!Array.isArray(stages)) stages = [];
  function drawStages() {
    $("#stageList").innerHTML = stages.length ? `<table class="tbl stages"><thead><tr><th>Stage</th><th>Start</th><th>End</th><th>Status</th><th></th></tr></thead><tbody>` + stages.map((st, i) => `<tr><td><input data-k="name" data-i="${i}" value="${esc(st.name || "")}" placeholder="e.g. Night shoot"></td><td><input type="date" data-k="start" data-i="${i}" value="${esc(st.start || "")}"></td><td><input type="date" data-k="end" data-i="${i}" value="${esc(st.end || "")}"></td><td><select data-k="status" data-i="${i}">${option(stageStatusList(), st.status || "Planned")}</select></td><td><button type="button" class="btn btn-quiet btn-sm" data-rms="${i}">Remove</button></td></tr>`).join("") + `</tbody></table>` : "";
    $("#stageList").querySelectorAll("[data-k]").forEach(el => el.addEventListener("input", () => { stages[Number(el.dataset.i)][el.dataset.k] = el.value; }));
    $("#stageList").querySelectorAll("[data-rms]").forEach(b => b.addEventListener("click", () => { stages.splice(Number(b.dataset.rms), 1); drawStages(); }));
  }
  $("#addStage").addEventListener("click", () => { const last = stages[stages.length - 1]; stages.push({ name: "", start: last && last.end ? last.end : ($("#jStart").value || ""), end: "", status: "Planned" }); drawStages(); const inputs = $("#stageList").querySelectorAll('input[data-k="name"]'); if (inputs.length) inputs[inputs.length - 1].focus(); });
  drawStages();

  // mini map with draggable pin
  const hasPin = d["Latitude"] !== "" && d["Latitude"] != null && !isNaN(Number(d["Latitude"]));
  miniMap = L.map("miniMap", { scrollWheelZoom: false }).setView(hasPin ? [Number(d["Latitude"]), Number(d["Longitude"])] : CONFIG.mapCentre, hasPin ? 16 : CONFIG.mapZoom);
  const mmSat = satTiles().addTo(miniMap), mmStreet = tiles();
  const mmLabels = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}", { maxZoom: 19 }).addTo(miniMap);
  L.control.layers({ "Aerial": mmSat, "Street": mmStreet }, { "Labels": mmLabels }, { position: "topright" }).addTo(miniMap);
  miniMarker = null;
  const setPin = (lat, lng, zoom) => {
    $("#jLat").value = lat; $("#jLng").value = lng;
    $("#coords").textContent = `Pin at ${Number(lat).toFixed(5)}, ${Number(lng).toFixed(5)}. Drag the pin to adjust.`;
    if (!miniMarker) { miniMarker = L.marker([lat, lng], { draggable: true, icon: pinIcon(d["Status"]) }).addTo(miniMap); miniMarker.on("dragend", () => { const p = miniMarker.getLatLng(); setPin(p.lat, p.lng); }); }
    else miniMarker.setLatLng([lat, lng]);
    if (zoom) miniMap.setView([lat, lng], zoom);
  };
  if (hasPin) setPin(Number(d["Latitude"]), Number(d["Longitude"]));
  miniMap.on("click", e => { if (poiMode) { pois.push({ name: "", lat: e.latlng.lat, lng: e.latlng.lng }); drawPois(); const inputs = $("#poiList").querySelectorAll(".poi-name"); if (inputs.length) inputs[inputs.length - 1].focus(); } else setPin(e.latlng.lat, e.latlng.lng); });
  drawPois();
  if (pois.length && !hasPin) miniMap.fitBounds(L.latLngBounds(pois.map(p => [p.lat, p.lng])).pad(0.3));
  setTimeout(() => miniMap.invalidateSize(), 50);
  attachAddressSuggest($("#jAddress"), it => setPin(it.lat, it.lng, 15)); wireTidy(v);

  $("#geocodeBtn").addEventListener("click", async () => {
    const q = $("#jAddress").value.trim(); if (!q) { toast("Type an address first", true); return; }
    $("#geocodeBtn").disabled = true;
    try {
      const r = await fetch("https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=au&q=" + encodeURIComponent(q), { headers: { "Accept": "application/json" } });
      const hits = await r.json();
      if (!hits.length) { toast("Address not found. Tap the map to place the pin.", true); return; }
      setPin(Number(hits[0].lat), Number(hits[0].lon), 14);
    } catch (e) { toast("Couldn't look up the address. Tap the map to place the pin.", true); }
    finally { $("#geocodeBtn").disabled = false; }
  });
  $("#gpsBtn").addEventListener("click", () => {
    if (!navigator.geolocation) { toast("No GPS on this device", true); return; }
    navigator.geolocation.getCurrentPosition(p => setPin(p.coords.latitude, p.coords.longitude, 15), e => toast("Couldn't get location: " + e.message, true), { enableHighAccuracy: true, timeout: 10000 });
  });
  if ($("#jobKml")) ["kml", "gpx"].forEach(kind => $("#job" + kind.toUpperCase().slice(0, 1) + kind.slice(1)).addEventListener("click", async () => {
    const pts = (parseJson(d["POIs"], []) || []).filter(p => p && p.lat); if (d["Latitude"] !== "" && d["Latitude"] != null) pts.unshift({ name: "Site", lat: Number(d["Latitude"]), lng: Number(d["Longitude"]) });
    let areas = [], excl = [];
    try { const out = await api("getPermission", { jobId: id }); const pm = out.permission || out.standing; if (pm) { areas = parseJson(pm["Permitted Areas"], []) || []; excl = parseJson(pm["Exclusion Areas"], []) || []; } } catch (e) { }
    const name = safeFile((d["Client Name"] || "Terana") + " " + (d["Title"] || id));
    if (kind === "kml") downloadText(name + ".kml", kmlFor(name, areas, excl, pts), "application/vnd.google-earth.kml+xml"); else downloadText(name + ".gpx", gpxFor(name, areas, excl, pts), "application/gpx+xml");
  }));

  // ---- planning card ----
  let plan = parseJson(d["Planning"], null) || { equipment: [], consumables: [], documents: [], notes: "" };
  if (j && !plan.documents.length && !d["Planning"]) {
    const sms = (state.documents || []).filter(x => x["Category"] === "SMS");
    const pick = (re) => sms.find(x => re.test(x["Title"] || ""));
    const svc = String(d["Service"] || "");
    const defaults = [];
    const culling = pick(/ground culling/i), chem = pick(/chemical use/i), dogs = pick(/conservation dogs/i), phyto = pick(/phytophthora/i) ;
    if (/shoot|cull|control|bird|pig|deer|fox|rabbit|cat/i.test(svc) && culling) defaults.push({ name: culling["Title"], docId: culling["Doc ID"], link: culling["Link"], needed: true, ready: false });
    if (/rabbit|fox|bait|pig/i.test(svc) && chem) defaults.push({ name: chem["Title"], docId: chem["Doc ID"], link: chem["Link"], needed: true, ready: false });
    if (/den|detection|survey/i.test(svc) && dogs) defaults.push({ name: dogs["Title"], docId: dogs["Doc ID"], link: dogs["Link"], needed: true, ready: false });
    if (phyto) defaults.push({ name: phyto["Title"], docId: phyto["Doc ID"], link: phyto["Link"], needed: false, ready: false });
    if (/shoot|cull|bird|pig|deer|fox|cat|control/i.test(svc)) defaults.push({ name: "Shoot plan (this job)", template: "TE-WHS-TPL-001", link: "", needed: true, ready: false });
    defaults.push({ name: "Site-specific JHA (this job)", template: "TE-WHS-TPL-002", link: "", needed: true, ready: false });
    defaults.push({ name: "Firearm use permission signed", auto: "permission", link: "", needed: /shoot|cull|bird|pig|deer|fox|cat/i.test(svc), ready: permissionHeld(d) });
    plan.documents = defaults;
  }
  const savePlanOnly = async () => {
    if (!j) return;
    const planning = JSON.stringify({ equipment: plan.equipment.filter(e => e.item), consumables: plan.consumables.filter(c => c.product), documents: plan.documents.filter(x => x.name), notes: ($("#planNotes") ? $("#planNotes").value : plan.notes) || "" });
    const out = await api("saveJob", { job: { "Job ID": j["Job ID"], "Planning": planning } });
    const idx = state.jobs.findIndex(x => x["Job ID"] === j["Job ID"]); if (idx >= 0 && out.job) state.jobs[idx] = out.job; else if (idx >= 0) state.jobs[idx]["Planning"] = planning; d["Planning"] = planning; saveCache();
  };
  const drawPlan = () => {
    if (!$("#planCard")) return;
    $("#eqList").innerHTML = plan.equipment.map((e, i) => `<div class="plrow2"><label class="check" style="margin:0"><input type="checkbox" data-eq="${i}" ${e.done ? "checked" : ""}></label><input class="eqItem" data-eq="${i}" value="${esc(e.item || "")}" placeholder="e.g. Howa .308, thermal, spotlight, traps x6"><button type="button" class="btn btn-sm btn-quiet" data-eqdel="${i}">x</button></div>`).join("");
    const prods = ((state.chem || {}).products || []).map(x => x["Product Name"]);
    $("#conList").innerHTML = plan.consumables.map((c, i) => `<div class="plrow2"><label class="check" style="margin:0"><input type="checkbox" data-con="${i}" ${c.done ? "checked" : ""}></label><input class="conItem" data-con="${i}" list="prodList" value="${esc(c.product || "")}" placeholder="Product or item"><input class="conQty" data-con="${i}" value="${esc(c.qty || "")}" placeholder="Qty" style="max-width:6em"><button type="button" class="btn btn-sm btn-quiet" data-condel="${i}">x</button></div>`).join("") + `<datalist id="prodList">${prods.map(x => `<option value="${esc(x)}">`).join("")}</datalist>`;
    $("#docList").innerHTML = plan.documents.map((x, i) => `<div class="plrow2 docrow"><label class="check" style="margin:0" title="Needed for this job"><input type="checkbox" data-need="${i}" ${x.needed ? "checked" : ""}></label><div class="docname"><input class="docName" data-doc="${i}" value="${esc(x.name || "")}" placeholder="Document">${x.link ? ` <a href="${esc(x.link)}" target="_blank" rel="noopener" class="small">Open</a>` : x.template ? ` <button type="button" class="btn btn-sm btn-quiet" data-mk="${i}">Create from template</button>` : x.auto === "permission" ? ` <a class="small" href="#/jobs/${esc(d["Job ID"])}/permission">Open</a>` : ` <button type="button" class="btn btn-sm btn-quiet" data-link="${i}">Add link</button>`}${x.docId && !x.copy ? ` <button type="button" class="btn btn-sm btn-quiet" data-copy="${i}" title="Make this job's own copy so people can sign it">Job copy</button>` : ""}${x.copy ? ` <span class="small muted">job copy</span> <button type="button" class="btn btn-sm" data-sign="${i}">Sign</button><button type="button" class="btn btn-sm btn-quiet" data-signmail="${i}">Email to sign</button><span class="small muted" data-signed="${i}"></span>` : ""}</div><label class="check ready" style="margin:0" title="Ready"><input type="checkbox" data-ready="${i}" ${x.ready ? "checked" : ""} ${x.auto ? "disabled" : ""}> ready</label><button type="button" class="btn btn-sm btn-quiet" data-docdel="${i}">x</button></div>`).join("");
    $("#planNotes").value = plan.notes || "";
    const need = plan.documents.filter(x => x.needed), ready = need.filter(x => x.ready);
    $("#planBadge").innerHTML = need.length ? (ready.length === need.length ? `<span class="tag ok">Ready to start</span>` : `<span class="tag warn">${ready.length} of ${need.length} documents ready</span>`) : "";
    const P = $("#planCard");
    P.querySelectorAll("[data-eq]").forEach(el => el.addEventListener("change", () => { const i = Number(el.dataset.eq); if (el.type === "checkbox") plan.equipment[i].done = el.checked; else plan.equipment[i].item = el.value; }));
    P.querySelectorAll("[data-eqdel]").forEach(b => b.addEventListener("click", () => { plan.equipment.splice(Number(b.dataset.eqdel), 1); drawPlan(); }));
    P.querySelectorAll("[data-con]").forEach(el => el.addEventListener("change", () => { const i = Number(el.dataset.con); if (el.type === "checkbox") plan.consumables[i].done = el.checked; else if (el.classList.contains("conQty")) plan.consumables[i].qty = el.value; else plan.consumables[i].product = el.value; }));
    P.querySelectorAll("[data-condel]").forEach(b => b.addEventListener("click", () => { plan.consumables.splice(Number(b.dataset.condel), 1); drawPlan(); }));
    P.querySelectorAll("[data-need]").forEach(el => el.addEventListener("change", () => { plan.documents[Number(el.dataset.need)].needed = el.checked; drawPlan(); }));
    P.querySelectorAll("[data-ready]").forEach(el => el.addEventListener("change", () => { plan.documents[Number(el.dataset.ready)].ready = el.checked; drawPlan(); }));
    P.querySelectorAll("[data-doc]").forEach(el => el.addEventListener("change", () => { plan.documents[Number(el.dataset.doc)].name = el.value; }));
    P.querySelectorAll("[data-docdel]").forEach(b => b.addEventListener("click", () => { plan.documents.splice(Number(b.dataset.docdel), 1); drawPlan(); }));
    P.querySelectorAll("[data-link]").forEach(b => b.addEventListener("click", () => { const u = prompt("Paste the Drive link for this document"); if (u) { plan.documents[Number(b.dataset.link)].link = u.trim(); drawPlan(); } }));
    P.querySelectorAll("[data-copy]").forEach(b => b.addEventListener("click", async () => {
      const i = Number(b.dataset.copy); b.disabled = true; b.textContent = "Copying";
      try { const out = await api("copyTemplate", { docId: plan.documents[i].docId, jobId: d["Job ID"] }); plan.documents[i].link = out.url; plan.documents[i].copy = out.id; await savePlanOnly(); toast("Job copy made in the job's Drive folder" + (out.converted ? " (converted to a Google Doc)" : "") + "."); drawPlan(); } catch (err) { toast(err.message, true); b.disabled = false; b.textContent = "Job copy"; }
    }));
    P.querySelectorAll("[data-sign]").forEach(b => b.addEventListener("click", async () => { try { await savePlanOnly(); } catch (e) { } signPlanDoc(plan.documents[Number(b.dataset.sign)], d, false); }));
    P.querySelectorAll("[data-signmail]").forEach(b => b.addEventListener("click", async () => { try { await savePlanOnly(); } catch (e) { } signPlanDoc(plan.documents[Number(b.dataset.signmail)], d, true); }));
    if (plan.documents.some(x => x.copy)) api("listSignDocs", { jobId: d["Job ID"] }).then(out => { (out.docs || []).filter(sg => sg["Status"] === "Signed" && sg["Target Doc ID"]).forEach(sg => { plan.documents.forEach((x, i) => { if (x.copy === sg["Target Doc ID"]) { const el = P.querySelector(`[data-signed="${i}"]`); if (el) el.textContent = (el.textContent ? el.textContent + ", " : "Signed: ") + sg["Signed Name"]; } }); }); }).catch(() => { });
    P.querySelectorAll("[data-mk]").forEach(b => b.addEventListener("click", async () => {
      const i = Number(b.dataset.mk); const tplNo = plan.documents[i].template; const tpl = (state.documents || []).find(x => x["Doc No"] === tplNo);
      if (!tpl) { toast("Template " + tplNo + " not found in the SMS list.", true); return; }
      b.disabled = true; b.textContent = "Copying";
      try { const out = await api("copyTemplate", { docId: tpl["Doc ID"], jobId: d["Job ID"] }); plan.documents[i].link = out.url; plan.documents[i].copy = out.id; await savePlanOnly(); toast("Copy made in the job's Drive folder. Open it, fill it in, then tick ready."); drawPlan(); } catch (err) { toast(err.message, true); b.disabled = false; b.textContent = "Create from template"; }
    }));
  };
  if (j) {
    drawPlan();
    $("#addEq").addEventListener("click", () => { plan.equipment.push({ item: "", done: false }); drawPlan(); $("#eqList .eqItem:last-of-type") && $("#eqList .eqItem:last-of-type").focus(); });
    $("#addCon").addEventListener("click", () => { plan.consumables.push({ product: "", qty: "", done: false }); drawPlan(); });
    $("#addDoc").addEventListener("click", () => { plan.documents.push({ name: "", link: "", needed: true, ready: false }); drawPlan(); });
    $("#addSmsDoc").addEventListener("change", ev => { const x = (state.documents || []).find(y => y["Doc ID"] === ev.target.value); if (x) { plan.documents.push({ name: x["Title"], docId: x["Doc ID"], link: x["Link"], needed: true, ready: false }); drawPlan(); } ev.target.value = ""; });
    $("#planNotes").addEventListener("change", () => plan.notes = $("#planNotes").value);
    if (!(state.chem || {}).products) api("listProducts").then(out => { state.chem = out; drawPlan(); }).catch(() => { });
  }

  $("#jobForm").addEventListener("submit", async ev => {
    ev.preventDefault();
    const btn = $("#jobSave"); btn.disabled = true;
    try {
      let clientId = $("#jClient").value;
      const newName = $("#jNewClient").value.trim();
      if (newName) { const out = await api("saveClient", { client: { "Name": newName } }); state.clients.push(out.client); clientId = out.client["Client ID"]; }
      const job = {
        "Job ID": j ? j["Job ID"] : "", "Client ID": clientId, "Title": $("#jTitle").value.trim(), "Service": $("#jService").value,
        "Site Name": $("#jSiteName").value.trim(), "Site Address": $("#jAddress").value.trim(), "Latitude": $("#jLat").value, "Longitude": $("#jLng").value,
        "Status": $("#jStatus").value, "Priority": $("#jPriority").value, "Start Date": $("#jStart").value, "End Date": $("#jEnd").value,
        "Assigned To": $("#jAssigned").value.trim(), "Quote Value": $("#jValue").value, "Description": $("#jDesc").value,
        "Next Action": $("#jNextAction").value.trim(), "Next Action Date": $("#jNextDate").value, "Notes": $("#jNotes").value,
        "POIs": JSON.stringify(pois.map(p => ({ name: p.name || "", lat: Number(p.lat), lng: Number(p.lng) }))),
        "Stages": JSON.stringify(stages.filter(st => st.name || st.start).map(st => ({ name: st.name || "", start: st.start || "", end: st.end || "", status: st.status || "Planned" }))),
        "Planning": j ? JSON.stringify({ equipment: plan.equipment.filter(e => e.item), consumables: plan.consumables.filter(c => c.product), documents: plan.documents.filter(x => x.name), notes: ($("#planNotes") ? $("#planNotes").value : plan.notes) || "" }) : ""
      };
      const out = await api("saveJob", { job });
      const idx = state.jobs.findIndex(x => x["Job ID"] === out.job["Job ID"]);
      if (idx >= 0) state.jobs[idx] = out.job; else state.jobs.push(out.job);
      saveCache(); toast(j ? "Job saved" : "Job created");
      location.hash = "#/jobs/" + out.job["Job ID"];
    } catch (err) { toast(err.message, true); }
    finally { btn.disabled = false; }
  });
  const del = $("#jobDelete");
  if (del) del.addEventListener("click", async () => {
    if (!confirm("Delete this job? This removes it from the sheet. To keep the record, set the status to Cancelled instead.")) return;
    try { await api("deleteJob", { jobId: j["Job ID"] }); state.jobs = state.jobs.filter(x => x["Job ID"] !== j["Job ID"]); saveCache(); toast("Job deleted"); location.hash = "#/jobs"; }
    catch (err) { toast(err.message, true); }
  });
}

/* ---------- clients ---------- */
function renderClients(v) {
  v.innerHTML = `
    <div class="page-head"><div><h1>Clients</h1><p class="muted">${state.clients.length} in total</p></div><div><a class="btn btn-primary" href="#/clients/new">New client</a></div></div>
    <div class="toolbar"><input type="search" id="clientSearch" placeholder="Search name, contact, address"></div>
    <div id="clientTable"></div>`;
  const draw = () => {
    const q = $("#clientSearch").value.toLowerCase();
    const rows = state.clients.filter(c => !q || [c["Name"], c["Contact Name"], c["Address"], c["Email"], c["Client Type"]].join(" ").toLowerCase().includes(q)).sort((a, b) => String(a["Name"]).localeCompare(String(b["Name"])));
    $("#clientTable").innerHTML = rows.length ? `<table class="tbl"><thead><tr><th>Client</th><th class="hide-m">Contact</th><th>Open jobs</th><th class="hide-m">Type</th></tr></thead><tbody>
      ${rows.map(c => { const open = jobsByClient(c["Client ID"]).filter(j => !["Completed", "Invoiced", "Cancelled"].includes(j["Status"])).length; return `<tr class="row" data-id="${esc(c["Client ID"])}"><td><a href="#/clients/${esc(c["Client ID"])}">${esc(c["Name"])}</a>${c["Status"] === "Archived" ? ` <span class="pill" data-s="Cancelled">Archived</span>` : ""}</td><td class="hide-m">${esc(c["Contact Name"] || [c["First Name"], c["Last Name"]].filter(Boolean).join(" "))}<div class="small muted">${esc(c["Phone"] || "")}${c["Phone"] && c["Email"] ? ", " : ""}${esc(c["Email"] || "")}</div></td><td>${open}</td><td class="hide-m">${esc(c["Client Type"] || "")}</td></tr>`; }).join("")}
      </tbody></table>` : `<p class="empty">No clients yet.</p>`;
    $("#clientTable").querySelectorAll("tr.row").forEach(tr => tr.addEventListener("click", ev => { if (ev.target.tagName !== "A") location.hash = "#/clients/" + tr.dataset.id; }));
  };
  $("#clientSearch").addEventListener("input", draw); draw();
}

function renderClientForm(v, id) {
  const c = id ? state.clients.find(x => x["Client ID"] === id) : null;
  if (id && !c) { v.innerHTML = `<p class="empty">Client not found.</p>`; return; }
  const d = c || {};
  const jobs = c ? jobsByClient(c["Client ID"]).sort((a, b) => String(b["Start Date"] || "").localeCompare(String(a["Start Date"] || ""))) : [];
  v.innerHTML = `
    <div class="page-head"><div><p class="muted small"><a href="#/clients">Clients</a> / ${c ? esc(c["Client ID"]) : "New"}</p><h1>${c ? esc(c["Name"]) : "New client"}</h1>${c && c["Address"] ? `<p class="small">${esc(c["Address"])} ${dirLink({ "Site Address": c["Address"] })}</p>` : ""}</div>
      ${c ? `<div class="btnrow"><a class="btn btn-primary" href="#/jobs/new?client=${esc(c["Client ID"])}" id="newJobForClient">New job for this client</a> <a class="btn btn-sm" href="#/clients/${esc(c["Client ID"])}/sign">Standing agreements</a></div>` : ""}</div>
    ${c ? `<div class="card" style="margin-bottom:16px"><h2>Standing agreements</h2>${standingAgreements(c["Client ID"]).length || standingPermission(c["Client ID"]) ? `<ul class="list">${standingAgreements(c["Client ID"]).map(a => `<li><span class="when">${esc(fmtDate(a["Signed Date"]))}</span><div class="what"><strong>${esc(a["Title"])}</strong> <span class="small muted">${esc(a["Signed Name"] || "")}${a["Valid To"] ? ", until " + esc(fmtDate(a["Valid To"])) : ", until cancelled"}</span> ${a["PDF URL"] ? `${extLink(a["PDF URL"], "PDF", "")}` : ""}</div></li>`).join("")}${standingPermission(c["Client ID"]) ? `<li><span class="when">${esc(fmtDate(standingPermission(c["Client ID"])["Signed Date"]))}</span><div class="what"><strong>Firearm use</strong> <span class="small muted">${esc(standingPermission(c["Client ID"])["Signed By"] || "")}${standingPermission(c["Client ID"])["Valid To"] ? ", until " + esc(fmtDate(standingPermission(c["Client ID"])["Valid To"])) : ", until revoked"}</span> <a href="${esc(standingPermission(c["Client ID"])["PDF URL"])}" target="_blank" rel="noopener">PDF</a></div></li>` : ""}</ul>` : `<p class="empty">Nothing standing. A letter of engagement or firearm use permission signed here covers every job for this client until it is cancelled.</p>`}<div class="btnrow" style="margin-top:10px"><a class="btn btn-sm" href="#/clients/${esc(c["Client ID"])}/sign">Open agreements</a><a class="btn btn-sm btn-quiet" href="#/clients/${esc(c["Client ID"])}/permission">Firearm use permission</a></div></div>` : ""}
    <div class="grid cols-2">
      <form id="clientForm" class="card">
        <label for="cName">Client or trading name</label><input id="cName" required value="${esc(d["Name"] || "")}" placeholder="As it should appear on the invoice">
        <div class="form" style="gap:0 12px"><div><label for="cFirst">Authorised person, first name</label><input id="cFirst" value="${esc(d["First Name"] || (d["Contact Name"] || "").split(" ")[0] || "")}"></div><div><label for="cLast">Last name</label><input id="cLast" value="${esc(d["Last Name"] || (d["Contact Name"] || "").split(" ").slice(1).join(" ") || "")}"></div></div>
        <div class="form" style="gap:0 12px"><div><label for="cEmail">Email</label><input id="cEmail" type="email" value="${esc(d["Email"] || "")}"></div><div><label for="cPhone">Phone</label><input id="cPhone" type="tel" value="${esc(d["Phone"] || "")}"></div></div>
        <div class="form" style="gap:0 12px"><div><label for="cMobile">Mobile</label><input id="cMobile" type="tel" value="${esc(d["Mobile"] || "")}"></div><div><label for="cABN">ABN</label><input id="cABN" value="${esc(d["ABN"] || "")}"></div></div>
        <label for="cStreet">Street address</label><div class="suggest-wrap"><input id="cStreet" value="${esc(d["Street"] || d["Address"] || "")}" placeholder="Start typing and pick a match"></div>
        <div class="form" style="gap:0 12px"><div><label for="cCity">Suburb or town</label><input id="cCity" value="${esc(d["City"] || "")}"></div><div><label for="cState">State</label><input id="cState" value="${esc(d["State"] || "WA")}"></div></div>
        <label for="cPostcode">Postcode</label><input id="cPostcode" value="${esc(d["Postcode"] || "")}" style="max-width:10em">
        <label for="cType">Client type</label><select id="cType">${option(CONFIG.clientTypes, d["Client Type"], "Choose")}</select>
        <label for="cNotes">Notes</label><textarea id="cNotes">${esc(d["Notes"] || "")}</textarea>
        <label for="cStatus">Status</label><select id="cStatus">${option(["Active", "Archived"], d["Status"] || "Active")}</select>
        <div class="form-actions"><button class="btn btn-primary" type="submit" id="clientSave">${c ? "Save changes" : "Create client"}</button><a class="btn btn-quiet" href="#/clients">Cancel</a></div>
      </form>
      <div class="card"><h2>Jobs</h2>${c ? (jobs.length ? `<ul class="list">${jobs.map(j => `<li><span class="when">${esc(fmtDate(j["Start Date"]) || "No date")}</span><div class="what"><a href="#/jobs/${esc(j["Job ID"])}">${esc(j["Title"])}</a><div class="sub">${esc(j["Service"] || "")} ${pill(j["Status"])} ${dirLink(j)}</div></div></li>`).join("")}</ul>` : `<p class="empty">No jobs for this client yet.</p>`) : `<p class="empty">Save the client first, then add jobs.</p>`}</div>
    </div>`;
  attachAddressSuggest($("#cStreet"), it => { $("#cStreet").value = it.street || it.label; if (it.city) $("#cCity").value = it.city; if (it.state) $("#cState").value = it.state; if (it.postcode) $("#cPostcode").value = it.postcode; });
  $("#clientForm").addEventListener("submit", async ev => {
    ev.preventDefault();
    const btn = $("#clientSave"); btn.disabled = true;
    try {
      const first = $("#cFirst").value.trim(), last = $("#cLast").value.trim();
      const street = $("#cStreet").value.trim(), city = $("#cCity").value.trim(), st = $("#cState").value.trim(), pc = $("#cPostcode").value.trim();
      const client = { "Client ID": c ? c["Client ID"] : "", "Name": $("#cName").value.trim(), "Client Type": $("#cType").value,
        "Contact Name": [first, last].filter(Boolean).join(" "), "First Name": first, "Last Name": last,
        "Phone": $("#cPhone").value.trim(), "Mobile": $("#cMobile").value.trim(), "Email": $("#cEmail").value.trim(), "ABN": $("#cABN").value.trim(),
        "Street": street, "City": city, "State": st, "Postcode": pc, "Address": [street, [city, st, pc].filter(Boolean).join(" ")].filter(Boolean).join(", "),
        "Notes": $("#cNotes").value, "Status": $("#cStatus").value };
      const out = await api("saveClient", { client });
      const idx = state.clients.findIndex(x => x["Client ID"] === out.client["Client ID"]);
      if (idx >= 0) state.clients[idx] = out.client; else state.clients.push(out.client);
      state.jobs.forEach(j => { if (j["Client ID"] === out.client["Client ID"]) j["Client Name"] = out.client["Name"]; });
      saveCache(); toast(c ? "Client saved" : "Client created");
      location.hash = "#/clients/" + out.client["Client ID"];
    } catch (err) { toast(err.message, true); }
    finally { btn.disabled = false; }
  });
}

/* ---------- job report ---------- */
function renderReport(v, jobId) {
  const j = state.jobs.find(x => x["Job ID"] === jobId);
  if (!j) { v.innerHTML = `<p class="empty">Job not found.</p>`; return; }
  v.innerHTML = `<div class="page-head"><div><p class="muted small"><a href="#/jobs">Jobs</a> / <a href="#/jobs/${esc(jobId)}">${esc(j["Title"])}</a> / Report</p><h1>Job report</h1></div></div><p class="muted">Loading visits and photos from the sheet.</p>`;
  api("getReport", { jobId }).then(out => drawReport(v, out)).catch(err => { v.querySelector("p.muted").textContent = err.message; });
}
function drawReport(v, out) {
  const j = out.job, c = out.client || {}, visits = out.visits || [];
  const r = out.report || {};
  const draftWork = visits.length ? visits.map(x => `${fmtDate(x.date)}${x.start ? ", " + x.start + (x.finish ? " to " + x.finish : "") : ""}: ${[x.methods, x.target, x.product ? x.product + (x.quantity ? " (" + x.quantity + ")" : "") : "", (x.count || x.count === 0) && x.kind === "Site visit" ? x.count + " " + (Number(x.count) === 1 ? "animal" : "animals") : ""].filter(Boolean).join(", ")}${x.notes ? ". " + x.notes : ""}`).join("\n\n") : "";
  const draftRecs = visits.map(x => x.recommendations).filter(Boolean).join("\n\n");
  const photoCount = visits.reduce((a, x) => a + x.photos.length, 0);
  const d = {
    title: r["Title"] || j["Title"], summary: r["Summary"] || "", work: r["Work Carried Out"] || draftWork, obs: r["Observations"] || "",
    recs: r["Recommendations"] || draftRecs, photos: String(r["Include Photos"] || "Yes") !== "No"
  };
  v.innerHTML = `
    <div class="page-head"><div><p class="muted small"><a href="#/jobs">Jobs</a> / <a href="#/jobs/${esc(j["Job ID"])}">${esc(j["Title"])}</a> / Report</p><h1>Job report</h1>
      <p class="muted small">${esc(c["Name"] || j["Client Name"] || "No client")}${c["Email"] ? ", " + esc(c["Email"]) : ", no client email on file"}${r["Sent Date"] ? ". Sent " + esc(fmtWhen(r["Sent Date"])) + " to " + esc(r["Sent To"] || "") : ""}</p></div></div>
    <div class="grid cols-2">
      <form id="reportForm" class="card">
        <h2>Draft</h2>
        <p class="muted small">Prefilled from ${visits.length} field ${visits.length === 1 ? "record" : "records"} tied to this job. Edit anything, then build the PDF.</p>
        <label for="rTitle">Report title</label><input id="rTitle" value="${esc(d.title)}">
        <label for="rSummary">Summary (optional, one or two sentences) ${tidyBtn("rSummary", "report summary", "Summary", j["Service"])}</label><textarea id="rSummary">${esc(d.summary)}</textarea>
        <label for="rWork">Work carried out ${tidyBtn("rWork", "report section, work carried out", "Work carried out", j["Service"])}</label><textarea id="rWork" style="min-height:9em">${esc(d.work)}</textarea>
        <label for="rObs">Observations (optional) ${tidyBtn("rObs", "report section, observations", "Observations", j["Service"])}</label><textarea id="rObs">${esc(d.obs)}</textarea>
        <label for="rRecs">Recommendations ${tidyBtn("rRecs", "report section, recommendations", "Recommendations", j["Service"])}</label><textarea id="rRecs">${esc(d.recs)}</textarea>
        <label><input type="checkbox" id="rPhotos" ${d.photos ? "checked" : ""} style="width:auto"> Include the ${photoCount} field ${photoCount === 1 ? "photo" : "photos"} (up to 16)</label>
        <div class="form-actions">
          <button class="btn" type="submit" id="rSave">Save draft</button>
          <button class="btn btn-primary" type="button" id="rBuild">Build PDF</button>
        </div>
      </form>
      <div>
        <div class="card" id="rSendCard">
          <h2>Send</h2>
          ${r["PDF URL"] ? pdfBlock(r["PDF URL"], r["PDF File ID"]) : `<p class="empty">Build the PDF first. It is saved to Drive under Job Reports.</p>`}
        </div>
        <div class="card" style="margin-top:16px"><h2>Field records</h2>${visits.length ? `<table class="tbl"><thead><tr><th>Date</th><th>Method</th><th class="hide-m">Target</th><th>No.</th></tr></thead><tbody>${visits.map(x => `<tr><td>${esc(fmtDate(x.date))}<div class="small muted">${esc(x.who || "")}</div></td><td>${esc(x.methods || x.kind)}${x.product ? `<div class="small muted">${esc(x.product)}</div>` : ""}</td><td class="hide-m">${esc(x.target || "")}</td><td>${esc(x.count === 0 ? "0" : (x.count || ""))}</td></tr>`).join("")}</tbody></table>` : `<p class="empty">No field records are tied to this job yet. In the Job log form, pick this job in the Job dropdown and the visit lands here.</p>`}</div>
      </div>
    </div>`;
  const collect = () => ({ "Report ID": r["Report ID"] || "", "Job ID": j["Job ID"], "Title": $("#rTitle").value.trim(), "Summary": $("#rSummary").value, "Work Carried Out": $("#rWork").value, "Observations": $("#rObs").value, "Recommendations": $("#rRecs").value, "Include Photos": $("#rPhotos").checked ? "Yes" : "No" });
  const saveDraft = async () => { const o = await api("saveReport", { report: collect() }); Object.assign(r, o.report); upsertReport(o.report); return o.report; };
  wireTidy(v);
  $("#reportForm").addEventListener("submit", async ev => { ev.preventDefault(); $("#rSave").disabled = true; try { await saveDraft(); toast("Draft saved"); } catch (e) { toast(e.message, true); } finally { $("#rSave").disabled = false; } });
  $("#rBuild").addEventListener("click", async () => {
    $("#rBuild").disabled = true; $("#rBuild").textContent = "Building";
    try { await saveDraft(); const o = await api("buildReportPdf", { reportId: r["Report ID"] }); Object.assign(r, o.report); upsertReport(o.report); $("#rSendCard").innerHTML = `<h2>Send</h2>` + pdfBlock(o.pdfUrl, o.report["PDF File ID"]); wireSend(); toast("PDF built"); }
    catch (e) { toast(e.message, true); }
    finally { $("#rBuild").disabled = false; $("#rBuild").textContent = "Build PDF"; }
  });
  function pdfBlock(url, fileId) {
    const dl = fileId ? "https://drive.google.com/uc?export=download&id=" + encodeURIComponent(fileId) : url;
    return `<p><a class="btn" href="${esc(dl)}" target="_blank" rel="noopener">Download PDF</a> <a class="btn btn-quiet" href="${esc(url)}" target="_blank" rel="noopener">Open in Drive</a></p>
      <p class="muted small">Email it from your Terana address: the button opens a new email in your mail app with the client, subject and wording filled in. Attach the downloaded PDF, press send, then come back and mark it sent.</p>
      <p><a class="btn btn-primary" id="rEmail" href="#">Email client</a> <button class="btn" type="button" id="rSent">Mark as sent</button></p>`;
  }
  function wireSend() {
    const em = $("#rEmail"), sent = $("#rSent");
    if (em) em.addEventListener("click", ev => {
      ev.preventDefault();
      const to = c["Email"] || "";
      const first = (c["Contact Name"] || "").split(" ")[0];
      const subject = `${$("#rTitle").value.trim() || j["Title"]}: report from Terana Environmental`;
      const body = `Hi${first ? " " + first : ""},\n\nPlease find attached the report for ${$("#rTitle").value.trim() || j["Title"]}${j["Site Name"] ? " at " + j["Site Name"] : ""}.\n\n${$("#rSummary").value.trim() ? $("#rSummary").value.trim() + "\n\n" : ""}Let me know if you have any questions.\n\nCourtney Kelly\nTerana Environmental\n0450 303 434`;
      window.location.href = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    });
    if (sent) sent.addEventListener("click", async () => {
      const to = prompt("Sent to which address?", c["Email"] || ""); if (to === null) return;
      try { const o = await api("markReportSent", { reportId: r["Report ID"], sentTo: to }); Object.assign(r, o.report); upsertReport(o.report); if (o.job) { const i = state.jobs.findIndex(x => x["Job ID"] === o.job["Job ID"]); if (i >= 0) state.jobs[i] = o.job; } saveCache(); toast("Marked as sent. Job is now Completed with next action Invoice."); route(); }
      catch (e) { toast(e.message, true); }
    });
  }
  wireSend();
}
function upsertReport(rep) { const i = state.reports.findIndex(x => x["Report ID"] === rep["Report ID"]); const slim = { "Report ID": rep["Report ID"], "Job ID": rep["Job ID"], "PDF URL": rep["PDF URL"], "Sent Date": rep["Sent Date"], "Updated": rep["Updated"] }; if (i >= 0) state.reports[i] = slim; else state.reports.push(slim); saveCache(); }

/* ---------- shooting permission ---------- */
function renderPermission(v, jobId, clientId) {
  const j = jobId ? state.jobs.find(x => x["Job ID"] === jobId) : null;
  if (jobId && !j) { v.innerHTML = `<p class="empty">Job not found.</p>`; return; }
  v.innerHTML = `<div class="page-head"><div><h1>Firearm use</h1></div></div><p class="muted">Loading.</p>`;
  api("getPermission", jobId ? { jobId } : { clientId }).then(out => drawPermission(v, out)).catch(err => { v.querySelector("p.muted").textContent = err.message; });
}
function drawPermission(v, out) {
  const c = out.client || {}, r = out.permission || {}, standingOnly = !out.job;
  const j = out.job || { "Job ID": "", "Title": "", "Site Address": "", "Client ID": c["Client ID"], "Client Name": c["Name"], "Latitude": (out.pins || [])[0] ? (out.pins || [])[0].lat : "", "Longitude": (out.pins || [])[0] ? (out.pins || [])[0].lng : "", "Status": "Scheduled", "POIs": "[]", "Start Date": "" };
  const crumb = standingOnly ? `<a href="#/clients">Clients</a> / <a href="#/clients/${esc(c["Client ID"])}">${esc(c["Name"])}</a> / Firearm use` : `<a href="#/jobs">Jobs</a> / <a href="#/jobs/${esc(j["Job ID"])}">${esc(j["Title"])}</a> / Permission`;
  const backHref = standingOnly ? `#/clients/${esc(c["Client ID"])}` : `#/jobs/${esc(j["Job ID"])}`;
  const d = {
    landholder: r["Landholder Name"] || [c["First Name"], c["Last Name"]].filter(Boolean).join(" ") || c["Contact Name"] || "",
    authority: r["Authority"] || "owner", address: r["Property Address"] || j["Site Address"] || c["Address"] || "",
    purpose: r["Purpose"] || "Culling, euthanasia or other humane destruction of pest animals", species: r["Species"] || "",
    from: String(r["Valid From"] || j["Start Date"] || todayISO()).slice(0, 10), to: String(r["Valid To"] || "").slice(0, 10),
    conditions: r["Conditions"] || "", carcass: r["Carcass Disposal"] || "", signedBy: r["Signed By"] || "", signedDate: String(r["Signed Date"] || "").slice(0, 10)
  };
  let areas = parseJson(r["Permitted Areas"], []), excl = parseJson(r["Exclusion Areas"], []);
  if (!Array.isArray(areas)) areas = []; if (!Array.isArray(excl)) excl = [];
  v.innerHTML = `
    <div class="page-head"><div><p class="muted small">${crumb}</p><h1>${standingOnly ? "Firearm use permission (standing)" : "Firearm use permission"}</h1>
      <p class="muted small">${r["KML URL"] ? `Map files in Drive: <a href="${esc(r["KML URL"])}" target="_blank" rel="noopener">KML</a>${r["GPX URL"] ? `, <a href="${esc(r["GPX URL"])}" target="_blank" rel="noopener">GPX</a>` : ""}. ` : ""}${r["Status"] === "Signed" && r["PDF URL"] ? `Signed ${esc(fmtDate(r["Signed Date"]))} by ${esc(r["Signed By"] || "")}${r["Valid To"] ? ", valid to " + esc(fmtDate(r["Valid To"])) : ", until revoked"}. ${extLink(r["PDF URL"], "Open PDF", "")}` : "Not yet signed."}${standingOnly ? " Covers every job for this client on this land." : out.standing ? ` A standing permission for this client is already in place (signed ${esc(fmtDate(out.standing["Signed Date"]))}), so this job is covered unless the land is different.` : ""}</p></div>${r["Status"] === "Signed" ? `<div><button type="button" class="btn btn-quiet" id="permCancel">Revoke / cancel</button></div>` : ""}</div>
    <form id="permForm" class="form">
      <div><label for="pLandholder">Landholder or occupier name</label><input id="pLandholder" required value="${esc(d.landholder)}"></div>
      <div><label for="pEmail">Landholder email (for signing by link)</label><input id="pEmail" type="email" value="${esc(r["Landholder Email"] || c["Email"] || "")}"></div>
      <div><label for="pAuthority">They are</label><select id="pAuthority">${[["owner", "the owner"], ["occupier", "the occupier"], ["representative", "an authorised representative of the owner or occupier"]].map(([k, l]) => `<option value="${k}" ${d.authority === k ? "selected" : ""}>${l}</option>`).join("")}</select></div>
      <div class="full"><label for="pAddress">Land (address or description)</label><input id="pAddress" required value="${esc(d.address)}"></div>
      <div><label for="pPurpose">Purpose</label><input id="pPurpose" value="${esc(d.purpose)}"></div>
      <div><label for="pSpecies">Species</label><input id="pSpecies" value="${esc(d.species)}" placeholder="e.g. Foxes, rabbits, feral pigs"></div>
      <div><label for="pFrom">Valid from</label><input id="pFrom" type="date" value="${esc(d.from)}"></div>
      <div><label for="pTo">Valid to (blank = until revoked)</label><input id="pTo" type="date" value="${esc(d.to)}"></div>
      <div class="full"><label for="pConditions">Conditions (one per line, leave blank if none)</label><textarea id="pConditions" style="min-height:5em">${esc(d.conditions)}</textarea></div>
      <div class="full"><label for="pCarcass">Carcass disposal</label><textarea id="pCarcass" style="min-height:4em" placeholder="e.g. Collected and buried on site at the landholder's nominated pit; left in situ in paddock 3; removed by Terana">${esc(d.carcass)}</textarea></div>
      <div class="full"><label>Map: permitted areas and exclusion zones</label>
        <div class="chips" style="margin-bottom:6px"><button type="button" class="chip on" data-m="pan">Look around</button><button type="button" class="chip" data-m="area">Draw permitted area</button><button type="button" class="chip" data-m="excl">Draw exclusion zone</button><button type="button" class="btn btn-sm" id="finishPoly" hidden>Finish this shape</button></div>
        <div class="locate" style="margin-bottom:6px"><div class="suggest-wrap"><input id="permSearch" placeholder="Search an address or place to move the map"></div><div class="locate-btns"><button type="button" class="btn" id="permGps">My location</button><button type="button" class="btn btn-quiet" id="permBig">Bigger map</button></div></div>
        <p class="muted small" style="margin:0 0 6px">Tap the map corner by corner, then press Finish. Pinch to zoom. Use the layers button for aerial, aerial with labels, or street.</p>
        <div class="minimap" id="permMap" style="height:420px"></div>
        <ul class="list" id="areaList"></ul>
        <div class="btnrow" style="margin-top:6px"><button type="button" class="btn btn-sm btn-quiet" id="permKml">Download KML</button><button type="button" class="btn btn-sm btn-quiet" id="permGpx">Download GPX</button><span class="small muted">For Google Earth, a Garmin or the phone's GPS app. Includes the job's points of interest.</span></div></div>
      <div><label for="pSignedBy">Signed by (name)</label><input id="pSignedBy" value="${esc(d.signedBy || d.landholder)}"></div>
      <div class="full"><label>Landholder signature</label><div class="sigbox"><canvas id="sigPad" width="900" height="260"></canvas></div><div class="form-actions" style="margin-top:6px"><button type="button" class="btn btn-sm btn-quiet" id="sigClear">Clear</button><span class="muted small">Sign with a finger or stylus.</span></div></div>
      <div class="full form-actions"><button class="btn btn-primary" type="submit" id="permSave">Save and build PDF</button><button class="btn" type="button" id="permSend">Save and email link to sign</button><a class="btn btn-quiet" href="${backHref}">Back</a></div>
      <p class="full small muted" id="permStatus">${r["Status"] === "Sent" ? "Link sent " + esc(fmtDate(r["Sent Date"])) + ", not signed yet." : r["Status"] === "Signed" && r["Signed How"] ? esc(r["Signed How"]) + "." : ""}</p>
    </form>`;

  // map
  const sat = satTiles();
  const labels = L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}", { maxZoom: 19, crossOrigin: true, attribution: "" });
  const street = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, crossOrigin: true, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' });
  const hasPin = j["Latitude"] !== "" && j["Latitude"] != null && !isNaN(Number(j["Latitude"]));
  const pm = L.map("permMap", { layers: [sat] }).setView(hasPin ? [Number(j["Latitude"]), Number(j["Longitude"])] : CONFIG.mapCentre, hasPin ? 15 : CONFIG.mapZoom);
  L.control.layers({ "Aerial": sat, "Street": street }, { "Labels (roads, towns)": labels }).addTo(pm);
  labels.addTo(pm);
  let meMarker = null;
  attachAddressSuggest($("#permSearch"), it => { pm.setView([it.lat, it.lng], 16); L.circleMarker([it.lat, it.lng], { radius: 7, color: "#C1440E", fillColor: "#fff", fillOpacity: 1 }).addTo(pm).bindTooltip(it.label).openTooltip(); });
  $("#permSearch").addEventListener("keydown", async ev => { if (ev.key !== "Enter") return; ev.preventDefault(); const q = ev.target.value.trim(); if (!q) return; try { const r = await fetch("https://nominatim.openstreetmap.org/search?format=json&countrycodes=au&limit=1&q=" + encodeURIComponent(q)); const d = await r.json(); if (d[0]) pm.setView([Number(d[0].lat), Number(d[0].lon)], 15); else toast("No match. Try a town name or pick a suggestion.", true); } catch (e) { toast("Search failed, check the connection.", true); } });
  $("#permGps").addEventListener("click", () => { if (!navigator.geolocation) { toast("No GPS on this device", true); return; } navigator.geolocation.getCurrentPosition(p => { const ll = [p.coords.latitude, p.coords.longitude]; if (meMarker) meMarker.setLatLng(ll); else meMarker = L.circleMarker(ll, { radius: 8, color: "#1565C0", fillColor: "#1565C0", fillOpacity: .7 }).addTo(pm).bindTooltip("You are here"); pm.setView(ll, 17); }, e => toast("Couldn't get location: " + e.message, true), { enableHighAccuracy: true, timeout: 10000 }); });
  $("#permBig").addEventListener("click", () => { const el = $("#permMap"); const big = el.style.height !== "420px"; el.style.height = big ? "420px" : "75vh"; $("#permBig").textContent = big ? "Bigger map" : "Smaller map"; pm.invalidateSize(); if (!big) el.scrollIntoView({ behavior: "smooth", block: "start" }); });
  if (hasPin) L.marker([Number(j["Latitude"]), Number(j["Longitude"])], { icon: pinIcon(j["Status"]) }).addTo(pm).bindTooltip("Site");
  const pois = parseJson(j["POIs"], []); if (Array.isArray(pois)) pois.forEach(p => L.marker([p.lat, p.lng], { icon: L.divIcon({ className: "", html: `<div class="poi-dot"></div>`, iconSize: [12, 12], iconAnchor: [6, 6] }) }).addTo(pm).bindTooltip(p.name || "Point", { permanent: true, direction: "right", offset: [8, 0], className: "poi-label" }));
  const shapes = L.layerGroup().addTo(pm);
  let mode = "pan", current = [], tempLine = null;
  const styleFor = kind => kind === "excl" ? { color: "#B3261E", fillColor: "#B3261E", fillOpacity: 0.25, weight: 2 } : { color: "#2E7D32", fillColor: "#2E7D32", fillOpacity: 0.2, weight: 2 };
  function drawShapes() {
    shapes.clearLayers();
    areas.forEach((a, i) => L.polygon(a.points, styleFor("area")).addTo(shapes).bindTooltip(a.name || ("Area " + (i + 1)), { permanent: true, direction: "center", className: "poi-label" }));
    excl.forEach((a, i) => L.polygon(a.points, styleFor("excl")).addTo(shapes).bindTooltip(a.name || ("Exclusion " + (i + 1)), { permanent: true, direction: "center", className: "poi-label" }));
    if (tempLine) tempLine.remove(); tempLine = current.length ? L.polyline(current, { color: mode === "excl" ? "#B3261E" : "#2E7D32", dashArray: "4 4" }).addTo(shapes) : null;
    $("#areaList").innerHTML = (areas.map((a, i) => `<li><div class="what"><input class="area-name" data-k="area" data-i="${i}" value="${esc(a.name || "")}" placeholder="Name this permitted area"><div class="sub">Permitted, ${a.points.length} corners</div></div><button type="button" class="btn btn-quiet btn-sm" data-rm="area:${i}">Remove</button></li>`).join("") + excl.map((a, i) => `<li><div class="what"><input class="area-name" data-k="excl" data-i="${i}" value="${esc(a.name || "")}" placeholder="Name this exclusion zone"><div class="sub">Excluded, ${a.points.length} corners</div></div><button type="button" class="btn btn-quiet btn-sm" data-rm="excl:${i}">Remove</button></li>`).join("")) || `<li class="empty">No areas drawn yet. The whole property is assumed if you leave this empty.</li>`;
    $("#areaList").querySelectorAll(".area-name").forEach(inp => inp.addEventListener("input", () => { (inp.dataset.k === "area" ? areas : excl)[Number(inp.dataset.i)].name = inp.value; }));
    $("#areaList").querySelectorAll("[data-rm]").forEach(b => b.addEventListener("click", () => { const [k, i] = b.dataset.rm.split(":"); (k === "area" ? areas : excl).splice(Number(i), 1); drawShapes(); }));
  }
  v.querySelectorAll(".chip[data-m]").forEach(ch => ch.addEventListener("click", () => { if (current.length >= 3) finish(); current = []; mode = ch.dataset.m; v.querySelectorAll(".chip[data-m]").forEach(x => x.classList.toggle("on", x === ch)); $("#finishPoly").hidden = mode === "pan"; drawShapes(); }));
  function finish() { if (current.length >= 3) { (mode === "excl" ? excl : areas).push({ name: "", points: current.map(p => [p[0], p[1]]) }); } current = []; drawShapes(); }
  $("#finishPoly").addEventListener("click", finish);
  pm.on("click", e => { if (mode === "pan") return; current.push([e.latlng.lat, e.latlng.lng]); drawShapes(); });
  drawShapes();
  const all = areas.concat(excl).flatMap(a => a.points);
  if (all.length) pm.fitBounds(L.latLngBounds(all).pad(0.2));
  setTimeout(() => pm.invalidateSize(), 50);

  // signature pad
  const canvas = $("#sigPad"), ctx = canvas.getContext("2d"); let drawing = false, dirty = false;
  ctx.lineWidth = 3; ctx.lineCap = "round"; ctx.strokeStyle = "#000";
  const pos = ev => { const rct = canvas.getBoundingClientRect(); return [(ev.clientX - rct.left) * canvas.width / rct.width, (ev.clientY - rct.top) * canvas.height / rct.height]; };
  canvas.addEventListener("pointerdown", ev => { drawing = true; dirty = true; const [x, y] = pos(ev); ctx.beginPath(); ctx.moveTo(x, y); canvas.setPointerCapture(ev.pointerId); });
  canvas.addEventListener("pointermove", ev => { if (!drawing) return; const [x, y] = pos(ev); ctx.lineTo(x, y); ctx.stroke(); });
  canvas.addEventListener("pointerup", () => drawing = false); canvas.addEventListener("pointercancel", () => drawing = false);
  $("#sigClear").addEventListener("click", () => { ctx.clearRect(0, 0, canvas.width, canvas.height); dirty = false; });

  async function mapImage() {
    // Draw the visible tiles and shapes onto a canvas so the PDF carries the map.
    try {
      const size = pm.getSize(); const cv = document.createElement("canvas"); cv.width = size.x; cv.height = size.y; const cx = cv.getContext("2d");
      cx.fillStyle = "#e8e8e8"; cx.fillRect(0, 0, cv.width, cv.height);
      const layer = pm.hasLayer(sat) ? sat : street;
      const origin = pm.getPixelOrigin();
      Object.values(layer._tiles || {}).forEach(t => { if (!t.loaded || !t.el || !t.el.complete) return; const pt = t.coords.scaleBy(layer.getTileSize()).subtract(origin); try { cx.drawImage(t.el, pt.x, pt.y, layer.getTileSize().x, layer.getTileSize().y); } catch (e) { } });
      const poly = (pts, kind) => { if (!pts.length) return; cx.beginPath(); pts.forEach((p, i) => { const q = pm.latLngToContainerPoint(p); if (i) cx.lineTo(q.x, q.y); else cx.moveTo(q.x, q.y); }); cx.closePath(); cx.fillStyle = kind === "excl" ? "rgba(179,38,30,.3)" : "rgba(46,125,50,.25)"; cx.fill(); cx.strokeStyle = kind === "excl" ? "#B3261E" : "#2E7D32"; cx.lineWidth = 3; cx.stroke(); };
      areas.forEach(a => poly(a.points, "area")); excl.forEach(a => poly(a.points, "excl"));
      cx.font = "bold 14px Arial"; cx.fillStyle = "#000";
      areas.concat(excl).forEach((a, i) => { const q = pm.latLngToContainerPoint(L.latLngBounds(a.points).getCenter()); const label = a.name || (i < areas.length ? "Area " + (i + 1) : "Exclusion " + (i - areas.length + 1)); cx.fillStyle = "#fff"; cx.fillRect(q.x - 4, q.y - 14, cx.measureText(label).width + 8, 18); cx.fillStyle = "#000"; cx.fillText(label, q.x, q.y); });
      if (hasPin) { const q = pm.latLngToContainerPoint([Number(j["Latitude"]), Number(j["Longitude"])]); cx.beginPath(); cx.arc(q.x, q.y, 7, 0, Math.PI * 2); cx.fillStyle = "#C1440E"; cx.fill(); cx.strokeStyle = "#fff"; cx.lineWidth = 2; cx.stroke(); }
      return cv.toDataURL("image/jpeg", 0.85);
    } catch (e) { return ""; }
  }

  const savePermission = async (sendLink) => {
    if (current.length >= 3) finish();
    const btn = $("#permSave"); btn.disabled = true; btn.textContent = "Building";
    try {
      const mapDataUrl = await mapImage();
      const sig = dirty ? canvas.toDataURL("image/png") : "";
      if (!sendLink && !dirty && !r["Signature File ID"]) { if (!confirm("No signature yet. Save without one?")) { btn.disabled = false; btn.textContent = "Save and build PDF"; return; } }
      if (sendLink && !$("#pEmail").value.trim()) { toast("Enter the landholder's email first.", true); btn.disabled = false; btn.textContent = "Save and build PDF"; return; }
      const permission = { "Permission ID": r["Permission ID"] || "", "Job ID": j["Job ID"] || "", "Client ID": c["Client ID"] || "", "Landholder Name": $("#pLandholder").value.trim(), "Landholder Email": $("#pEmail").value.trim(), "Authority": $("#pAuthority").value, "Property Address": $("#pAddress").value.trim(),
        "Purpose": $("#pPurpose").value.trim(), "Species": $("#pSpecies").value.trim(), "Valid From": $("#pFrom").value, "Valid To": $("#pTo").value, "Conditions": $("#pConditions").value, "Carcass Disposal": $("#pCarcass").value.trim(),
        "Permitted Areas": JSON.stringify(areas), "Exclusion Areas": JSON.stringify(excl),
        "Signed By": $("#pSignedBy").value.trim(), "Signed Date": dirty ? todayISO() : (String(r["Signed Date"] || "").slice(0, 10)) };
      const kmlText = kmlFor(exportName(), areas, excl, poiPts()), gpxText = gpxFor(exportName(), areas, excl, poiPts());
      const out = await api("savePermission", { permission, signatureDataUrl: sig, mapDataUrl, kmlText, gpxText, exportName: exportName() });
      Object.assign(r, out.permission);
      const i = state.permissions.findIndex(x => x["Permission ID"] === out.permission["Permission ID"]);
      const slim = { "Permission ID": out.permission["Permission ID"], "Job ID": out.permission["Job ID"], "Client ID": out.permission["Client ID"], "Scope": out.permission["Scope"] || "Job", "Status": out.permission["Status"] || "Draft", "Valid From": out.permission["Valid From"], "Valid To": out.permission["Valid To"], "Signed By": out.permission["Signed By"], "Signed Date": out.permission["Signed Date"], "PDF URL": out.permission["PDF URL"] };
      if (i >= 0) state.permissions[i] = slim; else state.permissions.push(slim); saveCache(); bootstrap();
      if (sendLink) {
        try { await api("markPermissionSent", { permissionId: out.permission["Permission ID"] }); } catch (e) { }
        const link = signLink(out.permission["Token"]);
        const body = `Hi ${permission["Landholder Name"]},\n\nPlease open the link below, check the details and the map, and sign on screen to give Terana Environmental permission to use firearms for pest animal control on your land.\n\n${link}\n\nIt takes a minute and works on a phone. A signed copy is filed automatically and I will send you a PDF.\n\nThanks,\n${state.user.name}\nTerana Environmental\n0450 303 434`;
        location.href = "mailto:" + encodeURIComponent(permission["Landholder Email"]) + "?subject=" + encodeURIComponent("Firearm use permission for signature: " + (j["Site Name"] || j["Title"])) + "&body=" + encodeURIComponent(body);
        toast("Saved. Email opened.");
      } else toast("Permission saved and PDF built");
      route();
    } catch (err) { toast(err.message, true); }
    finally { btn.disabled = false; btn.textContent = "Save and build PDF"; }
  };
  const exportName = () => safeFile((c["Name"] || j["Client Name"] || "Terana") + " " + (j["Title"] || "shooting areas"));
  const poiPts = () => { const pts = (parseJson(j["POIs"], []) || []).filter(p => p && p.lat); if (hasPin) pts.unshift({ name: "Site", lat: Number(j["Latitude"]), lng: Number(j["Longitude"]) }); return pts; };
  $("#permKml").addEventListener("click", () => { if (current.length >= 3) finish(); downloadText(exportName() + ".kml", kmlFor(exportName(), areas, excl, poiPts()), "application/vnd.google-earth.kml+xml"); });
  $("#permGpx").addEventListener("click", () => { if (current.length >= 3) finish(); downloadText(exportName() + ".gpx", gpxFor(exportName(), areas, excl, poiPts()), "application/gpx+xml"); });
  $("#permForm").addEventListener("submit", ev => { ev.preventDefault(); savePermission(false); });
  if ($("#permCancel")) $("#permCancel").addEventListener("click", async () => { if (!confirm("Cancel this permission? It stops covering jobs from today. The signed PDF is kept.")) return; try { await api("cancelPermission", { permissionId: r["Permission ID"] }); toast("Permission cancelled"); await bootstrap(); route(); } catch (err) { toast(err.message, true); } });
  $("#permSend").addEventListener("click", () => savePermission(true));
}

/* ---------- chemicals: SDS register and manifest ---------- */
function renderChemicals(v) {
  v.innerHTML = `<div class="page-head"><div><h1>Chemicals</h1><p class="muted">SDS register, manifest and stock, from the Products tab.</p></div><div class="btnrow"><button class="btn btn-primary" id="newProduct">Add product</button> <button class="btn" id="stockBtn">Stock in / adjust</button></div></div><p class="muted" id="chemLoading">Loading.</p><div id="chemBody"></div>`;
  api("listProducts").then(out => { state.chem = out; drawChemicals(v, out.products || [], out.applications || [], out.movements || [], out.settings || {}); }).catch(err => { $("#chemLoading").textContent = err.message; });
  $("#newProduct").addEventListener("click", () => editProduct(v, null));
  $("#stockBtn").addEventListener("click", () => stockMove(v, ""));
}
function sdsStatus(p) {
  const d = String(p["SDS Issue Date"] || "").slice(0, 10); if (!d) return { cls: "warn", text: "No SDS date" };
  const age = (Date.now() - new Date(d + "T00:00:00").getTime()) / 86400000 / 365.25;
  if (age >= 5) return { cls: "bad", text: "SDS over 5 years, replace" };
  if (age >= 4.5) return { cls: "warn", text: "SDS due for review" };
  return { cls: "ok", text: "SDS current" };
}
function qty(p) {
  const q = p["Quantity On Hand"], u = p["Unit"] || "", ps = Number(p["Pack Size"]);
  if (q === "" || q == null) return "";
  const base = q + (u ? " " + u : "");
  if (!ps) return base;
  const full = Math.floor(Number(q) / ps), rem = Math.round((Number(q) - full * ps) * 1000) / 1000;
  return base + " (" + full + " x " + ps + " " + u + (rem ? " + " + rem + " " + u + " open" : "") + ")";
}
function drawChemicals(v, products, applications, movements, settings) {
  $("#chemLoading").hidden = true;
  const active = products.filter(p => String(p["Status"] || "In use") !== "Retired");
  const byLoc = {}; active.forEach(p => { const k = p["Storage Location"] || settings["Manifest Storage Default"] || "Unspecified"; (byLoc[k] = byLoc[k] || []).push(p); });
  const lastUse = {}; applications.forEach(a => { const k = a["Product"]; if (k && (!lastUse[k] || String(a["Date"]) > String(lastUse[k]))) lastUse[k] = a["Date"]; });
  const low = active.filter(p => Number(p["Pack Size"]) > 0 && p["Quantity On Hand"] !== "" && Number(p["Quantity On Hand"]) < Number(p["Pack Size"]));
  const recent = movements.slice().reverse().slice(0, 15);
  $("#chemBody").innerHTML = `
    ${low.length ? `<div class="notice">Under one pack left: ${low.map(p => esc(p["Product Name"]) + " (" + esc(qty(p)) + ")").join(", ")}.</div>` : ""}
    <div class="card"><div class="card-head"><h2>SDS register</h2><button type="button" class="btn btn-sm" id="printSds">View / print register</button></div>${active.length ? `<table class="tbl"><thead><tr><th>Product</th><th class="hide-m">Supplier</th><th>Schedule</th><th>SDS</th><th class="hide-m">Last used</th><th></th></tr></thead><tbody>
      ${active.map((p, i) => { const st = sdsStatus(p); return `<tr><td><strong>${esc(p["Product Name"])}</strong><div class="small muted">${esc(p["Active Constituent"] || "")}${p["APVMA Number"] ? ", APVMA " + esc(p["APVMA Number"]) : ""}</div></td><td class="hide-m">${esc(p["Manufacturer / Supplier"] || "")}</td><td>${esc(p["Poison Schedule"] || "")}</td><td>${p["SDS Link"] ? `<a href="${esc(p["SDS Link"])}" target="_blank" rel="noopener">Open</a> ` : ""}<span class="tag ${st.cls}">${st.text}</span>${p["SDS Issue Date"] ? `<div class="small muted">${esc(fmtDate(p["SDS Issue Date"]))}</div>` : ""}</td><td class="hide-m">${esc(fmtDate(lastUse[p["Product Name"]]) || "")}</td><td class="right"><button type="button" class="btn btn-sm btn-quiet" data-edit="${i}">Edit</button></td></tr>`; }).join("")}</tbody></table>` : `<p class="empty">No products yet. Add one, or fill the Products tab in the sheet.</p>`}</div>
    <div class="card" style="margin-top:16px"><div class="card-head"><h2>Chemical manifest</h2><div><button type="button" class="btn btn-sm btn-quiet" id="editManifest">Vehicle and emergency details</button> <button type="button" class="btn btn-sm" id="printManifest">View / print manifest</button></div></div>
      <p class="small muted">${esc(settings["Vehicle Description"] || "Vehicle not set")}${settings["Vehicle Registration"] ? ", " + esc(settings["Vehicle Registration"]) : ""}. Responsible person ${esc(settings["Responsible Person"] || "")}, ${esc(settings["Emergency Contact Number"] || "")}. Stock drops automatically when a Job log records pesticide use.</p>
      ${Object.keys(byLoc).sort().map(loc => `<h3 class="loc">${esc(loc)}</h3><table class="tbl"><thead><tr><th>Product</th><th>DG class</th><th>On hand</th><th></th></tr></thead><tbody>${byLoc[loc].map(p => `<tr><td>${esc(p["Product Name"])}<div class="small muted">${esc(p["Poison Schedule"] || "")}${p["UN Number"] ? " UN " + esc(p["UN Number"]) : ""}</div></td><td>${esc(p["DG Class"] || "")}</td><td>${esc(qty(p))}</td><td class="right"><button type="button" class="btn btn-sm btn-quiet" data-stock="${esc(p["Product Name"])}">Stock</button></td></tr>`).join("")}</tbody></table>`).join("") || `<p class="empty">Nothing on hand.</p>`}</div>
    <div class="card" style="margin-top:16px"><h2>Recent stock movements</h2>${recent.length ? `<table class="tbl"><thead><tr><th>Date</th><th>Product</th><th>Change</th><th class="hide-m">Job</th><th class="hide-m">By</th></tr></thead><tbody>${recent.map(m => `<tr><td>${esc(fmtDate(m["Date"]))}</td><td>${esc(m["Product"])}<div class="small muted">${esc(m["Note"] || "")}</div></td><td>${Number(m["Quantity"]) > 0 ? "+" : ""}${esc(m["Quantity"])} ${esc(m["Unit"] || "")}<div class="small muted">bal ${esc(m["Balance After"])}</div></td><td class="hide-m">${m["Job ID"] ? `<a href="#/jobs/${esc(m["Job ID"])}">${esc(m["Job Title"] || m["Job ID"])}</a>` : esc(m["Site / Client"] || m["Type"])}</td><td class="hide-m">${esc(m["By"] || "")}</td></tr>`).join("")}</tbody></table>` : `<p class="empty">No movements yet. They appear here when a Job log uses a chemical or you add stock.</p>`}</div>`;
  $("#chemBody").querySelectorAll("[data-edit]").forEach(b => b.addEventListener("click", () => editProduct(v, active[Number(b.dataset.edit)])));
  $("#chemBody").querySelectorAll("[data-stock]").forEach(b => b.addEventListener("click", () => stockMove(v, b.dataset.stock)));
  $("#printSds").addEventListener("click", () => location.hash = "#/registers/sds");
  $("#printManifest").addEventListener("click", () => location.hash = "#/registers/manifest");
  $("#editManifest").addEventListener("click", () => editSettings(v, settings));
}
function sdsRegisterHtml(products, blank) {
  const rows = blank ? Array.from({ length: 22 }, () => `<tr><td>&nbsp;</td><td></td><td></td><td></td></tr>`) : products.map(p => `<tr><td>${esc(p["Product Name"])}</td><td>${esc(p["Manufacturer / Supplier"] || "")}</td><td>${esc(fmtDate(p["SDS Issue Date"]))}</td><td>${p["SDS Link"] ? `<a href="${esc(p["SDS Link"])}">${esc(p["SDS Link"]).slice(0, 60)}</a>` : ""}</td></tr>`);
  return `<table><thead><tr><th>Product Name</th><th>Manufacturer / Supplier</th><th>SDS issued</th><th>SDS location / link</th></tr></thead><tbody>${rows.join("")}</tbody></table>`;
}
function manifestHtml(products, st, blank) {
  const head = `<p><strong>Business Name:</strong> ${esc(st["Business Name"] || "")}<br><strong>Vehicle Registration:</strong> ${esc(st["Vehicle Registration"] || "")}<br><strong>Vehicle Description:</strong> ${esc(st["Vehicle Description"] || "")}<br><strong>Responsible Person:</strong> ${esc(st["Responsible Person"] || "")}<br><strong>Emergency Contact Number:</strong> ${esc(st["Emergency Contact Number"] || "")}</p>`;
  const def = st["Manifest Storage Default"] || "";
  const rows = blank ? Array.from({ length: 8 }, () => `<tr><td>&nbsp;</td><td></td><td></td><td>${esc(def)}</td></tr>`) : products.map(p => `<tr><td>${esc(p["Product Name"])}<br><span class="sm">${esc(p["Active Constituent"] || "")}${p["Poison Schedule"] ? ", " + esc(p["Poison Schedule"]) : ""}${p["UN Number"] ? ", UN " + esc(p["UN Number"]) : ""}</span></td><td>${esc(p["DG Class"] || "")}</td><td>${esc(qty(p))}</td><td>${esc(p["Storage Location"] || def)}</td></tr>`);
  return head + `<table><thead><tr><th>Product Name</th><th>DG Class</th><th>Qty Onboard</th><th>Storage Location</th></tr></thead><tbody>${rows.join("")}</tbody></table>
    <h3>Emergency Information</h3><p>Poisons Information Centre: 13 11 26<br>Fire/Police/Ambulance: 000<br>Spill Kit Location: ${esc(st["Spill Kit Location"] || "")}<br>Fire Extinguisher: ${esc(st["Fire Extinguisher"] || "")}</p>`;
}
// Opens a print view with the Terana header. Print to PDF from the browser dialog.
function printDoc(title, bodyHtml, opts) {
  opts = opts || {};
  const w = window.open("", "_blank");
  if (!w) { toast("Allow pop-ups to print.", true); return; }
  const base = u => new URL(u, location.href).href;
  w.document.write(`<!DOCTYPE html><html lang="en-AU"><head><meta charset="utf-8"><title>${esc(title)}</title><style>
    @font-face{font-family:"Work Sans";src:url(${base("work-sans-400.woff")}) format("woff");font-weight:400}@font-face{font-family:"Work Sans";src:url(${base("work-sans-600.woff")}) format("woff");font-weight:600}
    body{font-family:"Work Sans",Arial,sans-serif;color:#000;margin:0;padding:28px 32px;font-size:11pt;line-height:1.4}
    .hdr{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:22px}.hdr img{height:70px}.hdr h1{font-size:16pt;font-weight:600;margin:14px 0 0}
    table{width:100%;border-collapse:collapse;margin:12px 0}th,td{border:1px solid #000;padding:7px 8px;text-align:left;vertical-align:top;font-size:10pt}th{font-weight:600}
    .sm{font-size:9pt;color:#444}h3{font-size:11pt;margin:18px 0 4px}a{color:#000}
    .foot{margin-top:26px;font-size:9pt;color:#444}@media print{body{padding:0}}
  </style></head><body><div class="hdr"><h1>${esc(title)}</h1><img src="${base("terana-logo.png")}" alt="Terana Environmental"></div>${bodyHtml}
  <p class="foot">Terana Environmental Pty Ltd. ${opts.noDate ? "" : "Printed " + esc(new Date().toLocaleDateString("en-AU")) + "."}</p>
  <script>window.addEventListener("load",function(){setTimeout(function(){window.print()},300)})<\/script></body></html>`);
  w.document.close();
}
function editSettings(v, st) {
  const keys = ["Business Name", "Vehicle Registration", "Vehicle Description", "Responsible Person", "Emergency Contact Number", "Spill Kit Location", "Fire Extinguisher", "Manifest Storage Default"];
  const dlg = document.createElement("div"); dlg.className = "modal";
  dlg.innerHTML = `<form class="modal-card" id="setForm"><h2>Manifest details</h2>${keys.map((k, i) => `<label for="st${i}">${esc(k === "Manifest Storage Default" ? "Storage location (default)" : k)}</label><input id="st${i}" value="${esc(st[k] || "")}">`).join("")}
    <div class="form-actions"><button class="btn btn-primary" type="submit" id="stSave">Save</button><button class="btn btn-quiet" type="button" id="stCancel">Cancel</button></div></form>`;
  document.body.appendChild(dlg);
  dlg.querySelector("#stCancel").addEventListener("click", () => dlg.remove());
  dlg.querySelector("#setForm").addEventListener("submit", async ev => {
    ev.preventDefault(); dlg.querySelector("#stSave").disabled = true;
    const settings = {}; keys.forEach((k, i) => settings[k] = dlg.querySelector("#st" + i).value.trim());
    try { await api("saveSettings", { settings }); dlg.remove(); toast("Saved"); renderChemicals(v); } catch (err) { toast(err.message, true); dlg.querySelector("#stSave").disabled = false; }
  });
}
function stockMove(v, productName) {
  const products = ((state.chem || {}).products || []).filter(p => String(p["Status"] || "In use") !== "Retired");
  const dlg = document.createElement("div"); dlg.className = "modal";
  dlg.innerHTML = `<form class="modal-card" id="mvForm"><h2>Stock movement</h2>
    <label for="mvProduct">Product</label><select id="mvProduct" required>${option(products.map(p => p["Product Name"]), productName, "Choose")}</select>
    <label for="mvType">What happened</label><select id="mvType">${option(["Purchased", "Used", "Disposed", "Stocktake correction"], "Purchased")}</select>
    <div class="form" style="gap:0 12px"><div><label for="mvPacks">Packs <span class="muted small" id="mvPackHint"></span></label><input id="mvPacks" type="number" step="any" placeholder="e.g. 3"></div><div><label for="mvQty">Or amount <span class="muted small" id="mvUnit"></span></label><input id="mvQty" type="number" step="any" placeholder="e.g. 500"></div></div>
    <label for="mvDate">Date</label><input id="mvDate" type="date" value="${todayISO()}">
    <p class="small muted" id="mvHint">Purchases add to stock. Used and disposed take away. A stocktake correction is signed: type -2 to take 2 off.</p>
    <label for="mvNote">Note</label><input id="mvNote" placeholder="Supplier, batch, reason">
    <div class="form-actions"><button class="btn btn-primary" type="submit" id="mvSave">Save</button><button class="btn btn-quiet" type="button" id="mvCancel">Cancel</button></div></form>`;
  document.body.appendChild(dlg);
  const unitFor = () => { const p = products.find(x => x["Product Name"] === dlg.querySelector("#mvProduct").value); dlg.querySelector("#mvUnit").textContent = p ? "(" + (p["Unit"] || "units") + ", on hand " + qty(p) + ")" : ""; dlg.querySelector("#mvPackHint").textContent = p && p["Pack Size"] ? "(" + p["Pack Size"] + " " + (p["Unit"] || "") + " each)" : "(no pack size set)"; };
  unitFor(); dlg.querySelector("#mvProduct").addEventListener("change", unitFor);
  dlg.querySelector("#mvCancel").addEventListener("click", () => dlg.remove());
  dlg.querySelector("#mvForm").addEventListener("submit", async ev => {
    ev.preventDefault(); dlg.querySelector("#mvSave").disabled = true;
    const t = dlg.querySelector("#mvType").value;
    const p = products.find(x => x["Product Name"] === dlg.querySelector("#mvProduct").value) || {};
    const packs = dlg.querySelector("#mvPacks").value, amt = dlg.querySelector("#mvQty").value;
    const quantity = amt !== "" ? amt : (packs !== "" && Number(p["Pack Size"]) ? String(Number(packs) * Number(p["Pack Size"])) : "");
    if (quantity === "") { toast("Enter packs or an amount.", true); dlg.querySelector("#mvSave").disabled = false; return; }
    const move = { product: p["Product Name"], type: t === "Stocktake correction" ? "Adjusted" : t, quantity, date: dlg.querySelector("#mvDate").value, note: (packs !== "" && amt === "" ? packs + " x " + p["Pack Size"] + " " + (p["Unit"] || "") + ". " : "") + dlg.querySelector("#mvNote").value.trim() };
    try { const out = await api("stockMove", { move }); dlg.remove(); toast("Stock now " + out.balance + " " + (out.unit || "")); renderChemicals(v); } catch (err) { toast(err.message, true); dlg.querySelector("#mvSave").disabled = false; }
  });
}
function editProduct(v, p) {
  const d = p || {};
  const dlg = document.createElement("div"); dlg.className = "modal";
  dlg.innerHTML = `<form class="modal-card" id="prodForm"><h2>${p ? "Edit product" : "Add product"}</h2>
    <label for="xName">Product name</label><input id="xName" required value="${esc(d["Product Name"] || "")}">
    <div class="form" style="gap:0 12px"><div><label for="xActive">Active constituent</label><input id="xActive" value="${esc(d["Active Constituent"] || "")}"></div><div><label for="xSupp">Manufacturer / supplier</label><input id="xSupp" value="${esc(d["Manufacturer / Supplier"] || "")}"></div></div>
    <div class="form" style="gap:0 12px"><div><label for="xSched">Poison schedule</label><select id="xSched">${option(["", "S5", "S6", "S7", "Unscheduled"], d["Poison Schedule"] || "")}</select></div><div><label for="xApvma">APVMA code</label><input id="xApvma" value="${esc(d["APVMA Number"] || "")}"></div></div>
    <label for="xSds">SDS link (Drive or supplier)</label><input id="xSds" value="${esc(d["SDS Link"] || "")}">
    <div class="form" style="gap:0 12px"><div><label for="xSdsDate">SDS issue date</label><input id="xSdsDate" type="date" value="${esc(String(d["SDS Issue Date"] || "").slice(0, 10))}"></div><div><label for="xDg">DG class</label><input id="xDg" value="${esc(d["DG Class"] || "")}" placeholder="e.g. 6.1"></div></div>
    <div class="form" style="gap:0 12px"><div><label for="xUn">UN number</label><input id="xUn" value="${esc(d["UN Number"] || "")}"></div><div><label for="xLoc">Storage location</label><input id="xLoc" value="${esc(d["Storage Location"] || "")}" placeholder="Leave blank for the vehicle cabinet"></div></div>
    <div class="form" style="gap:0 12px"><div><label for="xUnit">Unit it is measured in</label><input id="xUnit" value="${esc(d["Unit"] || "")}" placeholder="g, kg, mL, L"></div><div><label for="xPack">Pack size (per tub, bottle or bag)</label><input id="xPack" type="number" step="any" min="0" value="${esc(d["Pack Size"] ?? "")}" placeholder="e.g. 50"></div></div>
    <div class="form" style="gap:0 12px"><div><label for="xPacks">Packs on hand</label><input id="xPacks" type="number" step="any" min="0" value="${esc(d["Pack Size"] && d["Quantity On Hand"] !== "" ? Math.round(Number(d["Quantity On Hand"]) / Number(d["Pack Size"]) * 100) / 100 : "")}" placeholder="e.g. 3"></div><div><label for="xQty">Total on hand <span class="muted small" id="xQtyHint"></span></label><input id="xQty" type="number" step="any" min="0" value="${esc(d["Quantity On Hand"] ?? "")}"></div></div>
    <p class="small muted">Give a pack size and packs on hand and the total works itself out. Usage in the Job log comes off the total, so 3 tubs of 50 g minus 20 g shows as 2 x 50 g plus 30 g open.</p>
    <label for="xStatus">Status</label><select id="xStatus">${option(["In use", "Retired"], d["Status"] || "In use")}</select>
    <label for="xNotes">Notes (usage is added here automatically)</label><textarea id="xNotes">${esc(d["Notes"] || "")}</textarea>
    <div class="form-actions"><button class="btn btn-primary" type="submit" id="xSave">Save</button><button class="btn btn-quiet" type="button" id="xCancel">Cancel</button><span class="spacer"></span>${p ? `<button class="btn btn-danger btn-sm" type="button" id="xDelete">Delete product</button>` : ""}</div></form>`;
  document.body.appendChild(dlg);
  if (p) dlg.querySelector("#xDelete").addEventListener("click", async () => {
    if (!confirm("Delete " + d["Product Name"] + " from the register and manifest? Past usage records are kept. Retire it instead if you might buy it again.")) return;
    try { await api("deleteProduct", { productName: d["Product Name"] }); dlg.remove(); toast("Product deleted"); renderChemicals(v); } catch (err) { toast(err.message, true); }
  });
  const recalc = () => { const ps = Number($("#xPack").value), pk = $("#xPacks").value; if (ps && pk !== "") $("#xQty").value = Math.round(ps * Number(pk) * 1000) / 1000; $("#xQtyHint").textContent = $("#xUnit").value ? "(" + $("#xUnit").value + ")" : ""; };
  ["#xPack", "#xPacks", "#xUnit"].forEach(id => dlg.querySelector(id).addEventListener("input", recalc)); recalc();
  dlg.querySelector("#xCancel").addEventListener("click", () => dlg.remove());
  dlg.querySelector("#prodForm").addEventListener("submit", async ev => {
    ev.preventDefault(); const btn = dlg.querySelector("#xSave"); btn.disabled = true;
    try {
      const product = { "Original Name": d["Product Name"] || "", "Product Name": $("#xName").value.trim(), "Active Constituent": $("#xActive").value.trim(), "Manufacturer / Supplier": $("#xSupp").value.trim(), "Poison Schedule": $("#xSched").value, "APVMA Number": $("#xApvma").value.trim(), "SDS Link": $("#xSds").value.trim(), "SDS Issue Date": $("#xSdsDate").value, "DG Class": $("#xDg").value.trim(), "UN Number": $("#xUn").value.trim(), "Storage Location": $("#xLoc").value.trim(), "Quantity On Hand": $("#xQty").value, "Unit": $("#xUnit").value.trim(), "Pack Size": $("#xPack").value, "Status": $("#xStatus").value, "Notes": $("#xNotes").value };
      await api("saveProduct", { product }); dlg.remove(); toast("Product saved"); renderChemicals(v);
    } catch (err) { toast(err.message, true); btn.disabled = false; }
  });
}

/* ---------- team: register of employees ---------- */
const EMP_FIELDS = ["Name", "Role", "Status", "Residential Address", "Date Of Birth", "Phone", "Email", "LPMP Licence Number", "Licence Expiry", "Firearms Licence Number", "Firearms Licence Expiry", "Firearms Authorised", "Date Start of Employment", "Date End of Employment", "Notes"];
function renderTeam(v) {
  v.innerHTML = `<div class="page-head"><div><h1>Team</h1><p class="muted">Register of employees, licences and firearms authorisations. From the Technicians tab.</p></div><div class="btnrow"><button class="btn btn-primary" id="newEmp">Add person</button> <button class="btn" id="printEmp">View / print register</button></div></div><p class="muted" id="empLoading">Loading.</p><div id="empBody"></div>`;
  api("listEmployees").then(out => drawTeam(v, out.employees || [])).catch(err => { $("#empLoading").textContent = err.message; });
  $("#newEmp").addEventListener("click", () => editEmployee(v, null));
}
function expiryTag(d) {
  const s = String(d || "").slice(0, 10); if (!s) return "";
  const days = (new Date(s + "T00:00:00").getTime() - Date.now()) / 86400000;
  if (days < 0) return `<span class="tag bad">Expired ${esc(fmtDate(s))}</span>`;
  if (days < 60) return `<span class="tag warn">Expires ${esc(fmtDate(s))}</span>`;
  return `<span class="tag ok">To ${esc(fmtDate(s))}</span>`;
}
function drawTeam(v, emps) {
  $("#empLoading").hidden = true;
  const current = emps.filter(e => !e["Date End of Employment"]), past = emps.filter(e => e["Date End of Employment"]);
  const row = (e, i) => `<tr><td><strong>${esc(e["Name"])}</strong><div class="small muted">${esc(e["Role"] || "")}${e["Phone"] ? ", " + esc(e["Phone"]) : ""}</div></td>
    <td>${e["LPMP Licence Number"] ? esc(e["LPMP Licence Number"]) + " " + expiryTag(e["Licence Expiry"]) : `<span class="muted">Not licensed</span>`}</td>
    <td class="hide-m">${/^y/i.test(e["Firearms Authorised"] || "") && e["Firearms Licence Number"] ? esc(e["Firearms Licence Number"]) + " " + expiryTag(e["Firearms Licence Expiry"]) : `<span class="muted">Not authorised</span>`}</td>
    <td class="hide-m">${esc(fmtDate(e["Date Start of Employment"]))}${e["Date End of Employment"] ? " to " + esc(fmtDate(e["Date End of Employment"])) : ""}</td>
    <td class="right"><button type="button" class="btn btn-sm btn-quiet" data-emp="${i}">Edit</button></td></tr>`;
  $("#empBody").innerHTML = `<div class="card">${emps.length ? `<table class="tbl"><thead><tr><th>Name</th><th>LPMT number</th><th class="hide-m">Firearms authorised person</th><th class="hide-m">Employed</th><th></th></tr></thead><tbody>${current.map((e) => row(e, emps.indexOf(e))).join("")}</tbody></table>` : `<p class="empty">Nobody yet. Add a person.</p>`}
    ${past.length ? `<h3 style="margin-top:1.2em">Former employees</h3><table class="tbl"><tbody>${past.map(e => row(e, emps.indexOf(e))).join("")}</tbody></table>` : ""}
    <p class="small muted" style="margin-top:10px">Only current employees appear in the field form dropdowns. Only authorised persons with a licence number appear in the firearm log.</p></div>`;
  $("#empBody").querySelectorAll("[data-emp]").forEach(b => b.addEventListener("click", () => editEmployee(v, emps[Number(b.dataset.emp)])));
  $("#printEmp").onclick = () => location.hash = "#/registers/employees";
}
function employeesHtml(emps, blank) {
  const rows = blank ? Array.from({ length: 20 }, () => `<tr><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td></tr>`) : emps.map(e => `<tr><td>${esc(e["Name"])}</td><td>${esc(e["Residential Address"] || "")}</td><td>${esc(fmtDate(e["Date Of Birth"]))}</td><td>${e["LPMP Licence Number"] ? "LPMT " + esc(e["LPMP Licence Number"]) : ""}${e["Firearms Licence Number"] ? (e["LPMP Licence Number"] ? "<br>" : "") + "Firearms " + esc(e["Firearms Licence Number"]) : ""}</td><td>${esc(fmtDate(e["Date Start of Employment"]))}</td><td>${esc(fmtDate(e["Date End of Employment"]))}</td></tr>`);
  return `<table><thead><tr><th>Employee Full Name</th><th>Residential Address</th><th>Date Of Birth</th><th>Licence Number</th><th>Date Start of Employment</th><th>Date End of Employment</th></tr></thead><tbody>${rows.join("")}</tbody></table>`;
}
function editEmployee(v, e) {
  const d = e || {};
  const dlg = document.createElement("div"); dlg.className = "modal";
  const id = k => "e_" + k.replace(/\W/g, "");
  const f = (k, type, extra, label) => `<label for="${id(k)}">${esc(label || k)}</label>${type === "select" ? `<select id="${id(k)}">${option(extra, d[k] || extra[0])}</select>` : type === "textarea" ? `<textarea id="${id(k)}">${esc(d[k] || "")}</textarea>` : `<input id="${id(k)}" type="${type || "text"}" value="${esc(type === "date" ? String(d[k] || "").slice(0, 10) : d[k] || "")}">`}`;
  const hasLpmt = !!d["LPMP Licence Number"], hasFa = /^y/i.test(d["Firearms Authorised"] || "") || !!d["Firearms Licence Number"];
  dlg.innerHTML = `<form class="modal-card" id="empForm"><h2>${e ? "Edit person" : "Add person"}</h2>
    ${f("Name")}<div class="form" style="gap:0 12px"><div>${f("Role")}</div><div>${f("Status", "select", ["Employee", "Contractor", "Trainee", "Admin"])}</div></div>
    ${f("Residential Address")}<div class="form" style="gap:0 12px"><div>${f("Date Of Birth", "date")}</div><div>${f("Phone", "tel")}</div></div>${f("Email", "email")}
    <label class="check"><input type="checkbox" id="eLpmt" ${hasLpmt ? "checked" : ""}> Licensed pest management technician (LPMT)</label>
    <div id="lpmtBox" class="subfields" ${hasLpmt ? "" : "hidden"}><div class="form" style="gap:0 12px"><div>${f("LPMP Licence Number", "text", null, "LPMT number")}</div><div>${f("Licence Expiry", "date", null, "LPMT expiry")}</div></div></div>
    <label class="check"><input type="checkbox" id="eFa" ${hasFa ? "checked" : ""}> Authorised person on the firearms Business Licence</label>
    <div id="faBox" class="subfields" ${hasFa ? "" : "hidden"}><div class="form" style="gap:0 12px"><div>${f("Firearms Licence Number", "text", null, "Firearms licence number")}</div><div>${f("Firearms Licence Expiry", "date", null, "Firearms licence expiry")}</div></div></div>
    <div class="form" style="gap:0 12px"><div>${f("Date Start of Employment", "date", null, "Employment start")}</div><div>${f("Date End of Employment", "date", null, "Employment end")}</div></div>${f("Notes", "textarea")}
    <div class="form-actions"><button class="btn btn-primary" type="submit" id="eSave">Save</button><button class="btn btn-quiet" type="button" id="eCancel">Cancel</button></div></form>`;
  document.body.appendChild(dlg);
  const wire = (cb, box, field) => { const toggle = () => { dlg.querySelector(box).hidden = !dlg.querySelector(cb).checked; dlg.querySelector(field).required = dlg.querySelector(cb).checked; }; dlg.querySelector(cb).addEventListener("change", toggle); toggle(); };
  wire("#eLpmt", "#lpmtBox", "#" + id("LPMP Licence Number")); wire("#eFa", "#faBox", "#" + id("Firearms Licence Number"));
  dlg.querySelector("#eCancel").addEventListener("click", () => dlg.remove());
  dlg.querySelector("#empForm").addEventListener("submit", async ev => {
    ev.preventDefault(); dlg.querySelector("#eSave").disabled = true;
    const employee = { "Original Name": d["Name"] || "" };
    EMP_FIELDS.forEach(k => { if (k !== "Firearms Authorised") employee[k] = dlg.querySelector("#" + id(k)).value.trim(); });
    if (!dlg.querySelector("#eLpmt").checked) { employee["LPMP Licence Number"] = ""; employee["Licence Expiry"] = ""; }
    if (!dlg.querySelector("#eFa").checked) { employee["Firearms Licence Number"] = ""; employee["Firearms Licence Expiry"] = ""; }
    employee["Firearms Authorised"] = dlg.querySelector("#eFa").checked ? "Yes" : "No";
    try { await api("saveEmployee", { employee }); dlg.remove(); toast("Saved"); renderTeam(v); } catch (err) { toast(err.message, true); dlg.querySelector("#eSave").disabled = false; }
  });
}

/* ---------- documents: policies, procedures and forms ---------- */
const BUILT_IN_DOCS = [
  { title: "Chemical manifest", cat: "Registers", desc: "Vehicle, responsible person, products on board by DG class and storage. Live from the Chemicals page.", open: "#/registers/manifest", blank: "manifest" },
  { title: "SDS register", cat: "Registers", desc: "Product, supplier, SDS date and link. Live from the Chemicals page.", open: "#/registers/sds", blank: "sds" },
  { title: "Register of employees", cat: "Registers", desc: "Name, address, date of birth, licence numbers, employment dates. Live from the Team page.", open: "#/registers/employees", blank: "employees" },
  { title: "Job log", cat: "Forms", desc: "Site visit record: pesticide, firearm, trapping, other work. Fill on the phone.", open: "pest-report.html" },
  { title: "Field survey", cat: "Forms", desc: "Den sites, fauna, weeds and other observations with GPS and photos. Fill on the phone.", open: "field-report.html" },
  { title: "Firearm log", cat: "Forms", desc: "Withdrawal and return register. Fill on the phone.", open: "firearm-log.html" },
  { title: "Firearm use permission", cat: "Forms", desc: "Landholder permission to use firearms, with map and signature. Pick the job it belongs to.", pick: "permission" },
  { title: "Forms to sign", cat: "Forms", desc: "Letter of engagement, site screening or any document the client signs. Pick the job.", pick: "sign" }
];
function renderDocuments(v) {
  v.innerHTML = `<div class="page-head"><div><h1>Documents</h1><p class="muted">Registers and forms. Safety documents (SWMS, procedures, emergency plan) are under <a href="#/sms">SMS</a>.</p></div><div><button class="btn btn-primary" id="newDoc">Add a document link</button></div></div><div id="docBody"></div>`;
  const draw = (extra) => {
    const cats = ["Registers", "Forms", "Policies and procedures"];
    extra = extra.filter(d => d["Category"] !== "SMS");
    const all = BUILT_IN_DOCS.concat(extra.map(d => ({ title: d["Title"], cat: d["Category"] || "Policies and procedures", desc: [d["Version"] ? "Version " + d["Version"] : "", d["Review Date"] ? "Review " + fmtDate(d["Review Date"]) : "", d["Notes"] || ""].filter(Boolean).join(". "), open: d["Link"], rec: d })));
    extra.forEach(d => { if (d["Category"] && !cats.includes(d["Category"])) cats.push(d["Category"]); });
    $("#docBody").innerHTML = cats.map(c => { const items = all.filter(d => d.cat === c); return items.length ? `<h2 class="sect">${esc(c)}</h2><div class="tools">${items.map((d, i) => `<div class="tool doc"><h3>${esc(d.title)}</h3><p>${esc(d.desc || "")}</p><div class="btnrow">${d.open ? `<a class="btn btn-sm" href="${esc(d.open)}" ${/^(https?:|docs\/)/.test(d.open) ? 'target="_blank" rel="noopener"' : ""}>${d.cat === "Forms" ? "Fill on phone" : d.cat === "Registers" ? "Open live" : "Open"}</a>` : ""}${d.pick ? `<button type="button" class="btn btn-sm" data-pick="${d.pick}">Fill on phone</button>` : ""}${d.print ? `<button type="button" class="btn btn-sm" data-print="${d.print}">Print filled</button>` : ""}${d.blank ? `<a class="btn btn-sm btn-quiet" href="#/registers/${d.blank}?blank=1">Blank hard copy</a>` : ""}${d.rec ? `<button type="button" class="btn btn-sm btn-quiet" data-editdoc="${esc(d.rec["Title"])}">Edit</button>` : ""}</div></div>`).join("")}</div>` : ""; }).join("");
    $("#docBody").querySelectorAll("[data-print]").forEach(b => b.addEventListener("click", () => printRegister(b.dataset.print, false)));
    $("#docBody").querySelectorAll("[data-pick]").forEach(b => b.addEventListener("click", () => pickJob(b.dataset.pick)));
    $("#docBody").querySelectorAll("[data-blank]").forEach(b => b.addEventListener("click", () => printRegister(b.dataset.blank, true)));
    $("#docBody").querySelectorAll("[data-editdoc]").forEach(b => b.addEventListener("click", () => editDocument(v, extra.find(d => d["Title"] === b.dataset.editdoc))));
  };
  draw([]);
  api("listDocuments").then(out => draw(out.documents || [])).catch(err => toast(err.message, true));
  $("#newDoc").addEventListener("click", () => editDocument(v, null));
}
const REGISTER_TITLES = { manifest: "Chemical Manifest", sds: "SDS Register", employees: "Register of Employees" };
function renderRegister(v, which) {
  const blank = state.query.get("blank") === "1";
  const title = REGISTER_TITLES[which] || "Register";
  v.innerHTML = `<div class="page-head noprint"><div><p class="muted small"><a href="#/documents">Documents</a> / ${esc(title)}</p><h1>${esc(title)}${blank ? " (blank)" : ""}</h1></div><div class="btnrow"><button class="btn btn-primary" id="regPrint">Print / PDF</button>${which !== "employees" ? `<a class="btn" href="#/chemicals">Edit in Chemicals</a>` : `<a class="btn" href="#/team">Edit in Team</a>`}</div></div><div class="regdoc"><div class="reghead"><h2>${esc(title)}</h2><img src="logo.png" alt="Terana Environmental"></div><div id="regBody"><p class="muted">Loading.</p></div><p class="small muted regfoot">Terana Environmental Pty Ltd. ${blank ? "" : "Printed " + esc(new Date().toLocaleDateString("en-AU")) + "."}</p></div>`;
  $("#regPrint").addEventListener("click", () => window.print());
  (async () => {
    try {
      let html = "";
      if (which === "employees") { const out = blank ? { employees: [] } : await api("listEmployees"); html = employeesHtml(out.employees || [], blank); }
      else { const out = blank ? { products: [], settings: (state.chem || {}).settings || {} } : await api("listProducts"); if (!blank) state.chem = out; const active = (out.products || []).filter(p => String(p["Status"] || "In use") !== "Retired"); html = which === "sds" ? sdsRegisterHtml(active, blank) : manifestHtml(active, out.settings || {}, blank); }
      $("#regBody").innerHTML = html;
    } catch (err) { $("#regBody").innerHTML = `<p class="form-error">${esc(err.message)}</p>`; }
  })();
}
function pickJob(sub) {
  const jobs = state.jobs.filter(j => !["Cancelled", "Invoiced", "Completed"].includes(j["Status"])).sort((a, b) => String(b["Updated"]).localeCompare(String(a["Updated"])));
  const dlg = document.createElement("div"); dlg.className = "modal";
  dlg.innerHTML = `<div class="modal-card"><h2>Which job?</h2>${jobs.length ? `<div class="picklist">${jobs.map(j => `<a href="#/jobs/${esc(j["Job ID"])}/${sub}"><strong>${esc(j["Title"])}</strong><span class="small muted">${esc(j["Client Name"] || "")}${j["Site Address"] ? ", " + esc(j["Site Address"]) : ""}</span></a>`).join("")}</div>` : `<p class="empty">No open jobs. <a href="#/jobs/new">Create one</a> first.</p>`}<div class="form-actions"><button class="btn btn-quiet" type="button" id="pkCancel">Cancel</button></div></div>`;
  document.body.appendChild(dlg);
  dlg.querySelector("#pkCancel").addEventListener("click", () => dlg.remove());
  dlg.querySelectorAll("a").forEach(a => a.addEventListener("click", () => dlg.remove()));
}
async function printRegister(which, blank) {
  try {
    if (which === "employees") { const out = blank ? { employees: [] } : await api("listEmployees"); printDoc("Register of Employees", employeesHtml(out.employees || [], blank), { noDate: blank }); return; }
    const out = blank ? { products: [], settings: (state.chem || {}).settings || {} } : await api("listProducts");
    const active = (out.products || []).filter(p => String(p["Status"] || "In use") !== "Retired");
    if (which === "sds") printDoc("SDS Register", sdsRegisterHtml(active, blank), { noDate: blank });
    else printDoc("Chemical Manifest", manifestHtml(active, out.settings || {}, blank), { noDate: blank });
  } catch (err) { toast(err.message, true); }
}
function editDocument(v, d) {
  d = d || {};
  const dlg = document.createElement("div"); dlg.className = "modal";
  dlg.innerHTML = `<form class="modal-card" id="docForm"><h2>${d["Title"] ? "Edit document" : "Add a document link"}</h2>
    <label for="dTitle">Title</label><input id="dTitle" required value="${esc(d["Title"] || "")}">
    <label for="dCat">Category</label><select id="dCat">${option(["Policies and procedures", "Registers", "Forms", "Licences and insurance", "Training"], d["Category"] || "Policies and procedures")}</select>
    <label for="dLink">Link (Drive, website or PDF)</label><input id="dLink" type="url" value="${esc(d["Link"] || "")}">
    <div class="form" style="gap:0 12px"><div><label for="dVer">Version</label><input id="dVer" value="${esc(d["Version"] || "")}"></div><div><label for="dRev">Review date</label><input id="dRev" type="date" value="${esc(String(d["Review Date"] || "").slice(0, 10))}"></div></div>
    <label for="dNotes">Notes</label><textarea id="dNotes">${esc(d["Notes"] || "")}</textarea>
    <div class="form-actions"><button class="btn btn-primary" type="submit" id="dSave">Save</button><button class="btn btn-quiet" type="button" id="dCancel">Cancel</button></div></form>`;
  document.body.appendChild(dlg);
  dlg.querySelector("#dCancel").addEventListener("click", () => dlg.remove());
  dlg.querySelector("#docForm").addEventListener("submit", async ev => {
    ev.preventDefault(); dlg.querySelector("#dSave").disabled = true;
    const document_ = { "Original Title": d["Title"] || "", "Title": $("#dTitle").value.trim(), "Category": $("#dCat").value, "Link": $("#dLink").value.trim(), "Version": $("#dVer").value.trim(), "Review Date": $("#dRev").value, "Notes": $("#dNotes").value.trim() };
    try { await api("saveDocument", { document: document_ }); dlg.remove(); toast("Saved"); renderDocuments(v); } catch (err) { toast(err.message, true); dlg.querySelector("#dSave").disabled = false; }
  });
}

/* ---------- documents for signature ---------- */
const SIGN_TEMPLATES = {
  "Letter of engagement": { title: "Letter of engagement: {job}", body: `Terana Environmental Pty Ltd (Terana) confirms its engagement by {client} to carry out {service} at {site}.

## Scope of work
{description}

## Fees
Fees are set out in the schedule below. Amounts are ex GST unless stated. All jobs carry a 3 hour minimum charge. Time on site is charged at the hourly rates listed; materials are charged at cost plus 30%; travel is charged as time door to door plus vehicle kilometres, return from Fremantle. Work outside this scope is quoted before it starts.

## Terms
- Invoices are issued on completion of each stage and are payable within 14 days.
- The client provides safe access to the site and tells Terana about hazards, other contractors, animals and people on site before work starts.
- Terana holds the licences and insurance required for this work and carries it out in line with WA legislation and product labels.
- Either party may end the engagement with 7 days written notice. Work completed to that date is payable.

By signing, the client accepts this engagement and the schedule of fees.`, fees: true },
  "Client intake": { title: "Tell us about the problem: {site}", body: `Thanks for getting in touch with Terana Environmental. The more you can tell us here, the better we can plan the first visit and quote accurately. Short answers are fine.

## The problem
? What animals or pests are causing the problem, and how do you know (sightings, tracks, scats, damage, noise)?
? How long has it been going on, and is it getting worse, better or staying the same?
? Where exactly is the problem? Sheds, paddocks, crops, buildings, roofs, waterways, bush. Describe the areas or name them.
? Roughly how big is the area affected (hectares, number of sheds, length of fence line)?

## Impact
? What damage or losses are you seeing? Lost crops or stock, fouled feed or product, structural damage, contamination, erosion.
? Rough cost of the damage so far, if you can estimate it.
? Any health, hygiene or safety concerns? Disease risk, droppings in food areas, public or staff exposure, bites, vehicle strikes.
? Any neighbours, public areas, schools or environmental sites nearby that we need to consider?

## What has been tried
? What has been done about it before (baits, traps, shooting, deterrents, fencing, a previous contractor)? What worked and what didn't?
? Any products, baits or chemicals used on the property in the last 12 months?

## The site
? Domestic animals, working dogs, livestock or poultry on site?
? Who else uses the site (staff, contractors, tenants, the public), and when?
? Access: gates, keys, locked areas, best times to visit, anyone we should check in with on arrival.
? Known hazards: power lines, machinery, chemicals, uneven ground, water, dams.
? Any timing constraints? Harvest, lambing, events, planned works.

## Acknowledgement
The information above is accurate to the best of my knowledge. I will tell Terana if anything changes.`, fees: false },
  "Site screening": { title: "Site screening: {site}", body: `Site: {site}
Client: {client}
Job: {job}

## Information provided by the client
? Target species or issue
? Domestic animals or livestock on site
? Other people, contractors or public access
? Water courses, drains or neighbouring land of concern
? Known hazards (chemicals, power, machinery, uneven ground)
? Access, gates and keys

## Acknowledgement
The client confirms the information above is accurate and will tell Terana straight away if anything changes. The client agrees to keep people and animals away from treated areas, baits and traps as instructed.`, fees: false },
  "Other": { title: "", body: "", fees: false }
};
function mergeTemplate(text, job, client) {
  const m = { job: job["Title"] || "ongoing pest management", client: client["Name"] || job["Client Name"] || "", service: job["Service"] || "pest and wildlife management services", site: job["Site Address"] || job["Site Name"] || client["Address"] || "the client's properties", description: job["Description"] || "" };
  return String(text || "").replace(/\{(\w+)\}/g, (_, k) => m[k] != null ? m[k] : "");
}
function bodyToHtml(text, answers, editable) {
  const out = []; let para = [], list = []; let qi = 0; answers = answers || {};
  const flushP = () => { if (para.length) { out.push("<p>" + para.map(esc).join("<br>") + "</p>"); para = []; } };
  const flushL = () => { if (list.length) { out.push("<ul>" + list.map(l => "<li>" + esc(l) + "</li>").join("") + "</ul>"); list = []; } };
  String(text || "").split(/\n/).forEach(raw => {
    const l = raw.trim();
    if (!l) { flushP(); flushL(); return; }
    if (/^#+ /.test(l)) { flushP(); flushL(); out.push("<h3>" + esc(l.replace(/^#+ /, "")) + "</h3>"); return; }
    if (/^\? /.test(l)) { flushP(); flushL(); const q = l.replace(/^\? /, ""); const key = "q" + (qi++); out.push(editable ? `<div class="q"><label for="${key}">${esc(q)}</label><textarea id="${key}" data-q="${esc(q)}" rows="2">${esc(answers[q] || "")}</textarea></div>` : `<div class="q"><div class="qq">${esc(q)}</div><div class="qa">${esc(answers[q] || "")}</div></div>`); return; }
    if (/^[-*] /.test(l)) { flushP(); list.push(l.replace(/^[-*] /, "")); return; }
    flushL(); para.push(l);
  });
  flushP(); flushL();
  return out.join("");
}
function collectAnswers(root) { const a = {}; root.querySelectorAll("textarea[data-q]").forEach(t => { if (t.value.trim()) a[t.dataset.q] = t.value.trim(); }); return a; }
function signLink(token) { return new URL("sign.html?t=" + token, location.href).href; }
function renderSign(v, jobId, clientId) {
  const j = jobId ? state.jobs.find(x => x["Job ID"] === jobId) : null;
  if (jobId && !j) { v.innerHTML = `<p class="empty">Job not found.</p>`; return; }
  const c = state.clients.find(x => x["Client ID"] === (j ? j["Client ID"] : clientId)) || {};
  if (!j && !c["Client ID"]) { v.innerHTML = `<p class="empty">Client not found.</p>`; return; }
  const jj = j || {};
  const crumb = j ? `<a href="#/jobs">Jobs</a> / <a href="#/jobs/${esc(jobId)}">${esc(j["Title"])}</a> / Forms to sign` : `<a href="#/clients">Clients</a> / <a href="#/clients/${esc(c["Client ID"])}">${esc(c["Name"])}</a> / Agreements`;
  v.innerHTML = `<div class="page-head"><div><p class="muted small">${crumb}</p><h1>${j ? "Forms to sign" : "Standing agreements"}</h1><p class="muted">${esc(c["Name"] || jj["Client Name"] || "")}. ${j ? "Sign on this phone with the client, or email them a link to sign from anywhere. Signed PDFs file under the client's Drive folder." : "Documents signed here cover every job for this client until they are cancelled: a letter of engagement, firearm use permission, intake. They file under the client's Agreements folder."}</p></div><div><button class="btn btn-primary" id="newSign">New document</button></div></div><p class="muted" id="signLoading">Loading.</p><div id="signList"></div><div id="signForm"></div>`;
  let docs = [], rateCard = [];
  const load = () => api("listSignDocs", j ? { jobId } : { clientId: c["Client ID"] }).then(out => { docs = out.docs || []; rateCard = out.rateCard || []; drawList(); }).catch(err => { $("#signLoading").textContent = err.message; });
  const drawList = () => {
    $("#signLoading").hidden = true;
    const live = docs.filter(d => d["Status"] !== "Void");
    const sp = !j ? (state.permissions || []).find(p => p["Scope"] === "Client" && p["Client ID"] === c["Client ID"] && !["Void", "Cancelled"].includes(p["Status"])) : null;
    const permRow = !j ? `<tr><td><strong>Firearm use permission</strong><div class="small muted">Landholder permission to use firearms on the client's land, with map${sp && sp["Valid To"] ? ", valid to " + esc(fmtDate(sp["Valid To"])) : sp ? ", until revoked" : ""}</div></td><td>${sp ? pill(sp["Status"] || "Draft") + (sp["Status"] === "Signed" ? `<div class="small muted">${esc(sp["Signed By"] || "")}, ${esc(fmtDate(sp["Signed Date"]))}</div>` : "") : `<span class="muted">Not set up</span>`}</td><td class="hide-m">${esc(sp ? sp["Signed By"] || "" : "")}</td><td class="right btnrow" style="justify-content:flex-end"><a class="btn btn-sm" href="#/clients/${esc(c["Client ID"])}/permission">${sp ? "Open" : "Set up"}</a>${sp && sp["PDF URL"] ? `${extLink(sp["PDF URL"], "PDF", "btn btn-sm btn-quiet")}` : ""}</td></tr>` : "";
    $("#signList").innerHTML = `<div class="card">${live.length || permRow ? `<table class="tbl"><thead><tr><th>Document</th><th>Status</th><th class="hide-m">Signer</th><th></th></tr></thead><tbody>${permRow}${live.map((d, i) => `<tr><td><strong>${esc(d["Title"])}</strong><div class="small muted">${esc(d["Type"])}${d["Include Permission"] === "Yes" ? " + firearm use" : ""}${d["Scope"] === "Client" ? ", standing for the client" : ""}, ${esc(fmtDate(d["Created"]))}</div></td><td>${pill(d["Status"])}${d["Status"] === "Signed" ? `<div class="small muted">${esc(d["Signed Name"])}, ${esc(fmtDate(d["Signed Date"]))}</div>` : d["Status"] === "Sent" ? `<div class="small muted">Link sent ${esc(fmtDate(d["Sent Date"]))}</div>` : ""}</td><td class="hide-m">${esc(d["Signer Name"] || "")}<div class="small muted">${esc(d["Signer Email"] || "")}</div></td><td class="right btnrow" style="justify-content:flex-end">${d["Status"] === "Cancelled" ? `${extLink(d["PDF URL"], "PDF (cancelled)", "btn btn-sm btn-quiet")}` : d["Status"] === "Signed" ? `${extLink(d["PDF URL"], "Open PDF", "btn btn-sm")}${d["Scope"] === "Client" ? `<button type="button" class="btn btn-sm btn-quiet" data-cancel="${i}">Cancel agreement</button>` : ""}` : `<button type="button" class="btn btn-sm" data-signnow="${i}">Sign now</button><button type="button" class="btn btn-sm" data-send="${i}">Email link</button><button type="button" class="btn btn-sm btn-quiet" data-copy="${i}">Copy link</button><button type="button" class="btn btn-sm btn-quiet" data-edit="${i}">Edit</button><button type="button" class="btn btn-sm btn-quiet" data-void="${i}">Void</button>`}</td></tr>`).join("")}</tbody></table>` : `<p class="empty">Nothing yet for this job. New document starts a letter of engagement, site screening or anything else that needs a signature.</p>`}</div>`;
    const L = $("#signList");
    L.querySelectorAll("[data-signnow]").forEach(b => b.addEventListener("click", () => signNow(live[Number(b.dataset.signnow)])));
    L.querySelectorAll("[data-send]").forEach(b => b.addEventListener("click", () => sendLink(live[Number(b.dataset.send)])));
    L.querySelectorAll("[data-copy]").forEach(b => b.addEventListener("click", async () => { const d = live[Number(b.dataset.copy)]; try { await navigator.clipboard.writeText(signLink(d["Token"])); toast("Link copied"); } catch (e) { prompt("Copy this link", signLink(d["Token"])); } }));
    L.querySelectorAll("[data-edit]").forEach(b => b.addEventListener("click", () => api("getSignDoc", { signId: live[Number(b.dataset.edit)]["Sign ID"] }).then(out => drawForm(out.doc)).catch(err => toast(err.message, true))));
    L.querySelectorAll("[data-cancel]").forEach(b => b.addEventListener("click", async () => { const d = live[Number(b.dataset.cancel)]; if (!confirm("Cancel " + d["Title"] + "? It stops covering new jobs from today. The signed PDF is kept.")) return; try { await api("cancelSignDoc", { signId: d["Sign ID"] }); toast("Cancelled"); await bootstrap(); load(); } catch (err) { toast(err.message, true); } }));
    L.querySelectorAll("[data-void]").forEach(b => b.addEventListener("click", async () => { const d = live[Number(b.dataset.void)]; if (!confirm("Void " + d["Title"] + "? The link stops working.")) return; try { await api("voidSignDoc", { signId: d["Sign ID"] }); toast("Voided"); load(); } catch (err) { toast(err.message, true); } }));
  };
  const feeRow = (f) => { const known = rateCard.some(r => r["Item"] === f.item); return `<tr><td><select class="fSel">${option(rateCard.map(r => r["Item"]).concat(["Other"]), known ? f.item : (f.item ? "Other" : ""), "Choose")}</select><input class="fItem" value="${esc(f.item || "")}" placeholder="Describe the item" ${known || !f.item ? "hidden" : ""}></td><td><input class="fQty" type="number" step="any" value="${esc(f.qty ?? "")}" placeholder="1"></td><td><input class="fUnit" value="${esc(f.unit || "")}" placeholder="each"></td><td><input class="fRate" type="number" step="any" value="${esc(f.rate ?? "")}" placeholder="0.00"></td><td><input class="fAmt" type="number" step="any" value="${esc(f.amount ?? "")}" placeholder="auto"></td><td><button type="button" class="btn btn-sm btn-quiet fDel">x</button></td></tr>`; };
  const drawForm = (d) => {
    d = d || {}; const t = d["Type"] || "Letter of engagement"; const tpl = SIGN_TEMPLATES[t] || SIGN_TEMPLATES["Other"];
    const scope = d["Scope"] || (j ? "Job" : "Client");
    let fees = []; try { fees = JSON.parse(d["Fees"] || "[]"); } catch (e) { }
    if (!d["Sign ID"] && tpl.fees && !fees.length) fees = jj["Quote Value"] ? [{ item: jj["Service"] || "Service", qty: 1, unit: "each", rate: jj["Quote Value"], amount: "" }] : [{ item: "General pest work", qty: 3, unit: "hour", rate: "", amount: "" }, { item: "Travel time", qty: "", unit: "hour", rate: "", amount: "" }, { item: "Vehicle", qty: "", unit: "km", rate: "", amount: "" }];
    $("#signForm").innerHTML = `<form class="card" id="sForm" style="margin-top:16px"><h2>${d["Sign ID"] ? "Edit document" : "New document"}</h2>
      ${rateCard.length ? "" : `<p class="notice">The Rate Card tab is empty, so nothing can prefill. Run setupHubTabs once in the script, or type rates into the Rate Card tab.</p>`}
      <div class="form"><div><label for="sType">Type</label><select id="sType">${option(Object.keys(SIGN_TEMPLATES), t)}</select></div><div><label for="sTitle">Title</label><input id="sTitle" required value="${esc(d["Title"] || mergeTemplate(tpl.title, jj, c))}"></div>
      <div><label for="sScope">Covers</label><select id="sScope" ${d["Sign ID"] || !j ? "disabled" : ""}>${[["Job", "This job only"], ["Client", "This client, every job until cancelled"]].map(([k, l]) => `<option value="${k}" ${scope === k ? "selected" : ""}>${l}</option>`).join("")}</select></div><div><label for="sValidTo">Valid to (blank = until cancelled)</label><input id="sValidTo" type="date" value="${esc(String(d["Valid To"] || "").slice(0, 10))}"></div>
      <div><label for="sName">Signer name</label><input id="sName" value="${esc(d["Signer Name"] || c["Contact Name"] || "")}"></div><div><label for="sEmail">Signer email</label><input id="sEmail" type="email" value="${esc(d["Signer Email"] || c["Email"] || "")}"></div>
      <div><label for="sRole">Signer role</label><input id="sRole" value="${esc(d["Signer Role"] || "")}" placeholder="Owner, manager, site contact"></div></div>
      <label for="sBody">Wording (blank line between paragraphs, "## " for a heading, "- " for bullets, "? " for a question the client answers) ${tidyBtn("sBody", "letter or form the client signs", "Letter", jj["Service"])}</label><textarea id="sBody" rows="16" style="min-height:300px">${esc(d["Body"] || mergeTemplate(tpl.body, jj, c))}</textarea>
      <div id="ansBox" class="subfields" style="margin-top:10px"><h3 style="margin:.4em 0">Answers (optional, fill what you know; the client can add to them)</h3><div id="ansBody"></div></div>
      ${j ? `<label class="check" style="margin-top:14px"><input type="checkbox" id="sInsp" ${d["Include Inspection"] === "Yes" ? "checked" : ""}> Include the latest site inspection from the Job log (notes, recommendations, up to 4 photos)</label>` : ""}
      <label class="check" style="margin-top:14px"><input type="checkbox" id="sPerm" ${d["Include Permission"] === "Yes" ? "checked" : ""}> Include the firearm use permission (same signature covers both)</label>
      <p class="small muted" id="sPermNote">${(j ? state.permissions.some(p => p["Job ID"] === jobId && !["Void", "Cancelled"].includes(p["Status"])) || !!standingPermission(c["Client ID"]) : state.permissions.some(p => p["Scope"] === "Client" && p["Client ID"] === c["Client ID"] && !["Void", "Cancelled"].includes(p["Status"]))) ? "Permission drawn up. It will be appended with its map and signed with the same signature." : `No permission yet. <a href="${j ? `#/jobs/${esc(jobId)}/permission` : `#/clients/${esc(c["Client ID"])}/permission`}">Set it up and draw the map</a> first, then tick this.`}</p>
      <div id="feeBox" ${tpl.fees || fees.length ? "" : "hidden"}><h3 style="margin:1em 0 .4em">Schedule of fees (ex GST, GST added in the PDF)</h3><div class="tbl-wrap"><table class="tbl fees"><thead><tr><th>Item</th><th>Qty</th><th>Unit</th><th>Rate</th><th>Amount</th><th></th></tr></thead><tbody id="feeRows">${fees.map(feeRow).join("")}</tbody></table></div><div class="btnrow"><button type="button" class="btn btn-sm" id="feeAdd">Add line</button><span class="muted small">Items and rates come from the Rate Card tab. Leave Amount blank to use qty x rate.</span></div></div>
      <div class="form-actions"><button class="btn btn-primary" type="submit" id="sSave">Save</button><button class="btn" type="button" id="sSign">Save and sign now</button><button class="btn" type="button" id="sSend">Save and email link</button><button class="btn btn-quiet" type="button" id="sCancel">Cancel</button></div></form>`;
    const F = $("#sForm"); wireTidy(F);
    let savedAnswers = {}; try { savedAnswers = JSON.parse(d["Answers"] || "{}"); } catch (e) { }
    const drawAnswers = () => { const cur = Object.assign({}, savedAnswers, collectAnswers(F)); const tmp = document.createElement("div"); tmp.innerHTML = bodyToHtml($("#sBody").value, cur, true); const qs = tmp.querySelectorAll(".q"); $("#ansBody").innerHTML = ""; qs.forEach(q => $("#ansBody").appendChild(q)); $("#ansBox").hidden = !qs.length; };
    drawAnswers(); $("#sBody").addEventListener("change", drawAnswers);
    F.querySelector("#sType").addEventListener("change", ev => { const tp = SIGN_TEMPLATES[ev.target.value]; if (!d["Sign ID"] || confirm("Replace the wording with the " + ev.target.value + " template?")) { $("#sTitle").value = mergeTemplate(tp.title, jj, c); $("#sBody").value = mergeTemplate(tp.body, jj, c); if (!tp.fees && !d["Sign ID"]) $("#feeRows").innerHTML = ""; drawAnswers(); } $("#feeBox").hidden = !tp.fees && !$("#feeRows").children.length; });
    F.querySelector("#feeAdd").addEventListener("click", () => { $("#feeRows").insertAdjacentHTML("beforeend", feeRow({})); wireFees(); });
    const applyRate = (tr, force) => { const sel = tr.querySelector(".fSel"), inp = tr.querySelector(".fItem"); if (sel.value === "Other") { inp.hidden = false; return; } inp.hidden = true; if (sel.value) inp.value = sel.value; const r = rateCard.find(x => x["Item"] === sel.value); if (r) { if (force || !tr.querySelector(".fUnit").value) tr.querySelector(".fUnit").value = r["Unit"] || ""; if (force || !tr.querySelector(".fRate").value) tr.querySelector(".fRate").value = r["Rate ex GST"] === "" || r["Rate ex GST"] == null ? "" : r["Rate ex GST"]; } };
    const wireFees = () => { F.querySelectorAll(".fDel").forEach(b => b.onclick = () => b.closest("tr").remove()); F.querySelectorAll(".fSel").forEach(sel => sel.onchange = () => applyRate(sel.closest("tr"), true)); };
    wireFees(); F.querySelectorAll("#feeRows tr").forEach(tr => applyRate(tr, false));
    F.querySelector("#sCancel").addEventListener("click", () => $("#signForm").innerHTML = "");
    const collect = () => ({ "Sign ID": d["Sign ID"] || "", "Job ID": $("#sScope").value === "Client" ? "" : (jobId || ""), "Client ID": c["Client ID"] || "", "Scope": $("#sScope").value, "Valid To": $("#sValidTo").value, "Type": $("#sType").value, "Title": $("#sTitle").value.trim(), "Body": $("#sBody").value, "Signer Name": $("#sName").value.trim(), "Signer Email": $("#sEmail").value.trim(), "Signer Role": $("#sRole").value.trim(), "Status": d["Status"] || "Draft", "Answers": JSON.stringify(Object.assign({}, savedAnswers, collectAnswers(F))), "Include Permission": $("#sPerm").checked ? "Yes" : "No", "Include Inspection": $("#sInsp") && $("#sInsp").checked ? "Yes" : "No",
      "Fees": JSON.stringify([...F.querySelectorAll("#feeRows tr")].map(tr => ({ item: tr.querySelector(".fItem").value.trim(), qty: tr.querySelector(".fQty").value, unit: tr.querySelector(".fUnit").value.trim(), rate: tr.querySelector(".fRate").value, amount: tr.querySelector(".fAmt").value })).filter(f => f.item || f.amount)) });
    const save = async (sig, signedName) => { if (!F.reportValidity()) return null; const out = await api("saveSignDoc", { doc: collect(), signatureDataUrl: sig || "", signedName: signedName || "" }); return out.doc; };
    F.addEventListener("submit", async ev => { ev.preventDefault(); try { await save(); toast("Saved"); $("#signForm").innerHTML = ""; load(); } catch (err) { toast(err.message, true); } });
    F.querySelector("#sSign").addEventListener("click", async () => { try { const doc = await save(); if (doc) signNow(doc); } catch (err) { toast(err.message, true); } });
    F.querySelector("#sSend").addEventListener("click", async () => { try { const doc = await save(); if (doc) sendLink(doc); } catch (err) { toast(err.message, true); } });
  };
  const signNow = (d) => {
    const dlg = document.createElement("div"); dlg.className = "modal";
    dlg.innerHTML = `<form class="modal-card" id="sigForm"><h2>${esc(d["Title"])}</h2><p class="muted small">Hand the phone to the client. They read the document, type their name and sign.</p>
      <div id="sigPreviewBox" class="doc-preview"><p class="muted">Loading the document.</p></div>
      <label for="sigName">Full name</label><input id="sigName" required value="${esc(d["Signer Name"] || "")}">
      <label>Signature</label><div class="sigbox"><canvas id="sigPad2" width="900" height="260"></canvas></div><div class="btnrow" style="margin-top:6px"><button type="button" class="btn btn-sm btn-quiet" id="sigClear2">Clear</button></div>
      <div class="form-actions"><button class="btn btn-primary" type="submit" id="sigSave">Sign and file</button><button class="btn btn-quiet" type="button" id="sigCancel">Cancel</button></div></form>`;
    document.body.appendChild(dlg);
    const pad = sigPad(dlg.querySelector("#sigPad2"), dlg.querySelector("#sigClear2"));
    let full = null;
    api("getSignDoc", { signId: d["Sign ID"] }).then(out => { full = out.doc; let ans = {}; try { ans = JSON.parse(full["Answers"] || "{}"); } catch (e) { } dlg.querySelector("#sigPreviewBox").innerHTML = bodyToHtml(full["Body"], ans, true); }).catch(e => { dlg.querySelector("#sigPreviewBox").textContent = e.message; });
    dlg.querySelector("#sigCancel").addEventListener("click", () => dlg.remove());
    dlg.querySelector("#sigForm").addEventListener("submit", async ev => {
      ev.preventDefault(); if (!pad.dirty()) { toast("Needs a signature.", true); return; }
      dlg.querySelector("#sigSave").disabled = true;
      try { const doc = full || (await api("getSignDoc", { signId: d["Sign ID"] })).doc; doc["Signed Name"] = dlg.querySelector("#sigName").value.trim(); doc["Answers"] = JSON.stringify(collectAnswers(dlg)); await api("saveSignDoc", { doc, signatureDataUrl: pad.dataUrl() }); dlg.remove(); toast("Signed and filed"); $("#signForm").innerHTML = ""; bootstrap().then(load); } catch (err) { toast(err.message, true); dlg.querySelector("#sigSave").disabled = false; }
    });
  };
  const sendLink = async (d) => {
    const link = signLink(d["Token"]);
    const subject = d["Title"] + " for signature";
    const body = `Hi ${d["Signer Name"] || ""},\n\nPlease open the link below, read ${d["Title"]} and sign on screen. It takes a minute and works on a phone.\n\n${link}\n\nA signed copy is filed automatically and I will send you a PDF.\n\nThanks,\n${state.user.name}\nTerana Environmental\n0450 303 434`;
    try { await api("markSignSent", { signId: d["Sign ID"] }); } catch (e) { }
    location.href = "mailto:" + encodeURIComponent(d["Signer Email"] || "") + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
    $("#signForm").innerHTML = ""; load();
  };
  $("#newSign").addEventListener("click", () => drawForm(null));
  load();
}
function sigPad(canvas, clearBtn) {
  const ctx = canvas.getContext("2d"); let drawing = false, dirty = false;
  ctx.lineWidth = 3; ctx.lineCap = "round"; ctx.strokeStyle = "#000";
  const pos = ev => { const rct = canvas.getBoundingClientRect(); return [(ev.clientX - rct.left) * canvas.width / rct.width, (ev.clientY - rct.top) * canvas.height / rct.height]; };
  canvas.addEventListener("pointerdown", ev => { drawing = true; dirty = true; const [x, y] = pos(ev); ctx.beginPath(); ctx.moveTo(x, y); canvas.setPointerCapture(ev.pointerId); ev.preventDefault(); });
  canvas.addEventListener("pointermove", ev => { if (!drawing) return; const [x, y] = pos(ev); ctx.lineTo(x, y); ctx.stroke(); ev.preventDefault(); });
  canvas.addEventListener("pointerup", () => drawing = false); canvas.addEventListener("pointercancel", () => drawing = false);
  if (clearBtn) clearBtn.addEventListener("click", () => { ctx.clearRect(0, 0, canvas.width, canvas.height); dirty = false; });
  return { dirty: () => dirty, dataUrl: () => canvas.toDataURL("image/png") };
}

/* ---------- account: two-step login ---------- */
function renderAccount(v) {
  v.innerHTML = `<div class="page-head"><div><h1>Account</h1><p class="muted">${esc(state.user.name)}${state.user.email ? ", " + esc(state.user.email) : ""}</p></div></div><div class="card" id="twoStepCard"><h2>Two-step login</h2><p class="muted">Checking.</p></div>
    <div class="card" style="margin-top:16px"><h2>Devices</h2><p class="small muted">This device is ${localStorage.getItem("teranaDevice") ? "trusted (no code needed for 60 days)" : "not trusted (a code is asked at each login)"}.</p>${localStorage.getItem("teranaDevice") ? `<button type="button" class="btn btn-sm btn-quiet" id="untrust">Stop trusting this device</button>` : ""}</div>`;
  if ($("#untrust")) $("#untrust").addEventListener("click", () => { localStorage.removeItem("teranaDevice"); toast("This device will ask for a code next login"); renderAccount(v); });
  api("twoStepStatus").then(out => {
    const card = $("#twoStepCard");
    if (out.on) {
      card.innerHTML = `<h2>Two-step login</h2><p><span class="tag ok">On</span> A code from your authenticator app is needed on any device that isn't trusted.</p><label for="offCode">To turn it off, enter a current code</label><div class="btnrow"><input id="offCode" inputmode="numeric" maxlength="7" style="max-width:10em" placeholder="6 digits"><button type="button" class="btn btn-sm btn-quiet" id="offBtn">Turn off</button></div>`;
      $("#offBtn").addEventListener("click", async () => { try { await api("totpOff", { code: $("#offCode").value.trim() }); toast("Two-step login turned off"); renderAccount(v); } catch (err) { toast(err.message, true); } });
    } else {
      card.innerHTML = `<h2>Two-step login</h2><p><span class="tag warn">Off</span> Anyone with your email and passcode can log in. Turning this on adds a 6-digit code from an authenticator app (Google Authenticator, Microsoft Authenticator, Authy or the iPhone Passwords app).</p><button type="button" class="btn btn-primary" id="setupBtn">Set up two-step login</button><div id="setupBox" hidden style="margin-top:14px"></div>`;
      $("#setupBtn").addEventListener("click", async () => {
        try {
          const out = await api("totpSetup");
          $("#setupBox").hidden = false;
          $("#setupBox").innerHTML = `<ol class="steps-list"><li>Open your authenticator app and add an account.</li><li>On this phone: <a class="btn btn-sm" href="${esc(out.otpauth)}">Open in authenticator app</a>. Or scan this code from another device, or type the key.</li></ol>
            <div class="qrwrap" id="qrBox"></div>
            <p class="small">Key (if typing): <code id="secretKey">${esc(out.secret.replace(/(.{4})/g, "$1 ").trim())}</code> <button type="button" class="btn btn-sm btn-quiet" id="copyKey">Copy</button></p>
            <label for="confirmCode">Enter the 6-digit code the app shows now</label><div class="btnrow"><input id="confirmCode" inputmode="numeric" maxlength="7" style="max-width:10em" placeholder="6 digits"><button type="button" class="btn btn-primary btn-sm" id="confirmBtn">Turn on</button></div>`;
          drawQr($("#qrBox"), out.otpauth);
          $("#copyKey").addEventListener("click", async () => { try { await navigator.clipboard.writeText(out.secret); toast("Key copied"); } catch (e) { } });
          $("#confirmBtn").addEventListener("click", async () => { try { await api("totpConfirm", { code: $("#confirmCode").value.trim() }); toast("Two-step login is on"); renderAccount(v); } catch (err) { toast(err.message, true); } });
        } catch (err) { toast(err.message, true); }
      });
    }
  }).catch(err => { $("#twoStepCard").innerHTML = `<h2>Two-step login</h2><p class="form-error">${esc(err.message)}</p>`; });
}

function drawQr(box, text) {
  try {
    const q = window.qrcode(text, "M"); const n = q.getModuleCount(), cell = 5, pad = 4;
    const cv = document.createElement("canvas"); cv.width = cv.height = (n + pad * 2) * cell; const cx = cv.getContext("2d");
    cx.fillStyle = "#fff"; cx.fillRect(0, 0, cv.width, cv.height); cx.fillStyle = "#000";
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (q.isDark(r, c)) cx.fillRect((c + pad) * cell, (r + pad) * cell, cell, cell);
    cv.style.width = "220px"; cv.style.height = "220px"; box.innerHTML = ""; box.appendChild(cv);
  } catch (e) { box.textContent = "QR unavailable, use the key or the link."; }
}

/* ---------- SMS: safety management system ---------- */
function reviewTag(d) {
  const due = String(d["Review Date"] || "").slice(0, 10); if (!due) return `<span class="tag warn">No review date</span>`;
  const days = Math.round((new Date(due + "T00:00:00") - new Date(todayISO() + "T00:00:00")) / 86400000);
  if (days < 0) return `<span class="tag bad">Review overdue (${esc(fmtDate(due))})</span>`;
  if (days <= 60) return `<span class="tag warn">Review due ${esc(fmtDate(due))}</span>`;
  return `<span class="tag ok">Reviewed ${esc(fmtDate(d["Last Reviewed"]))}</span>`;
}
function reviewsDue(days) { return (state.documents || []).filter(d => d["Review Date"] && String(d["Review Date"]).slice(0, 10) <= addDays(todayISO(), days)).sort((a, b) => String(a["Review Date"]).localeCompare(String(b["Review Date"]))); }
const SMS_TYPES = ["Plan", "SWMS", "Procedure", "Pre-site screen", "Template", "Policy", "Register", "Other"];
function renderSms(v) {
  v.innerHTML = `<div class="page-head"><div><h1>Safety management system</h1><p class="muted">Every safety document in one place: open it, see when it was last reviewed, get it read and signed, and mark it reviewed.</p></div><div class="btnrow"><button class="btn btn-primary" id="newSms">Add document</button><a class="btn" href="emergency-plan.html">Emergency plan</a></div></div><p class="muted" id="smsLoading">Loading.</p><div id="smsBody"></div>`;
  $("#newSms").addEventListener("click", () => editSmsDoc(v, null));
  Promise.all([api("listDocuments"), api("listSignDocs", { scope: "SMS" })]).then(([d, sg]) => {
    $("#smsLoading").hidden = true;
    const docs = (d.documents || []).filter(x => x["Category"] === "SMS" && x["Status"] !== "Archived");
    state.documents = (d.documents || []).filter(x => x["Status"] !== "Archived"); saveCache();
    const signed = (sg.docs || []).filter(x => x["Status"] === "Signed");
    const due = docs.filter(x => x["Review Date"] && String(x["Review Date"]).slice(0, 10) <= addDays(todayISO(), 60));
    const types = SMS_TYPES.filter(t => docs.some(x => (x["Type"] || "Other") === t)).concat(docs.some(x => !SMS_TYPES.includes(x["Type"] || "Other")) ? ["Other"] : []);
    $("#smsBody").innerHTML = `${due.length ? `<div class="notice">Reviews due: ${due.map(x => esc(x["Title"]) + " (" + esc(fmtDate(x["Review Date"])) + ")").join(", ")}.</div>` : ""}
      ${types.map(t => { const items = docs.filter(x => (SMS_TYPES.includes(x["Type"] || "Other") ? (x["Type"] || "Other") : "Other") === t); return `<h2 class="sect">${esc(t === "SWMS" ? "Safe work method statements" : t === "Plan" ? "Plans" : t === "Procedure" ? "Procedures" : t === "Pre-site screen" ? "Pre-site screens" : t === "Template" ? "Templates" : t)}</h2><div class="card"><table class="tbl"><thead><tr><th>Document</th><th>Review</th><th class="hide-m">Signed by</th><th></th></tr></thead><tbody>${items.map(x => { const sigs = signed.filter(sg2 => sg2["Doc ID"] === x["Doc ID"]); return `<tr><td><a href="#/sms/${esc(x["Doc ID"])}"><strong>${esc(x["Title"])}</strong></a><div class="small muted">${esc(x["Doc No"] || "")}${x["Version"] ? " v" + esc(x["Version"]) : ""}${x["Owner"] ? ", " + esc(x["Owner"]) : ""}</div></td><td>${reviewTag(x)}</td><td class="hide-m small">${sigs.length ? sigs.slice(-3).map(sg2 => esc(sg2["Signed Name"])).join(", ") + (sigs.length > 3 ? " +" + (sigs.length - 3) : "") : `<span class="muted">Nobody yet</span>`}</td><td class="right btnrow" style="justify-content:flex-end">${x["Link"] ? `<a class="btn btn-sm" href="${esc(x["Link"])}" ${/^https?:/.test(x["Link"]) ? 'target="_blank" rel="noopener"' : ""}>Open</a>` : ""}<a class="btn btn-sm btn-quiet" href="#/sms/${esc(x["Doc ID"])}">Details</a></td></tr>`; }).join("")}</tbody></table></div>`; }).join("") || `<p class="empty">No SMS documents yet. Run setupHubTabs in the script to load the TE-WHS set, or add one.</p>`}`;
  }).catch(err => { $("#smsLoading").textContent = err.message; });
}
function renderSmsDoc(v, docId) {
  v.innerHTML = `<p class="muted">Loading.</p>`;
  Promise.all([api("listDocuments"), api("listSignDocs", { docId })]).then(([d, sg]) => {
    const x = (d.documents || []).find(y => y["Doc ID"] === docId); if (!x) { v.innerHTML = `<p class="empty">Document not found.</p>`; return; }
    const sigs = (sg.docs || []).filter(y => y["Status"] !== "Void").sort((a, b) => String(b["Signed Date"] || b["Created"]).localeCompare(String(a["Signed Date"] || a["Created"])));
    v.innerHTML = `<div class="page-head"><div><p class="muted small"><a href="#/sms">SMS</a> / ${esc(x["Doc No"] || "")}</p><h1>${esc(x["Title"])}</h1><p class="muted">${esc(x["Type"] || "")}${x["Version"] ? ", version " + esc(x["Version"]) : ""}${x["Owner"] ? ", owner " + esc(x["Owner"]) : ""}. ${reviewTag(x)} ${x["Review Months"] ? `<span class="small muted">every ${esc(x["Review Months"])} months</span>` : ""}</p>${x["Notes"] ? `<p class="small muted" style="white-space:pre-wrap">${esc(x["Notes"])}</p>` : ""}</div>
      <div class="btnrow">${x["Link"] ? `<a class="btn btn-primary" href="${esc(x["Link"])}" ${/^https?:/.test(x["Link"]) ? 'target="_blank" rel="noopener"' : ""}>Open document</a>` : ""}<button class="btn" id="smsReviewed">Mark reviewed today</button><button class="btn btn-quiet" id="smsEdit">Edit details</button></div></div>
      <div class="card"><div class="card-head"><h2>Read and signed</h2><div class="btnrow"><button class="btn btn-sm btn-primary" id="smsSignNow">Sign now</button><button class="btn btn-sm" id="smsSend">Email link to sign</button></div></div>
        <p class="small muted">Each signature is a read-and-understood acknowledgement of this version. The signed PDF files under Terana SMS / Signed acknowledgements in Drive.</p>
        ${/docs\.google\.com\/document/.test(x["Link"] || "") ? `<div class="btnrow" style="margin-bottom:10px"><label class="check" style="margin:0"><input type="checkbox" id="smsWriteIn" checked> Also write the name and signature into the document's sign-off table</label><select id="smsRole" style="width:auto;display:inline-block;margin:0"><option>Worker</option><option>Authoriser</option></select></div>` : `<p class="small muted">To have signatures written into the document itself, the master needs to be a Google Doc (open it in Drive, File, Save as Google Docs, then update the link here). Job copies made from the Planning card are converted automatically.</p>`}
        ${sigs.length ? `<table class="tbl"><thead><tr><th>Who</th><th>Status</th><th class="hide-m">Version</th><th></th></tr></thead><tbody>${sigs.map(sgn => `<tr><td><strong>${esc(sgn["Signed Name"] || sgn["Signer Name"] || "")}</strong><div class="small muted">${esc(sgn["Signer Email"] || "")}</div></td><td>${pill(sgn["Status"])}${sgn["Status"] === "Signed" ? `<div class="small muted">${esc(fmtDate(sgn["Signed Date"]))}, ${esc(sgn["Signed How"] || "")}</div>` : sgn["Status"] === "Sent" ? `<div class="small muted">sent ${esc(fmtDate(sgn["Sent Date"]))}</div>` : ""}</td><td class="hide-m">${esc(sgn["Valid To"] || "")}</td><td class="right">${sgn["Status"] === "Signed" ? extLink(sgn["PDF URL"], "PDF", "btn btn-sm") : `<button type="button" class="btn btn-sm btn-quiet" data-resend="${esc(sgn["Token"])}">Copy link</button>`}</td></tr>`).join("")}</tbody></table>` : `<p class="empty">Nobody has signed this version yet.</p>`}</div>`;
    const isGdoc = /docs\.google\.com\/document/.test(x["Link"] || "");
    const ackDoc = () => ({ "Doc ID": x["Doc ID"], "Scope": "SMS", "Type": "Acknowledgement", "Title": "Read and understood: " + x["Title"], "Valid To": x["Version"] || "", "Target Doc ID": isGdoc && $("#smsWriteIn") && $("#smsWriteIn").checked ? (x["Drive File ID"] || "") : "", "Sign Role": isGdoc && $("#smsRole") ? $("#smsRole").value : "",
      "Body": `I confirm that I have read ${x["Title"]}${x["Doc No"] ? " (" + x["Doc No"] + ")" : ""}${x["Version"] ? ", version " + x["Version"] : ""}, that I understand it, and that I will follow it when working for or with Terana Environmental.\n\n${x["Link"] && /^https?:/.test(x["Link"]) ? "The document is here: " + x["Link"] + "\n\n" : ""}## Acknowledgement\n? Your role (staff, contractor, client representative)\n? Anything you want clarified before starting work` });
    $("#smsSignNow").addEventListener("click", async () => {
      try { const out = await api("saveSignDoc", { doc: Object.assign(ackDoc(), { "Signer Name": "" }) }); signAckNow(v, out.doc, docId); } catch (err) { toast(err.message, true); }
    });
    $("#smsSend").addEventListener("click", async () => {
      const email = prompt("Email address to send the signing link to"); if (!email) return;
      const name = prompt("Their name") || "";
      try { const out = await api("saveSignDoc", { doc: Object.assign(ackDoc(), { "Signer Name": name, "Signer Email": email }) }); await api("markSignSent", { signId: out.doc["Sign ID"] });
        const link = signLink(out.doc["Token"]);
        const body = `Hi ${name},\n\nPlease read ${x["Title"]} and sign on the link below to confirm you have read and understood it.\n\n${link}\n\nIt takes a minute and works on a phone.\n\nThanks,\n${state.user.name}\nTerana Environmental\n0450 303 434`;
        location.href = "mailto:" + encodeURIComponent(email) + "?subject=" + encodeURIComponent("Please read and sign: " + x["Title"]) + "&body=" + encodeURIComponent(body);
        setTimeout(() => renderSmsDoc(v, docId), 800);
      } catch (err) { toast(err.message, true); }
    });
    v.querySelectorAll("[data-resend]").forEach(b => b.addEventListener("click", async () => { try { await navigator.clipboard.writeText(signLink(b.dataset.resend)); toast("Link copied"); } catch (e) { prompt("Copy this link", signLink(b.dataset.resend)); } }));
    $("#smsReviewed").addEventListener("click", async () => { const note = prompt("Any note on this review? (optional)") ; if (note === null) return; try { await api("markReviewed", { docId, note: note || true }); toast("Marked reviewed"); await bootstrap(); renderSmsDoc(v, docId); } catch (err) { toast(err.message, true); } });
    $("#smsEdit").addEventListener("click", () => editSmsDoc(v, x, () => renderSmsDoc(v, docId)));
  }).catch(err => { v.innerHTML = `<p class="form-error">${esc(err.message)}</p>`; });
}
// Sign a job's SWMS copy: the name and signature are written into the document's sign-off table as well as filed.
async function signPlanDoc(row, job, byEmail) {
  const master = (state.documents || []).find(x => x["Doc ID"] === row.docId) || {};
  const role = confirm("Sign as the person AUTHORISING this SWMS? (OK = authoriser, Cancel = worker sign-on)") ? "Authoriser" : "Worker";
  const doc = { "Doc ID": row.docId || "", "Job ID": job["Job ID"], "Scope": "SMS", "Type": "SWMS sign-on", "Sign Role": role, "Target Doc ID": row.copy || "", "Target Doc URL": row.link || "",
    "Title": (role === "Authoriser" ? "Authorise: " : "Sign on: ") + (row.name || master["Title"] || "SWMS") + " for " + job["Title"], "Valid To": master["Version"] || "",
    "Body": `I confirm that I have read ${row.name || master["Title"]}${master["Doc No"] ? " (" + master["Doc No"] + ")" : ""} for the job ${job["Title"]}${job["Site Address"] ? " at " + job["Site Address"] : ""}, that I understand the hazards and controls, and that I will work to it.${role === "Authoriser" ? "\n\nAs the person authorising use of this SWMS, I confirm it is suitable for this site and this work." : ""}\n\n${row.link ? "The document is here: " + row.link + "\n\n" : ""}## Acknowledgement\n? Your role on this job\n? Anything to add to the controls for this site` };
  if (byEmail) {
    const email = prompt("Email address of the person signing"); if (!email) return; const name = prompt("Their name") || "";
    try { const out = await api("saveSignDoc", { doc: Object.assign(doc, { "Signer Name": name, "Signer Email": email }) }); await api("markSignSent", { signId: out.doc["Sign ID"] });
      const link = signLink(out.doc["Token"]);
      location.href = "mailto:" + encodeURIComponent(email) + "?subject=" + encodeURIComponent("Please read and sign: " + (row.name || "SWMS") + ", " + job["Title"]) + "&body=" + encodeURIComponent(`Hi ${name},\n\nPlease read the SWMS for ${job["Title"]} and sign on the link below before work starts.\n\n${link}\n\nThanks,\n${state.user.name}\nTerana Environmental\n0450 303 434`);
    } catch (err) { toast(err.message, true); }
  } else {
    try { const out = await api("saveSignDoc", { doc }); signAckNow(null, out.doc, null, () => route()); } catch (err) { toast(err.message, true); }
  }
}
function signAckNow(v, d, docId, after) {
  const dlg = document.createElement("div"); dlg.className = "modal";
  dlg.innerHTML = `<form class="modal-card" id="ackForm"><h2>${esc(d["Title"])}</h2><div id="ackBody" class="doc-preview"><p class="muted">Loading.</p></div>
    <label for="ackName">Full name</label><input id="ackName" required placeholder="Who is signing">
    <label>Signature</label><div class="sigbox"><canvas id="ackPad" width="900" height="260"></canvas></div><div class="btnrow" style="margin-top:6px"><button type="button" class="btn btn-sm btn-quiet" id="ackClear">Clear</button></div>
    <div class="form-actions"><button class="btn btn-primary" type="submit" id="ackSave">Sign and file</button><button class="btn btn-quiet" type="button" id="ackCancel">Cancel</button></div></form>`;
  document.body.appendChild(dlg);
  const pad = sigPad(dlg.querySelector("#ackPad"), dlg.querySelector("#ackClear"));
  let full = null;
  api("getSignDoc", { signId: d["Sign ID"] }).then(out => { full = out.doc; dlg.querySelector("#ackBody").innerHTML = bodyToHtml(full["Body"], {}, true); }).catch(e => dlg.querySelector("#ackBody").textContent = e.message);
  dlg.querySelector("#ackCancel").addEventListener("click", async () => { dlg.remove(); try { await api("voidSignDoc", { signId: d["Sign ID"] }); } catch (e) { } });
  dlg.querySelector("#ackForm").addEventListener("submit", async ev => {
    ev.preventDefault(); if (!pad.dirty()) { toast("Needs a signature.", true); return; }
    dlg.querySelector("#ackSave").disabled = true;
    try { const doc = full || (await api("getSignDoc", { signId: d["Sign ID"] })).doc; doc["Signed Name"] = dlg.querySelector("#ackName").value.trim(); doc["Signer Name"] = doc["Signed Name"]; doc["Answers"] = JSON.stringify(collectAnswers(dlg)); await api("saveSignDoc", { doc, signatureDataUrl: pad.dataUrl() }); dlg.remove(); toast("Signed and filed" + (doc["Target Doc ID"] ? ", and written into the document" : "")); if (after) after(); else renderSmsDoc(v, docId); } catch (err) { toast(err.message, true); dlg.querySelector("#ackSave").disabled = false; }
  });
}
function editSmsDoc(v, x, after) {
  const d = x || {};
  const dlg = document.createElement("div"); dlg.className = "modal";
  dlg.innerHTML = `<form class="modal-card" id="smsForm"><h2>${x ? "Edit document" : "Add SMS document"}</h2>
    <label for="mTitle">Title</label><input id="mTitle" required value="${esc(d["Title"] || "")}" placeholder="e.g. SWMS: Trapping operations">
    <div class="form" style="gap:0 12px"><div><label for="mNo">Document number</label><input id="mNo" value="${esc(d["Doc No"] || "")}" placeholder="TE-WHS-SAF-005"></div><div><label for="mType">Type</label><select id="mType">${option(SMS_TYPES, d["Type"] || "SWMS")}</select></div></div>
    <label for="mLink">Link (Drive file or Google Doc)</label><input id="mLink" value="${esc(d["Link"] || "")}" placeholder="https://drive.google.com/...">
    <div class="form" style="gap:0 12px"><div><label for="mVer">Version</label><input id="mVer" value="${esc(d["Version"] || "")}"></div><div><label for="mOwner">Owner</label><input id="mOwner" value="${esc(d["Owner"] || "Courtney Kelly")}"></div></div>
    <div class="form" style="gap:0 12px"><div><label for="mLast">Last reviewed</label><input id="mLast" type="date" value="${esc(String(d["Last Reviewed"] || "").slice(0, 10))}"></div><div><label for="mMonths">Review every (months)</label><input id="mMonths" type="number" min="1" value="${esc(d["Review Months"] || 12)}"></div></div>
    <label for="mStatus">Status</label><select id="mStatus">${option(["Current", "Draft", "Archived"], d["Status"] || "Current")}</select>
    <label for="mNotes">Notes</label><textarea id="mNotes">${esc(d["Notes"] || "")}</textarea>
    <div class="form-actions"><button class="btn btn-primary" type="submit" id="mSave">Save</button><button class="btn btn-quiet" type="button" id="mCancel">Cancel</button><span class="spacer"></span>${x ? `<button class="btn btn-danger btn-sm" type="button" id="mDelete">Delete</button>` : ""}</div></form>`;
  document.body.appendChild(dlg);
  dlg.querySelector("#mCancel").addEventListener("click", () => dlg.remove());
  if (x) dlg.querySelector("#mDelete").addEventListener("click", async () => { if (!confirm("Delete " + d["Title"] + " from the SMS list? The Drive file is not touched. Signed acknowledgements are kept.")) return; try { await api("deleteDocument", { docId: d["Doc ID"] }); dlg.remove(); toast("Removed"); await bootstrap(); location.hash = "#/sms"; } catch (err) { toast(err.message, true); } });
  dlg.querySelector("#smsForm").addEventListener("submit", async ev => {
    ev.preventDefault(); dlg.querySelector("#mSave").disabled = true;
    const document_ = { "Doc ID": d["Doc ID"] || "", "Original Title": d["Title"] || "", "Title": $("#mTitle").value.trim(), "Category": "SMS", "Doc No": $("#mNo").value.trim(), "Type": $("#mType").value, "Link": $("#mLink").value.trim(), "Version": $("#mVer").value.trim(), "Owner": $("#mOwner").value.trim(), "Last Reviewed": $("#mLast").value, "Review Months": $("#mMonths").value, "Status": $("#mStatus").value, "Notes": $("#mNotes").value.trim() };
    try { await api("saveDocument", { document: document_ }); dlg.remove(); toast("Saved"); await bootstrap(); if (after) after(); else renderSms(v); } catch (err) { toast(err.message, true); dlg.querySelector("#mSave").disabled = false; }
  });
}

/* ---------- cull register ---------- */
function renderCulls(v) {
  v.innerHTML = `<div class="page-head"><div><h1>Cull register</h1><p class="muted">Every animal recorded in a Job log, by species, place and date. Tick the species and type the number on the Job log and it lands here.</p></div><div class="btnrow"><select id="cullYear" style="width:auto;display:inline-block;margin:0"></select><select id="cullClient" style="width:auto;display:inline-block;margin:0"></select><button class="btn btn-sm" id="cullCsv">Download CSV</button></div></div><p class="muted" id="cullLoading">Loading.</p><div id="cullBody"></div>`;
  api("listCulls").then(out => {
    const all = out.culls || [];
    const years = [...new Set(all.map(c => String(c["Date"] || "").slice(0, 4)).filter(Boolean))].sort().reverse();
    const fy = d => { const dt = new Date(String(d).slice(0, 10) + "T00:00:00"); const y = dt.getFullYear(); return dt.getMonth() >= 6 ? `FY${String(y + 1).slice(2)} (Jul ${y} to Jun ${y + 1})` : `FY${String(y).slice(2)} (Jul ${y - 1} to Jun ${y})`; };
    const fys = [...new Set(all.map(c => c["Date"] ? fy(c["Date"]) : "").filter(Boolean))].sort().reverse();
    $("#cullYear").innerHTML = `<option value="">All time</option>${fys.map(f => `<option value="fy:${esc(f)}">${esc(f)}</option>`).join("")}${years.map(y => `<option value="y:${y}">Calendar ${y}</option>`).join("")}`;
    const clients = [...new Set(all.map(c => c["Client"]).filter(Boolean))].sort();
    $("#cullClient").innerHTML = `<option value="">All clients</option>${clients.map(c => `<option>${esc(c)}</option>`).join("")}`;
    const draw = () => {
      const yv = $("#cullYear").value, cv = $("#cullClient").value;
      const rows = all.filter(c => (!cv || c["Client"] === cv) && (!yv || (yv.startsWith("fy:") ? fy(c["Date"]) === yv.slice(3) : String(c["Date"]).slice(0, 4) === yv.slice(2))));
      $("#cullLoading").hidden = true;
      const sum = (key) => { const m = {}; rows.forEach(r => { const k = r[key] || "Unknown"; m[k] = (m[k] || 0) + Number(r["Count"] || 0); }); return Object.entries(m).sort((a, b) => b[1] - a[1]); };
      const total = rows.reduce((t, r) => t + Number(r["Count"] || 0), 0);
      const bySpecies = sum("Species"), byClient = sum("Client"), byMethod = sum("Method"), byLocality = sum("Locality");
      const byMonth = {}; rows.forEach(r => { const k = String(r["Date"] || "").slice(0, 7); byMonth[k] = (byMonth[k] || 0) + Number(r["Count"] || 0); });
      const months = Object.keys(byMonth).sort(); const maxM = Math.max(1, ...Object.values(byMonth));
      const tbl = (pairs, head) => pairs.length ? `<table class="tbl"><thead><tr><th>${head}</th><th class="right">Animals</th></tr></thead><tbody>${pairs.map(([k, n]) => `<tr><td>${esc(k)}</td><td class="right">${n}</td></tr>`).join("")}</tbody></table>` : `<p class="empty">Nothing yet.</p>`;
      $("#cullBody").innerHTML = `<div class="grid kpis"><div class="card kpi"><div class="num">${total}</div><div class="lbl">Animals</div></div><div class="card kpi"><div class="num">${bySpecies.length}</div><div class="lbl">Species</div></div><div class="card kpi"><div class="num">${new Set(rows.map(r => r["Job ID"]).filter(Boolean)).size}</div><div class="lbl">Jobs</div></div><div class="card kpi"><div class="num">${byClient.length}</div><div class="lbl">Clients</div></div></div>
        <div class="grid cols-2" style="margin-top:16px"><div class="card"><h2>By species</h2>${tbl(bySpecies, "Species")}</div><div class="card"><h2>By client</h2>${tbl(byClient, "Client")}</div><div class="card"><h2>By locality</h2>${tbl(byLocality, "Locality")}</div><div class="card"><h2>By method</h2>${tbl(byMethod, "Method")}</div></div>
        <div class="card" style="margin-top:16px"><h2>By month</h2>${months.length ? `<div class="bars">${months.map(m => `<div class="bar"><div class="fill" style="height:${Math.round(byMonth[m] / maxM * 100)}%"></div><div class="bl">${esc(new Date(m + "-01T00:00:00").toLocaleDateString("en-AU", { month: "short", year: "2-digit" }))}</div><div class="bn">${byMonth[m]}</div></div>`).join("")}</div>` : `<p class="empty">Nothing yet.</p>`}</div>
        <div class="card" style="margin-top:16px"><h2>Entries</h2>${rows.length ? `<table class="tbl"><thead><tr><th>Date</th><th>Species</th><th class="right">Count</th><th class="hide-m">Method</th><th>Job</th><th class="hide-m">Where</th></tr></thead><tbody>${rows.slice().sort((a, b) => String(b["Date"]).localeCompare(String(a["Date"]))).slice(0, 300).map(r => `<tr><td>${esc(fmtDate(r["Date"]))}</td><td>${esc(r["Species"])}</td><td class="right">${esc(r["Count"])}</td><td class="hide-m">${esc(r["Method"] || "")}</td><td>${r["Job ID"] ? `<a href="#/jobs/${esc(r["Job ID"])}">${esc(r["Job Title"] || r["Job ID"])}</a>` : ""}<div class="small muted">${esc(r["Client"] || "")}</div></td><td class="hide-m">${esc(r["Locality"] || r["Site"] || "")}</td></tr>`).join("")}</tbody></table>${rows.length > 300 ? `<p class="small muted">Showing the latest 300. Download the CSV for everything.</p>` : ""}` : `<p class="empty">No culls recorded for this filter.</p>`}</div>`;
      $("#cullCsv").onclick = () => { const cols = ["Date", "Species", "Count", "Method", "Job ID", "Job Title", "Client", "Site", "Locality", "Latitude", "Longitude", "Technician", "Reason"]; const csv = [cols.join(",")].concat(rows.map(r => cols.map(c => `"${String(r[c] == null ? "" : r[c]).replace(/"/g, '""')}"`).join(","))).join("\n"); downloadText("Terana cull register" + (yv ? " " + yv.replace(/^\w+:/, "") : "") + ".csv", csv, "text/csv"); };
    };
    $("#cullYear").addEventListener("change", draw); $("#cullClient").addEventListener("change", draw); draw();
  }).catch(err => { $("#cullLoading").textContent = err.message; });
}

/* ---------- planner: timeline of jobs and stages ---------- */
function renderPlanner(v) {
  const weeks = Number(localStorage.getItem("teranaPlannerWeeks") || 6);
  v.innerHTML = `<div class="page-head"><div><h1>Planner</h1><p class="muted">Every job and stage on a timeline. Tap a bar to open the job. Dates come from each job's start, end and stages.</p></div><div class="btnrow"><label class="small muted" for="plWeeks" style="display:inline;margin:0">Show</label><select id="plWeeks" style="width:auto;display:inline-block;margin:0 4px">${option(["4", "6", "8", "12", "26"], String(weeks))}</select><span class="small muted">weeks</span> <a class="btn btn-sm" href="#/jobs/new">New job</a></div></div><div id="plBody"></div>`;
  $("#plWeeks").addEventListener("change", ev => { localStorage.setItem("teranaPlannerWeeks", ev.target.value); renderPlanner(v); });
  drawPlanner($("#plBody"), weeks);
}
function drawPlanner(box, weeks) {
  const today = todayISO();
  const d0 = new Date(today + "T00:00:00"); d0.setDate(d0.getDate() - ((d0.getDay() + 6) % 7));   // Monday this week
  const start = d0.getFullYear() + "-" + String(d0.getMonth() + 1).padStart(2, "0") + "-" + String(d0.getDate()).padStart(2, "0");
  const days = weeks * 7, end = addDays(start, days - 1);
  const dayIndex = iso => Math.round((new Date(iso + "T00:00:00") - new Date(start + "T00:00:00")) / 86400000);
  const live = state.jobs.filter(j => !["Cancelled", "Invoiced"].includes(j["Status"]));
  const rows = [], unscheduled = [];
  live.forEach(j => {
    const stages = (parseJson(j["Stages"], []) || []).filter(st => st.start);
    const bars = [];
    if (j["Start Date"]) bars.push({ label: j["Title"], from: j["Start Date"], to: j["End Date"] || j["Start Date"], status: j["Status"], main: true });
    stages.forEach(st => bars.push({ label: st.name || "stage", from: st.start, to: st.end || st.start, status: st.status === "Done" ? "Completed" : st.status === "Skipped" ? "Cancelled" : (st.status === "Booked" ? "Scheduled" : j["Status"]), stage: true }));
    const visible = bars.filter(b => b.to >= start && b.from <= end);
    if (visible.length) rows.push({ job: j, bars: visible }); else if (!bars.length) unscheduled.push(j);
  });
  rows.sort((a, b) => (a.bars[0].from > b.bars[0].from ? 1 : -1));
  const dayW = weeks > 8 ? 18 : weeks > 6 ? 24 : 32;
  const labelW = 170;
  const dayCells = []; for (let i = 0; i < days; i++) { const d = addDays(start, i); const dt = new Date(d + "T00:00:00"); dayCells.push({ iso: d, dow: dt.getDay(), dom: dt.getDate(), mon: i === 0 || dt.getDate() === 1 ? dt.toLocaleDateString("en-AU", { month: "short" }) : "" }); }
  const todayX = dayIndex(today);
  const bar = (b, i) => { const a = Math.max(0, dayIndex(b.from)), z = Math.min(days - 1, dayIndex(b.to)); return `<a class="plbar ${b.stage ? "stage" : "main"}" style="left:${a * dayW}px;width:${(z - a + 1) * dayW - 2}px;top:${4 + i * 22}px;--c:${STATUS_COLOUR[b.status] || "#6B6B6B"}" title="${esc(b.label)} ${esc(fmtDate(b.from))}${b.to !== b.from ? " to " + esc(fmtDate(b.to)) : ""}">${esc(b.label)}</a>`; };
  box.innerHTML = `<div class="card plwrap"><div class="plscroll"><div class="plgrid" style="width:${labelW + days * dayW}px">
      <div class="plhead" style="padding-left:${labelW}px">${dayCells.map(c => `<div class="plday ${c.dow === 0 || c.dow === 6 ? "we" : ""} ${c.iso === today ? "today" : ""}" style="width:${dayW}px"><span class="mon">${c.mon}</span>${c.dom}</div>`).join("")}</div>
      ${rows.map(r => { const lanes = []; r.bars.forEach(b => { let i = 0; while (lanes[i] && lanes[i].some(o => !(b.to < o.from || b.from > o.to))) i++; (lanes[i] = lanes[i] || []).push(b); b.lane = i; }); const h = Math.max(46, 8 + lanes.length * 22); return `<div class="plrow" style="height:${h}px"><div class="pllabel" style="width:${labelW}px"><a href="#/jobs/${esc(r.job["Job ID"])}"><strong>${esc(r.job["Title"])}</strong></a><div class="small muted">${esc(r.job["Client Name"] || "")}${r.job["Assigned To"] ? ", " + esc(r.job["Assigned To"]) : ""}</div></div><div class="pllane" style="left:${labelW}px;width:${days * dayW}px;background-size:${dayW}px 100%">${r.bars.map(b => bar(Object.assign({}, b), b.lane).replace('<a class', `<a href="#/jobs/${esc(r.job["Job ID"])}" class`)).join("")}</div></div>`; }).join("") || `<p class="empty" style="padding:16px">Nothing scheduled in this window. Give jobs a start date, or add stages with dates.</p>`}
      ${todayX >= 0 && todayX < days ? `<div class="pltoday" style="left:${labelW + todayX * dayW + dayW / 2}px"></div>` : ""}
    </div></div>
    <p class="small muted" style="margin:10px 0 0">Bars are coloured by status: ${Object.keys(STATUS_COLOUR).filter(k => k !== "Invoiced").map(k => `<span class="pldot" style="--c:${STATUS_COLOUR[k]}"></span>${esc(k)}`).join(" &nbsp; ")}. Thin bars are stages.</p></div>
    ${(function () { const due = (state.documents || []).filter(d => d["Review Date"] && String(d["Review Date"]).slice(0, 10) <= end).sort((a, b) => String(a["Review Date"]).localeCompare(String(b["Review Date"]))); return due.length ? `<div class="card" style="margin-top:16px"><div class="card-head"><h2>Document reviews due</h2><a class="btn btn-sm" href="#/sms">Open SMS</a></div><ul class="list">${due.map(d => `<li><span class="when">${esc(fmtDate(d["Review Date"]))}</span><div class="what"><a href="#/sms/${esc(d["Doc ID"])}"><strong>Review ${esc(d["Title"])}</strong></a> <span class="small muted">${esc(d["Doc No"] || "")}, last reviewed ${esc(fmtDate(d["Last Reviewed"]) || "never")}</span> ${reviewTag(d)}</div></li>`).join("")}</ul></div>` : ""; })()}
    ${unscheduled.length ? `<div class="card" style="margin-top:16px"><h2>No dates yet</h2>${jobList(unscheduled, "Next Action Date")}</div>` : ""}`;
}

/* ---------- map ---------- */
function satTiles() { return L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", { maxZoom: 19, crossOrigin: true, attribution: "Imagery &copy; Esri" }); }
function tiles() { return L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' }); }
function pinIcon(status) { return L.divIcon({ className: "", html: `<div class="pin" style="--c:${STATUS_COLOUR[status] || "#6B6B6B"}"></div>`, iconSize: [18, 18], iconAnchor: [9, 18], popupAnchor: [0, -16] }); }
let mapFilter = "Open";
function renderMap(v) {
  v.innerHTML = `
    <div class="page-head"><div><h1>Job map</h1></div><div class="chips">${["Open", "All"].concat(CONFIG.statuses).map(f => `<button type="button" class="chip ${mapFilter === f ? "on" : ""}" data-f="${esc(f)}">${esc(f)}</button>`).join("")}</div></div>
    <div class="legend">${CONFIG.statuses.map(s => `<span style="--c:${STATUS_COLOUR[s]}">${esc(s)}</span>`).join("")}</div>
    <div class="bigmap" id="bigMap"></div>
    <p class="muted small" id="mapNote"></p>`;
  bigMap = L.map("bigMap").setView(CONFIG.mapCentre, CONFIG.mapZoom);
  tiles().addTo(bigMap);
  let layer = L.layerGroup().addTo(bigMap);
  const draw = () => {
    layer.clearLayers();
    const jobs = state.jobs.filter(j => {
      if (mapFilter === "Open") return !["Completed", "Invoiced", "Cancelled"].includes(j["Status"]);
      if (mapFilter === "All") return true; return j["Status"] === mapFilter;
    });
    const pinned = jobs.filter(j => j["Latitude"] !== "" && j["Latitude"] != null && !isNaN(Number(j["Latitude"])) && !isNaN(Number(j["Longitude"])));
    pinned.forEach(j => {
      L.marker([Number(j["Latitude"]), Number(j["Longitude"])], { icon: pinIcon(j["Status"]) }).addTo(layer)
        .bindPopup(`<strong>${esc(j["Title"])}</strong><br>${esc(j["Client Name"] || "")}${j["Site Name"] ? "<br>" + esc(j["Site Name"]) : ""}<br>${pill(j["Status"])} ${esc(fmtDate(j["Start Date"]))}<br><a href="#/jobs/${esc(j["Job ID"])}">Open job</a> &nbsp; ${dirLink(j)}`);
    });
    jobs.forEach(j => { const pois = parseJson(j["POIs"], []); if (Array.isArray(pois)) pois.forEach(p => { if (!isNaN(Number(p.lat))) L.marker([Number(p.lat), Number(p.lng)], { icon: L.divIcon({ className: "", html: `<div class="poi-dot"></div>`, iconSize: [12, 12], iconAnchor: [6, 6], popupAnchor: [0, -8] }) }).addTo(layer).bindPopup(`<strong>${esc(p.name || "Point")}</strong><br>${esc(j["Title"])}<br>${dirLink({ Latitude: p.lat, Longitude: p.lng })}`); }); });
    if (pinned.length) bigMap.fitBounds(L.latLngBounds(pinned.map(j => [Number(j["Latitude"]), Number(j["Longitude"])])).pad(0.2), { maxZoom: 13 });
    $("#mapNote").textContent = `${pinned.length} of ${jobs.length} jobs have a map pin.` + (jobs.length - pinned.length ? " Open a job and use Find on map to add the rest." : "");
  };
  v.querySelectorAll(".chip").forEach(c => c.addEventListener("click", () => { mapFilter = c.dataset.f; v.querySelectorAll(".chip").forEach(x => x.classList.toggle("on", x === c)); draw(); }));
  draw();
  setTimeout(() => bigMap.invalidateSize(), 50);
}

/* ---------- tools ---------- */
function renderTools(v) {
  v.innerHTML = `
    <div class="page-head"><div><h1>Field tools</h1><p class="muted">Field forms work offline once opened and send to the same sheet.</p></div></div>
    <div class="tools">
      <a class="tool" href="field-report.html"><h3>Field survey</h3><p>Den sites, activity status, signs, weeds and other observations with GPS and photos.</p></a>
      <a class="tool" href="pest-report.html"><h3>Job log</h3><p>Every site visit: pre-feeds, baiting, trapping, shooting, cleaning, deterrent installs, checks and collections. Quick log for known sites, full safety and survey flow for new ones.</p></a>
      <a class="tool" href="firearm-log.html"><h3>Firearm log</h3><p>Withdrawal and return register with rounds taken, used and left. Shooting activity is recorded in the Job log.</p></a>
    </div>
    <div class="tools" style="margin-top:16px">
      <a class="tool" href="#/chemicals"><h3>Chemicals</h3><p>SDS register, manifest and stock.</p></a>
      <a class="tool" href="#/documents"><h3>Documents</h3><p>Policies, procedures, registers and forms.</p></a>
      <a class="tool" href="#/team"><h3>Team</h3><p>Register of employees and licences.</p></a>
      <a class="tool" href="#/sms"><h3>SMS</h3><p>Safety management system: emergency plan, SWMS, procedures, pre-site screens, templates. Review dates and sign-offs.</p></a>
      <a class="tool" href="#/culls"><h3>Cull register</h3><p>What was culled, where and when. Totals by year, species and client.</p></a>
    </div>
    <div class="card" style="margin-top:16px"><h2>Recent field reports</h2>${activityList(state.activity)}</div>`;
}

/* ---------- start ---------- */
(async function start() {
  const token = localStorage.getItem(CONFIG.tokenKey);
  const user = JSON.parse(localStorage.getItem(CONFIG.userKey) || "null");
  if (token && user) {
    setLoggedIn(token, user);
    loadCache();
    if (!location.hash || location.hash === "#/") location.hash = "#/dashboard"; else route();
    await bootstrap();
    route();
  } else {
    $("#loginView").hidden = false;
  }
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => { });
})();
