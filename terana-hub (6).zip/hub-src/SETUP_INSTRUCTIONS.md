# Terana Hub, setup (October 2026)

The hub sits on top of the existing field tools. Same Google Sheet, same
Apps Script Web App URL, same Netlify project. Nothing about the three
field forms has changed except the shared service worker.

**Sheet ID:** `1BQk_ur0I2FfsdurlfEgHa9k3YkUeLZpDO-u9FQIaBgg`

## Step 1. Update the Apps Script

1. Open the Google Sheet, then Extensions > Apps Script.
2. Select everything in the editor (Cmd+A), delete it, paste in the full
   contents of `AppsScript-Code.gs`, save.
3. In the function dropdown at the top, choose `setupHubTabs` and click Run.
   Approve the permissions if asked. This creates the Users, Sessions,
   Clients and Jobs tabs.
4. Deploy > Manage deployments > pencil icon > Version: New version > Deploy.
   The Web App URL does not change.

## Step 2. Set your passcode

Open the **Users** tab in the Sheet. Replace `CHANGE-ME` with the passcode
you want. Add one row per staff member: Name, Email, Passcode, Role
(`admin` or `staff`), Status (`Active`).

Passcodes are stored as plain text in this private sheet. Anyone who can
open the sheet can read them, so keep the sheet shared only with you.

## Step 3. Put the hub live

Upload every file in this folder to the Netlify project (drag onto the
deploy area, or push to the connected repository). Open the site and log
in with your email and passcode.

## Step 4. Put the updated website live

The website's enquiry and calculator forms now send to the Apps Script
instead of Formspree. Upload the new website files (terana-site.zip) to
the website's GitHub repository as before. Each enquiry becomes a job
with status Enquiry, the client is created from the form, and the
notification email still arrives at courtney@teranaenvironmental.com.au
(sent by the Google account that owns the sheet, with reply-to set to
the enquirer). Formspree can be cancelled once this is live.

## What's in the hub

- **Dashboard**: active jobs, jobs starting in the next 7 days, open
  enquiries and quotes, actions due, coming up, next actions, completed
  but not invoiced, recent field reports.
- **Jobs**: list with status filters and search. Each job has client,
  service, status, priority, dates, assigned technician, quote value,
  site name and address, a map pin (address lookup, device location, or
  tap the map), description, next action and date, notes.
- **Clients**: list and detail with that client's jobs.
- **Map**: every job with a pin, coloured by status, filterable.
- **Job report**: from a job, Draft report pulls every pest report and
  survey entry tied to that job (the forms now have a Job dropdown) into
  an editable draft. Build PDF saves a branded PDF to Drive under Job
  Reports / client name. Email client opens a pre-filled email in your
  mail app (you attach the PDF and send from the Terana address). Mark
  as sent sets the job to Completed with next action Invoice.
- **Directions**: every job and client with an address or pin has a
  Directions link that opens Google Maps navigation.
- **Field tools**: the three existing forms, now with a Job dropdown
  (needs the hub login on that device).

Reads are cached on the device, so the hub can be looked at without
signal. Saving a job or client needs a connection.

## Sheet tabs

Data tabs: Fox Den Surveys, Pest Reports, Pesticide Applications,
Shooting Activities, Firearm Movements, Clients, Jobs.
Reports (one row per job report draft).
Reference tabs: Products, Firearms, Technicians, Locations, Users.
System tab: Sessions (login tokens, pruned automatically).

## Any time the Apps Script changes

Deploy > Manage deployments > edit > New version > Deploy. Editing the
existing deployment keeps the URL.
