/**
 * ============================================================
 * Terana Field Data Receiver — Google Apps Script
 * ============================================================
 * Single Web App shared across Terana's field tools. Each form
 * sends a "formType" tag in its payload; this script routes the
 * submission to the correct Sheet tab, and handles photo uploads
 * to Drive for all tools.
 *
 * Currently handles:
 *   - "fox_den"          — Fox Den Survey (field-report.html)
 *   - "pest_report"       — Pest Management Report (pest-report.html)
 *   - "firearm_movement"  — Firearm withdrawal/return register,
 *                            Firearms Regulations 2024 reg. 48
 *   - "shooting_activity" — Shooting activity record,
 *                            Firearms Regulations 2024 reg. 81
 *                            (Professional Shooter Business Licence)
 *
 * If a pest_report submission has firearmUsed=true, a matching
 * shooting_activity row is also written automatically, so a
 * shooting-involved pest job stays compliant without double entry.
 *
 * doGet supports:
 *   ?action=products   — live product list (Products tab)
 *   ?action=firearms   — live firearm list (Firearms tab)
 *   ?action=locations  — live survey location list (Locations tab)
 *
 * Hub API (POST with an "action" field instead of "formType"):
 *   login, logout, me, listClients, saveClient, listJobs, saveJob,
 *   deleteJob, recentActivity, bootstrap — token-checked against the
 *   Users and Sessions tabs. See the HUB section at the end.
 *
 * ONE-TIME SETUP — see SETUP_INSTRUCTIONS.md
 * ============================================================
 */

const SHEET_ID = "1BQk_ur0I2FfsdurlfEgHa9k3YkUeLZpDO-u9FQIaBgg";
const PHOTO_FOLDER_NAME = "Field Survey Photos";
const PRODUCTS_TAB_NAME = "Products";
const FIREARMS_TAB_NAME = "Firearms";
const TECHNICIANS_TAB_NAME = "Technicians";
const LOCATIONS_TAB_NAME = "Locations";

/* ============================================================
   ROUTING
   ============================================================ */
function doPost(e) {
  // Serializes concurrent submissions (e.g. two near-simultaneous retries of
  // the same queued offline entry) so the duplicate-submission checks in the
  // handlers below — which look, then write — can't both look before either
  // writes, which is what let the same photos land in Drive twice.
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    let payload;
    try { payload = JSON.parse(e.postData.contents); }
    catch (parseErr) {
      // Not JSON: this is the website enquiry or calculator form (FormData).
      return handleWebsiteEnquiry(e.parameter || {});
    }
    // Hub API (login, clients, jobs, activity) — see HUB section at the end of this file.
    if (payload.action) return handleHubAction(payload);
    // Field form submissions need a hub login on the device (the forms send the hub token).
    if (!getSession(payload.token)) return jsonResponse({ status: "error", code: "auth", message: "Log in to the hub on this device, then send again." });
    const formType = payload.formType || "fox_den"; // default keeps old Fox Den submissions working
    if (formType === "fox_den") return handleFoxDen(payload);
    if (formType === "pest_report") return handlePestReport(payload);
    if (formType === "firearm_movement") return handleFirearmMovement(payload);
    if (formType === "shooting_activity") return handleShootingActivity(payload.activity || {}, true);
    return jsonResponse({ status: "error", message: "Unknown formType: " + formType });
  } catch (err) {
    return jsonResponse({ status: "error", message: err.message });
  } finally {
    lock.releaseLock();
  }
}

function doGet(e) {
  const action = e.parameter && e.parameter.action;
  if (action === "signDoc") return publicSignDoc(e.parameter.t || "");   // public by design: only the link token identifies the document
  if (!action) return jsonResponse({ status: "ok", message: "Terana field data receiver is running." });
  // Everything else needs a hub login. The field forms carry the hub token.
  if (!getSession(e.parameter.token)) return jsonResponse({ status: "error", code: "auth", message: "Log in to the hub on this device first." });
  if (action === "products") return jsonResponse({ status: "success", products: getProducts() });
  if (action === "firearms") return jsonResponse({ status: "success", firearms: getFirearms() });
  if (action === "technicians") return jsonResponse({ status: "success", technicians: getTechnicians() });
  if (action === "locations") return jsonResponse({ status: "success", locations: getLocations() });
  if (action === "deployed") return jsonResponse({ status: "success", deployed: deployedFirearms() });
  if (action === "jobs") return jsonResponse({ status: "success", jobs: openJobsForForms() });
  return jsonResponse({ status: "ok", message: "Terana field data receiver is running. POST data to submit." });
}

/* ============================================================
   FOX DEN SURVEY
   ============================================================ */
const FOX_DEN_TAB_NAME = "Fox Den Surveys";
const FOX_DEN_HEADERS = [
  "Server Timestamp", "Submission ID", "Client Timestamp",
  "Date", "Reporter", "Dog Name",
  "Entry #", "Date/Time", "Location", "Site Number", "Entrance Count",
  "Activity Status", "Signs Observed", "Likely Species", "GPS Points",
  // "Other Species" / "Other Count" / "Other GPS Points" — the ORIGINAL
  // Aug 2026 columns, confirmed still present as the live header row
  // (Apps Script only writes headers when a sheet is completely empty, so
  // this sheet's row 1 was never updated by any later version of this
  // script). Kept here, always blank, so column positions stay correct —
  // do NOT remove without also physically deleting the matching sheet
  // columns, or every column after this point will misalign.
  "Other Species", "Other Count", "Other GPS Points",
  "Notes", "Incidents", "Photo Links",
  // Added Sept 2026 — always appended at the END, never inserted mid-sheet,
  // so existing rows and any script that writes by position stay intact.
  "Row Key", "Latitude", "Longitude", "GPS Accuracy (m)",
  "Wind Direction", "Wind Speed",
  "Entry Type", "Weed Species", "POI Category",
  // Added Oct 2026 for the hub.
  "Job ID", "Job Title"
];

function handleFoxDen(payload) {
  const sheet = getOrCreateSheet(FOX_DEN_TAB_NAME, FOX_DEN_HEADERS);
  const session = payload.session || {};
  const entries = payload.entries || [];

  if (entries.length === 0) return jsonResponse({ status: "success", rowsAdded: 0 });

  const firstWithLocation = entries.find(e => e.location) || {};
  const dayFolder = getOrCreateFoxDenDayFolder(session.date, firstWithLocation.location, session.jobId);

  // Keep the Locations tab current with anything new typed in the field,
  // so it's offered as a suggestion on every device next time.
  const seenLocations = {};
  entries.forEach(entry => { if (entry.location) seenLocations[entry.location] = true; });
  Object.keys(seenLocations).forEach(loc => addLocationIfNew(loc));

  let upserted = 0, inserted = 0;
  entries.forEach(entry => {
    // entry.id is generated once on the device when the entry is first
    // created and never changes — using it as the key (rather than a
    // per-submit-attempt session ID) means even a manual re-press of
    // Submit for the same entries updates the same row instead of
    // duplicating it.
    const rowKey = entry.id || ((session.submissionId || "") + "_" + (entry.num || ""));
    // If this rowKey was already written by an earlier attempt at this same
    // submission (e.g. the request succeeded last time but the response
    // never reached the device, so it got queued and retried), reuse its
    // Photo Links instead of re-uploading the same photos to Drive.
    const existingPhotoLinks = getExistingCellValue(sheet, FOX_DEN_HEADERS, "Row Key", rowKey, "Photo Links");
    const photoLinks = existingPhotoLinks !== null
      ? existingPhotoLinks
      : saveFoxDenPhotos(entry.photos || [], dayFolder, session.date, entry);
    const primaryPoint = (entry.gpsPoints && entry.gpsPoints[0]) || {};

    const row = [
      new Date(), session.submissionId || "", session.clientTimestamp || "",
      session.date || "", session.reporter || "", session.dogName || "",
      entry.num || "", entry.datetime || "", entry.location || "", entry.siteNumber || "", entry.entranceCount || 0,
      entry.activityStatus || "", entry.signsText || "", entry.speciesIndicated || "", formatGpsPoints(entry.gpsPoints),
      "", "", "", // Other Species / Other Count / Other GPS Points — retired, kept blank (see header comment)
      entry.notes || "", entry.incidents || "", photoLinks,
      rowKey, primaryPoint.decimalLat || "", primaryPoint.decimalLng || "", primaryPoint.accuracy || "",
      session.windDirection || "", session.windSpeed || "",
      entry.entryType || "Den / Site", entry.weedSpecies || "", entry.poiCategoryText || "",
      session.jobId || "", session.jobTitle || ""
    ];

    const result = upsertRow(sheet, FOX_DEN_HEADERS, "Row Key", rowKey, row);
    if (result.updated) upserted++; else inserted++;
  });

  return jsonResponse({ status: "success", rowsAdded: inserted, rowsUpdated: upserted });
}

/**
 * One folder per survey day + site, e.g. "20260904 Roe 8 Biyara", created
 * inside the main photo folder. Falls back to just the date if no site
 * name is available yet (shouldn't normally happen since Location is
 * required on the form).
 */
function getOrCreateFoxDenDayFolder(dateStr, siteName, jobId) {
  const cf = jobId ? clientFolderForJob(jobId) : null;
  const parent = cf ? getOrCreateSubFolder(cf, "Field surveys") : getOrCreatePhotoFolder();
  const safeDate = (dateStr || "unknown").replace(/[^0-9]/g, "");
  const folderName = safeDate + (siteName ? " " + siteName : "");
  const existing = parent.getFoldersByName(folderName);
  if (existing.hasNext()) return existing.next();
  return parent.createFolder(folderName);
}

/**
 * Fox Den photo naming: [YYYYMMDD] [Site] [HHMM] [site no.] p[n].jpeg
 * Falls back to time alone if there's no site number.
 */
function saveFoxDenPhotos(photos, folder, dateStr, entry) {
  if (!photos || photos.length === 0) return "";
  const safeDate = (dateStr || "unknown").replace(/[^0-9]/g, "");
  const site = entry.location || "";
  let hhmm = "";
  if (entry.datetime) {
    const match = String(entry.datetime).match(/T(\d{2}):(\d{2})/);
    if (match) hhmm = match[1] + match[2];
  }
  const siteNo = entry.siteNumber ? String(entry.siteNumber) : "";
  const links = [];
  photos.forEach((dataUrl, idx) => {
    try {
      const matches = dataUrl.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (!matches) return;
      const mimeType = matches[1];
      const base64Data = matches[2];
      const ext = mimeType.split("/")[1] || "jpg";
      const parts = [safeDate, site, hhmm, siteNo].filter(Boolean);
      const filename = parts.join(" ") + " p" + (idx + 1) + "." + ext;
      const blob = Utilities.newBlob(Utilities.base64Decode(base64Data), mimeType, filename);
      const file = folder.createFile(blob);
      links.push(file.getUrl());
    } catch (photoErr) {
      links.push("ERROR saving photo: " + photoErr.message);
    }
  });
  return links.join(" | ");
}

/* ============================================================
   ONE-OFF BACKFILL — run manually from the Apps Script editor
   (select this function in the dropdown, click Run) to populate
   Latitude/Longitude for existing rows from the old GPS Points
   text field. Safe to re-run; skips rows that already have a
   Latitude value.
   ============================================================ */
/* ============================================================
   ONE-OFF HEADER REFRESH — run manually once, after redeploying
   this script, to bring the actual header row (row 1) up to date.
   Apps Script only writes headers when a sheet is completely
   empty, so a sheet that already has data keeps whatever header
   row it started with — this brings it in line with the current
   FOX_DEN_HEADERS list without touching any data rows below it.
   ============================================================ */
function refreshFoxDenHeaders() {
  const sheet = getOrCreateSheet(FOX_DEN_TAB_NAME, FOX_DEN_HEADERS);
  sheet.getRange(1, 1, 1, FOX_DEN_HEADERS.length).setValues([FOX_DEN_HEADERS]);
  sheet.setFrozenRows(1);
  Logger.log("Header row updated to " + FOX_DEN_HEADERS.length + " columns.");
}

function backfillFoxDenLatLng() {
  const sheet = getOrCreateSheet(FOX_DEN_TAB_NAME, FOX_DEN_HEADERS);
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const gpsCol = headers.indexOf("GPS Points") + 1;
  const latCol = headers.indexOf("Latitude") + 1;
  const lngCol = headers.indexOf("Longitude") + 1;
  const lastRow = sheet.getLastRow();
  if (lastRow < 2 || gpsCol === 0 || latCol === 0 || lngCol === 0) return;

  let filled = 0;
  for (let r = 2; r <= lastRow; r++) {
    const existingLat = sheet.getRange(r, latCol).getValue();
    if (existingLat) continue; // already backfilled
    const gpsText = String(sheet.getRange(r, gpsCol).getValue() || "");
    const firstPoint = gpsText.split("|")[0].trim();
    const parts = firstPoint.split("/");
    if (parts.length < 2) continue;
    const lat = parseDDMToDecimal(parts[0].trim());
    const lng = parseDDMToDecimal(parts[1].trim());
    if (lat === null || lng === null) continue;
    sheet.getRange(r, latCol).setValue(lat);
    sheet.getRange(r, lngCol).setValue(lng);
    filled++;
  }
  Logger.log("Backfilled " + filled + " row(s).");
}

function parseDDMToDecimal(ddm) {
  const match = String(ddm).match(/^([NSEW])\s*(\d+(?:\.\d+)?)\s*°\s*([\d.]+)'/);
  if (!match) return null;
  const letter = match[1];
  const degrees = parseFloat(match[2]);
  const minutes = parseFloat(match[3]);
  const decimal = degrees + (minutes / 60);
  return (letter === "S" || letter === "W") ? -decimal : decimal;
}

/* ============================================================
   LOCATIONS (live-editable, auto-grows as new sites are typed)
   ============================================================ */
function getLocations() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(LOCATIONS_TAB_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(LOCATIONS_TAB_NAME);
    sheet.appendRow(["Location Name"]);
    sheet.appendRow(["Bibra Lake"]);
    sheet.appendRow(["Roe 8 Corridor"]);
    sheet.setFrozenRows(1);
  }
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const data = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
  return data.filter(r => r[0]).map(r => String(r[0]));
}

function addLocationIfNew(name) {
  if (!name) return;
  const existing = getLocations();
  if (existing.some(l => l.toLowerCase() === name.toLowerCase())) return;
  const ss = SpreadsheetApp.openById(SHEET_ID);
  const sheet = ss.getSheetByName(LOCATIONS_TAB_NAME);
  sheet.appendRow([name]);
}

/* ============================================================
   PEST MANAGEMENT REPORT
   ============================================================ */
const PEST_REPORT_TAB_NAME = "Pest Reports";
const PEST_REPORT_HEADERS = [
  "Server Timestamp", "Submission ID", "Client Timestamp",
  "Date", "Technician", "LPMP Licence Number", "Technician Status", "Site / Client", "Existing Site",
  "Onsite Start", "Onsite Finish",
  "Job Type(s)", "Trapping", "Trapping Details", "Pesticide Pre-Feeding",
  // Safety (new-site full flow only)
  "Spill Kit Available", "MSDS On Site", "PPE Used", "Chemicals Locked Up", "First Aid Kit On Site",
  "Signage Displayed", "Safe To Commence",
  // Site survey (new-site full flow only)
  "Areas Inspected", "Pest Activity Observed", "Entry Points / Conducive Conditions", "Survey Notes",
  // Job report
  "Target Pest", "Pesticide Applied", "Product", "Active Constituent", "Quantity Used", "Application Method",
  "Batch Number", "Expiry Date", "Equipment Used", "Weather",
  "Temperature", "Rainfall", "Humidity", "Wind", "Chemical SWMS Acknowledged", "SWMS Signed Off By",
  "Number Trapped / Culled", "Reason For Cull", "Recommendations", "Next Visit Due",
  // Firearm use flag (feeds a linked Shooting Activities row automatically)
  "Firearm Used", "Shooting Activity Ref",
  // Pesticide application flag (feeds a linked Pesticide Applications row automatically)
  "Pesticide Application Ref",
  "Notes", "Incidents", "Photo Links",
  // Added Oct 2026 for the hub: which job this visit belongs to. Appended at the end.
  "Job ID", "Job Title", "Work Done", "Stage",
  "Photo Captions"   // one per photo, same order as Photo Links, joined with " | "
];

function handlePestReport(payload) {
  const sheet = getOrCreateSheet(PEST_REPORT_TAB_NAME, PEST_REPORT_HEADERS);
  const v = payload.visit || {};

  // A retried offline-queue submission resends the same Submission ID —
  // treat it as already recorded rather than re-uploading its photos to
  // Drive and appending a second row.
  if (findRowNumberByKey(sheet, PEST_REPORT_HEADERS, "Submission ID", v.submissionId)) {
    return jsonResponse({ status: "success", rowsAdded: 0 });
  }

  const timestamp = new Date();
  const folder = jobPhotoFolder(v.jobId, v.jobTitle, v.siteClient, v.date);
  const photoLinks = savePhotos(v.photos || [], folder, v.date, (v.siteClient || "visit").replace(/[^0-9a-zA-Z-]/g, "_"), v.photoCaptions || []);
  const photoCaptions = (v.photoCaptions || []).map(c => String(c || "").replace(/\|/g, "/")).join(" | ");

  let shootingRef = "";
  if (v.firearmUsed) {
    // Auto-record the matching Reg. 81 shooting activity so this stays
    // compliant without re-entering the same visit twice.
    const activityResult = handleShootingActivity({
      submissionId: v.submissionId, clientTimestamp: v.clientTimestamp,
      date: v.date, shooter: v.technician,
      customerName: v.customerName || v.siteClient, customerContact: v.customerContact || "",
      address: v.shootAddress || v.siteClient,
      activityType: v.shootingActivityType || "",
      species: v.shootSpecies || v.targetPest || "",
      gpsPoint: v.gpsPoint || "",
      numberDispatched: v.numberTrappedCulled || 0,
      firearmUsed: v.firearmDetails || "",
      ammunitionUsed: v.ammunitionUsed || "",
      roundsUsed: v.roundsUsed,
      jobId: v.jobId || "",
      notes: "Auto-logged from Job Log " + (v.submissionId || "")
    }, false);
    shootingRef = activityResult;
  }

  let pesticideRef = "";
  if (v.product) {
    // Auto-record to the Pesticide Applications tab so every chemical
    // application is visible in one place without digging through the
    // full Pest Reports tab.
    pesticideRef = recordPesticideApplication(v);
    try { recordChemicalUse(v); } catch (e) { Logger.log("Stock update failed: " + e); }
  }

  const row = [
    timestamp, v.submissionId || "", v.clientTimestamp || "",
    v.date || "", v.technician || "", v.lpmpLicenceNumber || "", v.technicianStatus || "", v.siteClient || "", v.existingSite ? "Yes" : "No",
    v.onsiteStart || "", v.onsiteFinish || "",
    v.jobTypes || "", v.trapping ? "Yes" : "No", v.trappingDetails || "", v.pesticidePreFeeding ? "Yes" : "No",
    v.spillKit || "", v.msdsOnSite || "", v.ppeUsed || "", v.chemicalsLocked || "", v.firstAidKit || "",
    v.signageDisplayed || "", v.safeToCommence || "",
    v.areasInspected || "", v.pestActivity || "", v.entryPoints || "", v.surveyNotes || "",
    v.targetPest || "", v.pesticideApplied ? "Yes" : "No", v.product || "", v.activeConstituent || "", v.quantityUsed || "", v.applicationMethod || "",
    v.batchNumber || "", v.expiryDate || "", v.equipmentUsed || "", v.weather || "",
    v.temperature || "", v.rainfall || "", v.humidity || "", v.wind || "",
    v.swmsAck ? "Yes" : "No", v.swmsSignedBy || "",
    v.numberTrappedCulled || 0, v.cullReason || "", v.recommendations || "", v.nextVisitDue || "",
    v.firearmUsed ? "Yes" : "No", shootingRef,
    pesticideRef,
    v.notes || "", v.incidents || "", photoLinks,
    v.jobId || "", v.jobTitle || "", v.workDone || "", v.stage || "",
    photoCaptions
  ];

  sheet.getRange(sheet.getLastRow() + 1, 1, 1, PEST_REPORT_HEADERS.length).setValues([row]);
  if (v.jobId && v.stage) markStageDone(v.jobId, v.stage);
  try { recordCulls(v); } catch (e) { Logger.log("Cull register: " + e); }
  return jsonResponse({ status: "success", rowsAdded: 1 });
}

/* ============================================================
   PESTICIDE APPLICATIONS — auto-populated list of every chemical
   application across all pest reports, for at-a-glance access
   without digging through the full Pest Reports tab.
   ============================================================ */
const PESTICIDE_APPLICATIONS_TAB_NAME = "Pesticide Applications";
const PESTICIDE_APPLICATIONS_HEADERS = [
  "Server Timestamp", "Submission ID",
  "Date", "Technician", "Site / Client", "Target Pest",
  "Product", "Active Constituent", "Quantity Used", "Application Method",
  "Batch Number", "Expiry Date", "Equipment Used", "Weather",
  "Temperature", "Rainfall", "Humidity", "Wind",
  "Chemical SWMS Acknowledged", "SWMS Signed Off By"
];

function recordPesticideApplication(v) {
  const sheet = getOrCreateSheet(PESTICIDE_APPLICATIONS_TAB_NAME, PESTICIDE_APPLICATIONS_HEADERS);
  const timestamp = new Date();
  const row = [
    timestamp, v.submissionId || "",
    v.date || "", v.technician || "", v.siteClient || "", v.targetPest || "",
    v.product || "", v.activeConstituent || "", v.quantityUsed || "", v.applicationMethod || "",
    v.batchNumber || "", v.expiryDate || "", v.equipmentUsed || "", v.weather || "",
    v.temperature || "", v.rainfall || "", v.humidity || "", v.wind || "",
    v.swmsAck ? "Yes" : "No", v.swmsSignedBy || ""
  ];
  sheet.getRange(sheet.getLastRow() + 1, 1, 1, PESTICIDE_APPLICATIONS_HEADERS.length).setValues([row]);
  return "Row " + sheet.getLastRow() + " (" + (v.submissionId || "") + ")";
}

/* ============================================================
   FIREARM MOVEMENTS — Firearms Regulations 2024 reg. 48
   Record of every withdrawal/return of a firearm, major part, or
   ammunition from compliant storage.
   ============================================================ */
const FIREARM_MOVEMENTS_TAB_NAME = "Firearm Movements";
const FIREARM_MOVEMENTS_HEADERS = [
  "Server Timestamp", "Submission ID", "Client Timestamp",
  "Date/Time", "Movement Type", "Person", "Firearm / Item", "Serial Number",
  "Quantity", "Type (if ammunition)", "Reason", "Notes",
  // Added Oct 2026: job link and the ammunition count for the hub's deployed view.
  "Job ID", "Job Title", "Rounds Taken", "Rounds Used", "Rounds Returned"
];

function handleFirearmMovement(payload) {
  const sheet = getOrCreateSheet(FIREARM_MOVEMENTS_TAB_NAME, FIREARM_MOVEMENTS_HEADERS);
  const m = payload.movement || {};
  const timestamp = new Date();

  const row = [
    timestamp, m.submissionId || "", m.clientTimestamp || "",
    m.datetime || "", m.movementType || "", m.person || "", m.itemName || "", m.serialNumber || "",
    m.quantity || "", m.ammoType || "", m.reason || "", m.notes || "",
    m.jobId || "", m.jobTitle || "", m.roundsTaken === "" || m.roundsTaken == null ? "" : Number(m.roundsTaken),
    m.roundsUsed === "" || m.roundsUsed == null ? "" : Number(m.roundsUsed), m.roundsReturned === "" || m.roundsReturned == null ? "" : Number(m.roundsReturned)
  ];

  sheet.getRange(sheet.getLastRow() + 1, 1, 1, FIREARM_MOVEMENTS_HEADERS.length).setValues([row]);
  return jsonResponse({ status: "success", rowsAdded: 1 });
}

/* ============================================================
   SHOOTING ACTIVITIES — Firearms Regulations 2024 reg. 81
   Record of each shooting activity (sedation, culling, euthanasia,
   or other humane destruction) carried out as a professional
   shooting service for a customer.
   ============================================================ */
const SHOOTING_ACTIVITIES_TAB_NAME = "Shooting Activities";
const SHOOTING_ACTIVITIES_HEADERS = [
  "Server Timestamp", "Submission ID", "Client Timestamp",
  "Date", "Shooter", "Customer Name", "Customer Contact", "Address",
  "Activity Type", "Species", "Number Dispatched",
  "Firearm Used", "Ammunition Used", "GPS Point", "Notes", "Photo Links",
  // Added Oct 2026.
  "Rounds Used", "Job ID"
];

/**
 * Shared by the dedicated Firearm Deployment Logger AND automatically
 * from Pest Report when firearmUsed is ticked.
 * standalone=true means it also handles its own photos/folder and
 * returns a jsonResponse; standalone=false (called internally from
 * handlePestReport) just appends the row and returns a short ref string.
 */
function handleShootingActivity(a, standalone) {
  const sheet = getOrCreateSheet(SHOOTING_ACTIVITIES_TAB_NAME, SHOOTING_ACTIVITIES_HEADERS);

  // Same idempotency guard as Pest Report: a retried submission — whether
  // standalone from the Firearm Log or auto-logged from a retried Pest
  // Report — must not re-upload its photos to Drive or append a second row.
  const existingRow = findRowNumberByKey(sheet, SHOOTING_ACTIVITIES_HEADERS, "Submission ID", a.submissionId);
  if (existingRow) {
    return standalone
      ? jsonResponse({ status: "success", rowsAdded: 0 })
      : "Row " + existingRow + " (" + (a.submissionId || "") + ")";
  }

  const timestamp = new Date();
  let photoLinks = "";
  if (standalone) {
    const folder = getOrCreatePhotoFolder();
    photoLinks = savePhotos(a.photos || [], folder, a.date, (a.customerName || "shoot").replace(/[^0-9a-zA-Z-]/g, "_"));
  }

  const row = [
    timestamp, a.submissionId || "", a.clientTimestamp || "",
    a.date || "", a.shooter || "", a.customerName || "", a.customerContact || "", a.address || "",
    a.activityType || "", a.species || "", a.numberDispatched || 0,
    a.firearmUsed || "", a.ammunitionUsed || "", a.gpsPoint || "", a.notes || "", photoLinks,
    a.roundsUsed === "" || a.roundsUsed == null ? "" : Number(a.roundsUsed), a.jobId || ""
  ];

  sheet.getRange(sheet.getLastRow() + 1, 1, 1, SHOOTING_ACTIVITIES_HEADERS.length).setValues([row]);

  if (standalone) return jsonResponse({ status: "success", rowsAdded: 1 });
  return "Row " + sheet.getLastRow() + " (" + (a.submissionId || "") + ")";
}

/* ============================================================
   PRODUCTS (live-editable dropdown source)
   ============================================================ */
function getProducts() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(PRODUCTS_TAB_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(PRODUCTS_TAB_NAME);
    sheet.appendRow(["Product Name", "Active Constituent", "SDS Link"]);
    sheet.appendRow(["Example Product (edit/replace this row)", "Example Active Constituent", ""]);
    sheet.setFrozenRows(1);
  }
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const width = Math.max(3, sheet.getLastColumn());
  const hdr = sheet.getRange(1, 1, 1, width).getValues()[0].map(String);
  const col = n => hdr.indexOf(n);
  const data = sheet.getRange(2, 1, lastRow - 1, width).getValues();
  return data
    .filter(r => r[0] && String(col("Status") >= 0 ? r[col("Status")] : "") !== "Retired")
    .map(r => ({ name: String(r[0]), activeConstituent: String(r[1] || ""), sdsLink: String(r[2] || ""),
      unit: col("Unit") >= 0 ? String(r[col("Unit")] || "") : "", onHand: col("Quantity On Hand") >= 0 ? r[col("Quantity On Hand")] : "", packSize: col("Pack Size") >= 0 ? r[col("Pack Size")] : "" }));
}

/* ============================================================
   FIREARMS (live-editable dropdown source — Make/Model/Serial)
   ============================================================ */
const FIREARMS_HEADERS = ["Make", "Model", "Calibre", "Serial Number", "Category", "Description", "Licence Number", "Status"];
// Reads by header name, so an older tab with the columns in a different order still works.
function getFirearms() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(FIREARMS_TAB_NAME);
  if (!sheet) { sheet = ss.insertSheet(FIREARMS_TAB_NAME); sheet.appendRow(FIREARMS_HEADERS); sheet.setFrozenRows(1); }
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const width = sheet.getLastColumn();
  const hdr = sheet.getRange(1, 1, 1, width).getValues()[0].map(h => String(h).trim().toLowerCase());
  const col = (names) => { for (const n of names) { const i = hdr.indexOf(n.toLowerCase()); if (i >= 0) return i; } return -1; };
  const cMake = col(["Make"]), cModel = col(["Model"]), cCal = col(["Calibre", "Calibre / Ammunition", "Cal"]), cSer = col(["Serial Number", "Serial", "Serial No."]), cCat = col(["Category", "Cat"]), cDesc = col(["Description"]), cLic = col(["Licence Number", "Licence"]), cStat = col(["Status"]);
  const g = (r, i) => i >= 0 ? String(r[i] == null ? "" : r[i]).trim() : "";
  const data = sheet.getRange(2, 1, lastRow - 1, width).getValues();
  return data
    .filter(r => g(r, cMake) && !/^(retired|sold|disposed)$/i.test(g(r, cStat)))
    .map(r => {
      const make = g(r, cMake), model = g(r, cModel), serial = g(r, cSer), calibre = g(r, cCal), category = g(r, cCat).replace(/^Category\s*/i, "");
      return { make, model, serial, category, calibre, description: g(r, cDesc), licence: g(r, cLic), label: [calibre, make, model].filter(Boolean).join(" ") + (serial ? " (" + serial + ")" : "") };
    });
}
// Puts the Firearms tab into the licence order (Make, Model, Calibre, Serial, Cat, Description, Licence) keeping every row, then seeds the armoury if empty.
function rewriteFirearmsTab() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(FIREARMS_TAB_NAME);
  if (!sheet) { sheet = ss.insertSheet(FIREARMS_TAB_NAME); sheet.appendRow(FIREARMS_HEADERS); sheet.setFrozenRows(1); return; }
  const width = Math.max(1, sheet.getLastColumn()), last = sheet.getLastRow();
  const hdr = sheet.getRange(1, 1, 1, width).getValues()[0].map(h => String(h).trim());
  if (hdr.join("|") === FIREARMS_HEADERS.join("|")) return;
  const rows = last >= 2 ? sheet.getRange(2, 1, last - 1, width).getValues() : [];
  const low = hdr.map(h => h.toLowerCase());
  const pick = (r, names) => { for (const n of names) { const i = low.indexOf(n.toLowerCase()); if (i >= 0) return r[i]; } return ""; };
  const out = rows.filter(r => r.some(v => String(v).trim())).map(r => [pick(r, ["Make"]), pick(r, ["Model"]), pick(r, ["Calibre", "Calibre / Ammunition", "Cal"]), pick(r, ["Serial Number", "Serial", "Serial No."]), pick(r, ["Category", "Cat"]), pick(r, ["Description"]), pick(r, ["Licence Number", "Licence"]), pick(r, ["Status"]) || "In service"]);
  sheet.clearContents();
  sheet.getRange(1, 1, 1, FIREARMS_HEADERS.length).setValues([FIREARMS_HEADERS]); sheet.setFrozenRows(1);
  if (out.length) sheet.getRange(2, 1, out.length, FIREARMS_HEADERS.length).setValues(out);
}

/* ============================================================
   TECHNICIANS (live-editable dropdown source — Name + LPMP Licence)
   ============================================================ */
function getTechnicians() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(TECHNICIANS_TAB_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(TECHNICIANS_TAB_NAME);
    sheet.appendRow(["Name", "LPMP Licence Number", "Status", "Firearms Licence Number", "Firearms Authorised"]);
    sheet.appendRow(["Example Technician (edit/replace this row)", "000000", "Licensed", "", "Yes"]);
    sheet.setFrozenRows(1);
  }
  if (String(sheet.getRange(1, 4).getValue() || "") === "") sheet.getRange(1, 4, 1, 2).setValues([["Firearms Licence Number", "Firearms Authorised"]]);
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  const width = Math.max(5, sheet.getLastColumn());
  const hdr = sheet.getRange(1, 1, 1, width).getValues()[0].map(String);
  const endCol = hdr.indexOf("Date End of Employment");
  const data = sheet.getRange(2, 1, lastRow - 1, width).getValues();
  return data
    .filter(r => r[0] && !(endCol >= 0 && r[endCol]))   // people who have left drop out of the dropdowns
    .map(r => ({ name: String(r[0]), licenceNumber: String(r[1] || ""), status: String(r[2] || ""), firearmsLicence: String(r[3] || ""), firearmsAuthorised: /^y/i.test(String(r[4] || "")) }));
}

/* ============================================================
   SHARED HELPERS
   ============================================================ */
function getOrCreateSheet(tabName, headers) {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(tabName);
  if (!sheet) sheet = ss.insertSheet(tabName);
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(headers);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

/**
 * Row number (1-based) of the row whose keyColumnName cell exactly matches
 * keyValue, or 0 if there's no match. Shared by upsertRow and the
 * duplicate-submission checks that guard photo uploads to Drive.
 */
function findRowNumberByKey(sheet, headers, keyColumnName, keyValue) {
  const keyColIndex = headers.indexOf(keyColumnName) + 1; // 1-based
  if (keyColIndex === 0 || sheet.getLastRow() < 2 || !keyValue) return 0;
  const range = sheet.getRange(2, keyColIndex, sheet.getLastRow() - 1, 1);
  const finder = range.createTextFinder(String(keyValue)).matchEntireCell(true);
  const found = finder.findNext();
  return found ? found.getRow() : 0;
}

/**
 * Value already stored in valueColumnName for the row matching keyValue,
 * or null if no such row exists yet. Used to detect a retried submission
 * (row already written) so its Photo Links can be reused instead of
 * uploading the same photos to Drive again.
 */
function getExistingCellValue(sheet, headers, keyColumnName, keyValue, valueColumnName) {
  const row = findRowNumberByKey(sheet, headers, keyColumnName, keyValue);
  const valueColIndex = headers.indexOf(valueColumnName) + 1;
  if (!row || valueColIndex === 0) return null;
  return sheet.getRange(row, valueColIndex).getValue();
}

/**
 * Finds an existing row by an exact match in keyColumnName and overwrites
 * it, or appends a new row if no match is found. Used to make resubmission
 * safe (e.g. retried offline-queue submissions) — the same record sent
 * twice updates one row instead of creating a duplicate.
 */
function upsertRow(sheet, headers, keyColumnName, keyValue, rowValues) {
  const existingRow = findRowNumberByKey(sheet, headers, keyColumnName, keyValue);
  if (existingRow) {
    sheet.getRange(existingRow, 1, 1, headers.length).setValues([rowValues]);
    return { updated: true, row: existingRow };
  }
  sheet.getRange(sheet.getLastRow() + 1, 1, 1, headers.length).setValues([rowValues]);
  return { updated: false, row: sheet.getLastRow() };
}

function getOrCreatePhotoFolder() {
  const existing = DriveApp.getFoldersByName(PHOTO_FOLDER_NAME);
  if (existing.hasNext()) return existing.next();
  return DriveApp.createFolder(PHOTO_FOLDER_NAME);
}

function savePhotos(photos, folder, dateStr, labelPrefix, captions) {
  if (!photos || photos.length === 0) return "";
  const links = [];
  captions = captions || [];
  photos.forEach((dataUrl, idx) => {
    try {
      const matches = dataUrl.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (!matches) return;
      const mimeType = matches[1];
      const base64Data = matches[2];
      const ext = mimeType.split("/")[1] || "jpg";
      const safeDate = (dateStr || "unknown").replace(/[^0-9a-zA-Z-]/g, "");
      const cap = String(captions[idx] || "").trim();
      const filename = `${safeDate}_${labelPrefix}_photo${idx + 1}${cap ? " " + cap.replace(/[\\/:*?"<>|]/g, "").slice(0, 60) : ""}.${ext}`;
      const blob = Utilities.newBlob(Utilities.base64Decode(base64Data), mimeType, filename);
      const file = folder.createFile(blob);
      if (cap) { try { file.setDescription(cap); } catch (e) { } }
      links.push(file.getUrl());
    } catch (photoErr) {
      links.push("ERROR saving photo: " + photoErr.message);
    }
  });
  return links.join(" | ");
}

function formatGpsPoints(points) {
  if (!points || points.length === 0) return "";
  return points.filter(p => p.lat || p.lng).map(p => `${p.lat} / ${p.lng}`).join(" | ");
}

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}


/* ============================================================
   HUB — management views (Terana Hub). Everything below is new
   in October 2026 and is reached only through doPost payloads
   that carry an "action" field. The field form handlers above
   are untouched.

   Tabs:
     Users     — Name, Email, Passcode, Role, Status   (you edit this by hand)
     Sessions  — login tokens, created by the script
     Clients   — one row per client
     Jobs      — one row per job
   ============================================================ */
const USERS_TAB_NAME = "Users";
const USERS_HEADERS = ["Name", "Email", "Passcode", "Role", "Status", "TOTP Secret", "Two Step"];   // Two Step: On once the authenticator app is set up
const SESSIONS_TAB_NAME = "Sessions";
const SESSIONS_HEADERS = ["Token", "Email", "Name", "Role", "Created", "Expires"];
const SESSION_DAYS = 30;

const CLIENTS_TAB_NAME = "Clients";
const CLIENTS_HEADERS = [
  "Client ID", "Name", "Contact Name", "Email", "Phone", "Address", "Client Type",
  "Notes", "Status", "Created", "Updated", "Updated By",
  // Added 15 Oct 2026 to line up with Xero contacts. Appended at the end;
  // ensureHubHeaders() adds them to an existing tab without touching data.
  "First Name", "Last Name", "Mobile", "Street", "City", "State", "Postcode", "ABN", "Xero Contact ID",
  // One Drive folder per client; photos, reports and permissions file under it.
  "Drive Folder ID", "Drive Folder URL"
];
const JOBS_TAB_NAME = "Jobs";
const JOBS_HEADERS = [
  "Job ID", "Client ID", "Client Name", "Title", "Service", "Site Name", "Site Address",
  "Latitude", "Longitude", "Status", "Priority", "Start Date", "End Date", "Assigned To",
  "Quote Value", "Description", "Next Action", "Next Action Date", "Notes",
  "Created", "Updated", "Updated By",
  // Added 15 Oct 2026. JSON text: POIs [{name,lat,lng,notes}], Stages [{name,start,end,status,notes}].
  "POIs", "Stages",
  "Planning"   // JSON {equipment:[{item,done}], consumables:[{product,qty,unit,done}], documents:[{name,docId,link,needed,ready}], notes}
];
const JOB_STATUSES = ["Enquiry", "Quoted", "Scheduled", "In Progress", "Completed", "Invoiced", "Cancelled"];

function handleHubAction(p) {
  const action = p.action;
  if (action === "login") return hubLogin(p);
  if (action === "login2fa") return hubLogin2fa(p);
  if (action === "ping") return jsonResponse({ status: "success", hub: true });
  if (action === "signComplete") return signComplete(p);   // public: the signer has no login, the link token is the key
  const session = getSession(p.token);
  if (!session) return jsonResponse({ status: "error", code: "auth", message: "Please log in again." });
  if (action === "logout") return hubLogout(p.token);
  if (action === "me") return jsonResponse({ status: "success", user: session });
  if (action === "totpSetup") return hubTotpSetup(session);
  if (action === "totpConfirm") return hubTotpConfirm(p, session);
  if (action === "totpOff") return hubTotpOff(p, session);
  if (action === "twoStepStatus") { const u = readTable(USERS_TAB_NAME, USERS_HEADERS, true).find(x => String(x["Email"] || "").trim().toLowerCase() === session.email) || {}; return jsonResponse({ status: "success", on: /^on$/i.test(String(u["Two Step"] || "")) }); }
  if (action === "bootstrap") return jsonResponse({
    status: "success", user: session,
    clients: readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS),
    jobs: readTable(JOBS_TAB_NAME, JOBS_HEADERS),
    permissions: readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS).map(r => ({ "Permission ID": r["Permission ID"], "Job ID": r["Job ID"], "Client ID": r["Client ID"], "Scope": r["Scope"] || "Job", "Status": r["Status"] || (r["PDF URL"] ? "Signed" : "Draft"), "Valid From": r["Valid From"], "Valid To": r["Valid To"], "Signed By": r["Signed By"], "Signed Date": r["Signed Date"], "PDF URL": r["PDF URL"] })),
    agreements: readTable(SIGN_TAB_NAME, SIGN_HEADERS).filter(d => d["Scope"] === "Client" && d["Status"] !== "Void").map(slimAgreement),
    documents: readTable(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS).filter(d => d["Status"] !== "Archived").map(d => ({ "Doc ID": d["Doc ID"], "Doc No": d["Doc No"], "Title": d["Title"], "Category": d["Category"], "Type": d["Type"], "Link": d["Link"], "Last Reviewed": d["Last Reviewed"], "Review Date": d["Review Date"], "Review Months": d["Review Months"], "Drive File ID": d["Drive File ID"] })),
    reports: readTable(REPORTS_TAB_NAME, REPORTS_HEADERS).map(r => ({ "Report ID": r["Report ID"], "Job ID": r["Job ID"], "PDF URL": r["PDF URL"], "Sent Date": r["Sent Date"], "Updated": r["Updated"] })),
    technicians: getTechnicians(),
    activity: recentActivity(25),
    statuses: JOB_STATUSES
  });
  if (action === "listClients") return jsonResponse({ status: "success", clients: readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS) });
  if (action === "saveClient") return hubSaveClient(p.client || {}, session);
  if (action === "listJobs") return jsonResponse({ status: "success", jobs: readTable(JOBS_TAB_NAME, JOBS_HEADERS) });
  if (action === "saveJob") return hubSaveJob(p.job || {}, session);
  if (action === "deleteJob") return hubDeleteJob(p.jobId, session);
  if (action === "recentActivity") return jsonResponse({ status: "success", activity: recentActivity(p.limit || 25) });
  if (action === "getPermission") return hubGetPermission(p.jobId, p.clientId);
  if (action === "savePermission") return hubSavePermission(p.permission || {}, p.signatureDataUrl || "", p.mapDataUrl || "", session, p);
  if (action === "listProducts") return jsonResponse({ status: "success", products: readTable(PRODUCTS_TAB_NAME, PRODUCTS_HEADERS), applications: tailRows(PESTICIDE_APPLICATIONS_TAB_NAME, 50), movements: tailRows(CHEMICAL_MOVEMENTS_TAB_NAME, 200), settings: publicSettings() });
  if (action === "saveProduct") return hubSaveProduct(p.product || {}, session);
  if (action === "stockMove") return hubStockMove(p.move || {}, session);
  if (action === "listCulls") return jsonResponse({ status: "success", culls: readTable(CULL_TAB_NAME, CULL_HEADERS) });
  if (action === "deleteProduct") {
    const sheet = ensureHubHeaders(PRODUCTS_TAB_NAME, PRODUCTS_HEADERS);
    const row = findRowNumberByKey(sheet, PRODUCTS_HEADERS, "Product Name", p.productName);
    if (!row) return jsonResponse({ status: "error", message: "Product not found." });
    sheet.deleteRow(row);
    return jsonResponse({ status: "success" });
  }
  if (action === "getSettings") return jsonResponse({ status: "success", settings: publicSettings() });
  if (action === "tidyText") return hubTidyText(p.text || "", p.kind || "", session, p.service || "", p.section || "");
  if (action === "tidyAvailable") return jsonResponse({ status: "success", on: !!getSettings()["Anthropic API Key"] });
  if (action === "saveSettings") return hubSaveSettings(p.settings || {}, session);
  if (action === "listEmployees") return jsonResponse({ status: "success", employees: readTable(TECHNICIANS_TAB_NAME, EMPLOYEE_HEADERS) });
  if (action === "saveEmployee") return hubSaveEmployee(p.employee || {}, session);
  if (action === "listDocuments") return jsonResponse({ status: "success", documents: readTable(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS) });
  if (action === "saveDocument") return hubSaveDocument(p.document || {}, session);
  if (action === "markReviewed") return hubMarkReviewed(p.docId, session, p.note || true);
  if (action === "deleteDocument") return hubDeleteDocument(p.docId, session);
  if (action === "copyTemplate") return hubCopyTemplate(p.docId, p.jobId, session);
  if (action === "listSignDocs") {
    const all = readTable(SIGN_TAB_NAME, SIGN_HEADERS);
    let clientId = p.clientId || "";
    if (p.jobId && !clientId) { const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === p.jobId); clientId = job ? job["Client ID"] : ""; }
    if (p.docId) return jsonResponse({ status: "success", docs: all.filter(d => d["Scope"] === "SMS" && d["Doc ID"] === p.docId && (!p.jobId || d["Job ID"] === p.jobId)).map(slimSign), rateCard: [] });
    if (p.scope === "SMS") return jsonResponse({ status: "success", docs: all.filter(d => d["Scope"] === "SMS").map(slimSign), rateCard: [] });
    const docs = all.filter(d => (p.jobId && d["Job ID"] === p.jobId) || (clientId && d["Scope"] === "Client" && d["Client ID"] === clientId) || (!p.jobId && !clientId));
    return jsonResponse({ status: "success", docs: docs.map(slimSign), rateCard: readTable(RATE_CARD_TAB_NAME, RATE_CARD_HEADERS) });
  }
  if (action === "cancelSignDoc") { const r = readTable(SIGN_TAB_NAME, SIGN_HEADERS).find(x => x["Sign ID"] === p.signId); if (!r) return jsonResponse({ status: "error", message: "Not found." }); r["Status"] = "Cancelled"; r["Cancelled Date"] = new Date(); r["Updated"] = new Date(); writeRecord(SIGN_TAB_NAME, SIGN_HEADERS, "Sign ID", r); return jsonResponse({ status: "success" }); }
  if (action === "cancelPermission") { const r = readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS).find(x => x["Permission ID"] === p.permissionId); if (!r) return jsonResponse({ status: "error", message: "Not found." }); r["Status"] = "Cancelled"; r["Cancelled Date"] = new Date(); r["Updated"] = new Date(); writeRecord(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS, "Permission ID", r); return jsonResponse({ status: "success" }); }
  if (action === "getSignDoc") { const d = readTable(SIGN_TAB_NAME, SIGN_HEADERS).find(x => x["Sign ID"] === p.signId); return d ? jsonResponse({ status: "success", doc: d }) : jsonResponse({ status: "error", message: "Not found." }); }
  if (action === "saveSignDoc") return hubSaveSignDoc(p.doc || {}, p.signatureDataUrl || "", session);
  if (action === "markSignSent") return hubMarkSignSent(p.signId, session);
  if (action === "voidSignDoc") return hubVoidSignDoc(p.signId, session);
  if (action === "markPermissionSent") { const r = readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS).find(x => x["Permission ID"] === p.permissionId); if (!r) return jsonResponse({ status: "error", message: "Not found." }); if (r["Status"] !== "Signed") { r["Status"] = "Sent"; r["Sent Date"] = new Date(); writeRecord(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS, "Permission ID", r); } return jsonResponse({ status: "success", permission: r }); }
  if (action === "getReport") return hubGetReport(p.jobId);
  if (action === "saveReport") return hubSaveReport(p.report || {}, session);
  if (action === "buildReportPdf") return hubBuildReportPdf(p.reportId, session);
  if (action === "markReportSent") return hubMarkReportSent(p.reportId, p.sentTo || "", session);
  return jsonResponse({ status: "error", message: "Unknown action: " + action });
}

/* ---------- auth ---------- */
function hubLogin(p) {
  const email = String(p.email || "").trim().toLowerCase();
  const passcode = String(p.passcode || "");
  if (!email || !passcode) return jsonResponse({ status: "error", message: "Enter your email and passcode." });
  const cache = CacheService.getScriptCache();
  const failKey = "fail_" + email;
  const fails = Number(cache.get(failKey) || 0);
  if (fails >= 5) return jsonResponse({ status: "error", message: "Too many wrong attempts. Try again in 15 minutes." });
  const users = readTable(USERS_TAB_NAME, USERS_HEADERS, true);
  const user = users.find(u => String(u["Email"] || "").trim().toLowerCase() === email);
  if (!user || !passcodeMatches(String(user["Passcode"] || ""), passcode)) {
    cache.put(failKey, String(fails + 1), 900);
    return jsonResponse({ status: "error", message: "Email or passcode is wrong." });
  }
  // First successful login with a plain-text passcode: replace it in the sheet with a salted hash.
  if (!/^sha256:/.test(String(user["Passcode"] || ""))) { try { storePasscodeHash(email, passcode); } catch (e) { Logger.log("Hash upgrade: " + e); } }
  if (String(user["Status"] || "Active").toLowerCase() !== "active") {
    return jsonResponse({ status: "error", message: "This login has been turned off." });
  }
  cache.remove(failKey);
  // Two-step: unless this device is trusted, ask for the authenticator code before issuing a session.
  if (/^on$/i.test(String(user["Two Step"] || "")) && user["TOTP Secret"]) {
    const trusted = p.deviceToken && cache.get("dev_" + p.deviceToken) === email;
    if (!trusted && !(p.deviceToken && trustedDeviceOk(p.deviceToken, email))) {
      const pending = Utilities.getUuid();
      cache.put("pend_" + pending, email, 300);
      return jsonResponse({ status: "2fa", pending });
    }
  }
  return issueSession(user, email, p.trustDevice);
}
/* Passcodes are kept as "sha256:<salt>:<hex>" so nobody reading the sheet sees them.
   Type a new plain passcode into the cell to reset one; it is hashed at the next login. */
function hashPasscode(salt, passcode) {
  return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, salt + ":" + passcode, Utilities.Charset.UTF_8).map(b => ((b + 256) % 256).toString(16).padStart(2, "0")).join("");
}
function passcodeMatches(stored, passcode) {
  if (!stored || !passcode) return false;
  const m = stored.match(/^sha256:([^:]+):([0-9a-f]+)$/);
  if (!m) return stored === passcode;
  return hashPasscode(m[1], passcode) === m[2];
}
function storePasscodeHash(email, passcode) {
  const sheet = getOrCreateSheet(USERS_TAB_NAME, USERS_HEADERS);
  const hdr = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  const data = sheet.getRange(2, hdr.indexOf("Email") + 1, sheet.getLastRow() - 1, 1).getValues();
  for (let i = 0; i < data.length; i++) if (String(data[i][0]).trim().toLowerCase() === email) {
    const salt = Utilities.getUuid().replace(/-/g, "").slice(0, 16);
    sheet.getRange(i + 2, hdr.indexOf("Passcode") + 1).setValue("sha256:" + salt + ":" + hashPasscode(salt, passcode));
  }
}
function issueSession(user, email, trustDevice) {
  const token = Utilities.getUuid() + "-" + Utilities.getUuid();
  const sheet = getOrCreateSheet(SESSIONS_TAB_NAME, SESSIONS_HEADERS);
  const now = new Date();
  const expires = new Date(now.getTime() + SESSION_DAYS * 86400000);
  sheet.appendRow([token, email, user["Name"] || email, user["Role"] || "staff", now, expires]);
  pruneSessions(sheet);
  const sess = { email, name: user["Name"] || email, role: user["Role"] || "staff" };
  CacheService.getScriptCache().put("sess_" + token, JSON.stringify(sess), 21600);
  let deviceToken = "";
  if (trustDevice) { deviceToken = Utilities.getUuid().replace(/-/g, "") + Utilities.getUuid().replace(/-/g, ""); const dv = getOrCreateSheet(DEVICES_TAB_NAME, DEVICES_HEADERS); dv.appendRow([deviceToken, email, now, new Date(now.getTime() + 60 * 86400000)]); }
  return jsonResponse({ status: "success", token, user: sess, deviceToken });
}
const DEVICES_TAB_NAME = "Trusted Devices";
const DEVICES_HEADERS = ["Device Token", "Email", "Created", "Expires"];
function trustedDeviceOk(deviceToken, email) {
  const sheet = getOrCreateSheet(DEVICES_TAB_NAME, DEVICES_HEADERS);
  const row = findRowNumberByKey(sheet, DEVICES_HEADERS, "Device Token", deviceToken);
  if (!row) return false;
  const vals = sheet.getRange(row, 1, 1, 4).getValues()[0];
  if (String(vals[1]).toLowerCase() !== email || new Date(vals[3]) < new Date()) return false;
  CacheService.getScriptCache().put("dev_" + deviceToken, email, 21600);
  return true;
}
// Second step of login: the 6-digit code from the authenticator app.
function hubLogin2fa(p) {
  const cache = CacheService.getScriptCache();
  const email = cache.get("pend_" + String(p.pending || ""));
  if (!email) return jsonResponse({ status: "error", message: "That took too long. Log in again." });
  const user = readTable(USERS_TAB_NAME, USERS_HEADERS, true).find(u => String(u["Email"] || "").trim().toLowerCase() === email);
  if (!user) return jsonResponse({ status: "error", message: "Log in again." });
  const failKey = "fail2_" + email; const fails = Number(cache.get(failKey) || 0);
  if (fails >= 5) return jsonResponse({ status: "error", message: "Too many wrong codes. Try again in 15 minutes." });
  if (!totpCheck(user["TOTP Secret"], p.code)) { cache.put(failKey, String(fails + 1), 900); return jsonResponse({ status: "error", message: "Code is wrong. Check the time on your phone and try the next code." }); }
  cache.remove("pend_" + p.pending); cache.remove(failKey);
  return issueSession(user, email, p.trustDevice);
}
// Set up: generate a secret, hand back the key and the otpauth link. Turned on only once a code is verified.
function hubTotpSetup(session) {
  const secret = base32Encode(Utilities.getUuid().replace(/-/g, "").slice(0, 20));
  CacheService.getScriptCache().put("totpsetup_" + session.email, secret, 900);
  const label = encodeURIComponent("Terana Hub:" + session.email);
  return jsonResponse({ status: "success", secret, otpauth: "otpauth://totp/" + label + "?secret=" + secret + "&issuer=" + encodeURIComponent("Terana Hub") + "&digits=6&period=30" });
}
function hubTotpConfirm(p, session) {
  const secret = CacheService.getScriptCache().get("totpsetup_" + session.email);
  if (!secret) return jsonResponse({ status: "error", message: "Setup timed out. Start again." });
  if (!totpCheck(secret, p.code)) return jsonResponse({ status: "error", message: "Code is wrong. Try the next one the app shows." });
  const sheet = getOrCreateSheet(USERS_TAB_NAME, USERS_HEADERS);
  ensureHubHeaders(USERS_TAB_NAME, USERS_HEADERS);
  const hdr = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  const row = findRowNumberByKey(sheet, USERS_HEADERS, "Email", session.email) || (function () { const data = sheet.getRange(2, 2, sheet.getLastRow() - 1, 1).getValues(); for (let i = 0; i < data.length; i++) if (String(data[i][0]).trim().toLowerCase() === session.email) return i + 2; return 0; })();
  if (!row) return jsonResponse({ status: "error", message: "User row not found." });
  sheet.getRange(row, hdr.indexOf("TOTP Secret") + 1).setValue(secret);
  sheet.getRange(row, hdr.indexOf("Two Step") + 1).setValue("On");
  CacheService.getScriptCache().remove("totpsetup_" + session.email);
  return jsonResponse({ status: "success" });
}
function hubTotpOff(p, session) {
  const user = readTable(USERS_TAB_NAME, USERS_HEADERS, true).find(u => String(u["Email"] || "").trim().toLowerCase() === session.email);
  if (!user || !totpCheck(user["TOTP Secret"], p.code)) return jsonResponse({ status: "error", message: "Enter a current code from the app to turn it off." });
  const sheet = getOrCreateSheet(USERS_TAB_NAME, USERS_HEADERS);
  const hdr = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
  const data = sheet.getRange(2, 2, sheet.getLastRow() - 1, 1).getValues(); let row = 0; for (let i = 0; i < data.length; i++) if (String(data[i][0]).trim().toLowerCase() === session.email) row = i + 2;
  if (row) { sheet.getRange(row, hdr.indexOf("Two Step") + 1).setValue("Off"); sheet.getRange(row, hdr.indexOf("TOTP Secret") + 1).setValue(""); }
  return jsonResponse({ status: "success" });
}
/* TOTP (RFC 6238), 6 digits, 30 second steps, one step either side for clock drift. */
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function base32Encode(str) {
  const bytes = Utilities.newBlob(str).getBytes().map(b => b & 255); let bits = "", out = "";
  bytes.forEach(b => bits += b.toString(2).padStart(8, "0"));
  for (let i = 0; i + 5 <= bits.length; i += 5) out += B32[parseInt(bits.slice(i, i + 5), 2)];
  return out;
}
function base32Decode(str) {
  let bits = ""; String(str || "").toUpperCase().replace(/[^A-Z2-7]/g, "").split("").forEach(c => bits += B32.indexOf(c).toString(2).padStart(5, "0"));
  const out = []; for (let i = 0; i + 8 <= bits.length; i += 8) { let v = parseInt(bits.slice(i, i + 8), 2); out.push(v > 127 ? v - 256 : v); }
  return out;
}
function totpAt(secret, counter) {
  const key = base32Decode(secret);
  const msg = []; for (let i = 7; i >= 0; i--) { let v = counter % 256; msg.unshift(v > 127 ? v - 256 : v); counter = Math.floor(counter / 256); }
  const h = Utilities.computeHmacSignature(Utilities.MacAlgorithm.HMAC_SHA_1, msg, key).map(b => b & 255);
  const off = h[19] & 15;
  const code = ((h[off] & 127) << 24 | h[off + 1] << 16 | h[off + 2] << 8 | h[off + 3]) % 1000000;
  return String(code).padStart(6, "0");
}
function totpCheck(secret, code) {
  const c = String(code || "").replace(/\s/g, ""); if (!/^\d{6}$/.test(c) || !secret) return false;
  const step = Math.floor(Date.now() / 30000);
  return [step - 1, step, step + 1].some(k => totpAt(secret, k) === c);
}

function getSession(token) {
  if (!token) return null;
  const cache = CacheService.getScriptCache();
  const cached = cache.get("sess_" + token);
  if (cached) return JSON.parse(cached);
  const sheet = getOrCreateSheet(SESSIONS_TAB_NAME, SESSIONS_HEADERS);
  const row = findRowNumberByKey(sheet, SESSIONS_HEADERS, "Token", token);
  if (!row) return null;
  const vals = sheet.getRange(row, 1, 1, SESSIONS_HEADERS.length).getValues()[0];
  const expires = vals[5] instanceof Date ? vals[5] : new Date(vals[5]);
  if (expires.getTime() < Date.now()) return null;
  const sess = { email: vals[1], name: vals[2], role: vals[3] };
  cache.put("sess_" + token, JSON.stringify(sess), 21600);
  return sess;
}

function hubLogout(token) {
  CacheService.getScriptCache().remove("sess_" + token);
  const sheet = getOrCreateSheet(SESSIONS_TAB_NAME, SESSIONS_HEADERS);
  const row = findRowNumberByKey(sheet, SESSIONS_HEADERS, "Token", token);
  if (row) sheet.deleteRow(row);
  return jsonResponse({ status: "success" });
}

function pruneSessions(sheet) {
  const last = sheet.getLastRow();
  if (last < 2) return;
  const data = sheet.getRange(2, 1, last - 1, SESSIONS_HEADERS.length).getValues();
  for (let i = data.length - 1; i >= 0; i--) {
    const exp = data[i][5] instanceof Date ? data[i][5] : new Date(data[i][5]);
    if (exp.getTime() < Date.now()) sheet.deleteRow(i + 2);
  }
}

/* ---------- generic table read/write ---------- */
function cellToJson(v) {
  if (v instanceof Date) {
    // Date-only cells come back at local midnight; keep them as yyyy-mm-dd.
    const tz = Session.getScriptTimeZone();
    if (v.getHours() === 0 && v.getMinutes() === 0 && v.getSeconds() === 0) return Utilities.formatDate(v, tz, "yyyy-MM-dd");
    return Utilities.formatDate(v, tz, "yyyy-MM-dd'T'HH:mm:ss");
  }
  return v;
}

function readTable(tabName, headers, skipDateFormat) {
  const sheet = getOrCreateSheet(tabName, headers);
  const last = sheet.getLastRow();
  if (last < 2) return [];
  const width = Math.max(headers.length, sheet.getLastColumn());
  const liveHeaders = sheet.getRange(1, 1, 1, width).getValues()[0];
  const data = sheet.getRange(2, 1, last - 1, width).getValues();
  const out = [];
  data.forEach(r => {
    if (!r[0]) return;
    const obj = {};
    liveHeaders.forEach((h, i) => { if (h) obj[h] = skipDateFormat ? r[i] : cellToJson(r[i]); });
    out.push(obj);
  });
  return out;
}

function writeRecord(tabName, headers, keyHeader, record) {
  const sheet = ensureHubHeaders(tabName, headers);
  const row = headers.map(h => (record[h] === undefined || record[h] === null) ? "" : record[h]);
  const result = upsertRow(sheet, headers, keyHeader, record[keyHeader], row);
  // Keep date and id columns as text so Sheets doesn't reinterpret them.
  return result;
}

function newId(prefix) {
  const d = new Date();
  const stamp = Utilities.formatDate(d, Session.getScriptTimeZone(), "yyMMdd");
  return prefix + "-" + stamp + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();
}

/* ---------- clients ---------- */
function hubSaveClient(c, session) {
  if (!String(c["Name"] || "").trim()) return jsonResponse({ status: "error", message: "Client needs a name." });
  const now = new Date();
  const existing = c["Client ID"] ? readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(x => x["Client ID"] === c["Client ID"]) : null;
  const record = Object.assign({}, existing || {}, c);
  if (!record["Client ID"]) record["Client ID"] = newId("C");
  if (!record["Status"]) record["Status"] = "Active";
  if (!record["Created"]) record["Created"] = now;
  record["Updated"] = now;
  record["Updated By"] = session.name;
  try {
    const folder = clientFolder(record);
    record["Drive Folder ID"] = folder.getId(); record["Drive Folder URL"] = folder.getUrl();
    if (existing && existing["Name"] !== record["Name"] && folder.getName() !== record["Name"]) folder.setName(record["Name"]);
  } catch (e) { Logger.log("Client folder: " + e); }
  writeRecord(CLIENTS_TAB_NAME, CLIENTS_HEADERS, "Client ID", record);
  // Keep job rows' client name in step if it changed.
  if (existing && existing["Name"] !== record["Name"]) {
    readTable(JOBS_TAB_NAME, JOBS_HEADERS).filter(j => j["Client ID"] === record["Client ID"]).forEach(j => {
      j["Client Name"] = record["Name"];
      writeRecord(JOBS_TAB_NAME, JOBS_HEADERS, "Job ID", j);
    });
  }
  const saved = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(x => x["Client ID"] === record["Client ID"]);
  return jsonResponse({ status: "success", client: saved });
}

/* ---------- jobs ---------- */
function hubSaveJob(j, session) {
  if (!String(j["Title"] || "").trim()) return jsonResponse({ status: "error", message: "Job needs a title." });
  const now = new Date();
  const existing = j["Job ID"] ? readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(x => x["Job ID"] === j["Job ID"]) : null;
  const record = Object.assign({}, existing || {}, j);
  if (!record["Job ID"]) record["Job ID"] = newId("J");
  if (!record["Status"]) record["Status"] = "Enquiry";
  if (record["Client ID"]) {
    const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === record["Client ID"]);
    if (client) record["Client Name"] = client["Name"];
  }
  ["Latitude", "Longitude", "Quote Value"].forEach(k => {
    if (record[k] === "" || record[k] === null || record[k] === undefined) { record[k] = ""; return; }
    const n = Number(record[k]); record[k] = isNaN(n) ? "" : n;
  });
  if (!record["Created"]) record["Created"] = now;
  record["Updated"] = now;
  record["Updated By"] = session.name;
  writeRecord(JOBS_TAB_NAME, JOBS_HEADERS, "Job ID", record);
  const saved = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(x => x["Job ID"] === record["Job ID"]);
  return jsonResponse({ status: "success", job: saved });
}

function hubDeleteJob(jobId, session) {
  if (!jobId) return jsonResponse({ status: "error", message: "No job id." });
  const sheet = getOrCreateSheet(JOBS_TAB_NAME, JOBS_HEADERS);
  const row = findRowNumberByKey(sheet, JOBS_HEADERS, "Job ID", jobId);
  if (!row) return jsonResponse({ status: "error", message: "Job not found." });
  sheet.deleteRow(row);
  return jsonResponse({ status: "success" });
}

/* ---------- recent field activity (read-only view of the form tabs) ---------- */
function tailRows(tabName, n) {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  const sheet = ss.getSheetByName(tabName);
  if (!sheet || sheet.getLastRow() < 2) return [];
  const last = sheet.getLastRow();
  const start = Math.max(2, last - n + 1);
  const width = sheet.getLastColumn();
  const headers = sheet.getRange(1, 1, 1, width).getValues()[0];
  const data = sheet.getRange(start, 1, last - start + 1, width).getValues();
  return data.map(r => { const o = {}; headers.forEach((h, i) => { if (h) o[h] = cellToJson(r[i]); }); return o; });
}

function recentActivity(limit) {
  const items = [];
  tailRows(PEST_REPORT_TAB_NAME, limit).forEach(r => items.push({
    type: "Pest report", when: r["Server Timestamp"], date: r["Date"], who: r["Technician"],
    where: r["Site / Client"], summary: [r["Job Type(s)"], r["Target Pest"]].filter(Boolean).join(" / "), ref: r["Submission ID"]
  }));
  tailRows(FOX_DEN_TAB_NAME, limit).forEach(r => items.push({
    type: "Fox den survey", when: r["Server Timestamp"], date: r["Date"], who: r["Reporter"],
    where: r["Location"], summary: [r["Entry Type"], r["Activity Status"], r["Likely Species"]].filter(Boolean).join(" / "), ref: r["Row Key"]
  }));
  tailRows(SHOOTING_ACTIVITIES_TAB_NAME, limit).forEach(r => items.push({
    type: "Shooting activity", when: r["Server Timestamp"], date: r["Date"], who: r["Shooter"],
    where: r["Customer Name"], summary: [r["Activity Type"], r["Species"], r["Number Dispatched"] ? r["Number Dispatched"] + " dispatched" : ""].filter(Boolean).join(" / "), ref: r["Submission ID"]
  }));
  tailRows(FIREARM_MOVEMENTS_TAB_NAME, limit).forEach(r => items.push({
    type: "Firearm " + String(r["Movement Type"] || "movement").toLowerCase(), when: r["Server Timestamp"], date: r["Date/Time"], who: r["Person"],
    where: "", summary: [r["Firearm / Item"], r["Reason"]].filter(Boolean).join(" / "), ref: r["Submission ID"]
  }));
  items.sort((a, b) => String(b.when || "").localeCompare(String(a.when || "")));
  return items.slice(0, limit);
}

/* ---------- one-off: create the hub tabs with headers ---------- */
function ensureHubHeaders(tabName, headers) {
  const sheet = getOrCreateSheet(tabName, headers);
  const width = sheet.getLastColumn();
  const live = width ? sheet.getRange(1, 1, 1, width).getValues()[0].map(String) : [];
  const missing = headers.filter(h => live.indexOf(h) < 0);
  if (missing.length) sheet.getRange(1, live.length + 1, 1, missing.length).setValues([missing]);
  return sheet;
}

function setupHubTabs() {
  ensureHubHeaders(CLIENTS_TAB_NAME, CLIENTS_HEADERS);
  ensureHubHeaders(JOBS_TAB_NAME, JOBS_HEADERS);
  // The form tabs are written by column position, so their header row is
  // simply rewritten to match the arrays (data rows are untouched).
  [[PEST_REPORT_TAB_NAME, PEST_REPORT_HEADERS], [FOX_DEN_TAB_NAME, FOX_DEN_HEADERS]].forEach(([tab, hdr]) => {
    const sh = getOrCreateSheet(tab, hdr);
    sh.getRange(1, 1, 1, hdr.length).setValues([hdr]);
    sh.setFrozenRows(1);
  });
  ensureHubHeaders(USERS_TAB_NAME, USERS_HEADERS);
  getOrCreateSheet(SESSIONS_TAB_NAME, SESSIONS_HEADERS);
  getOrCreateSheet(DEVICES_TAB_NAME, DEVICES_HEADERS);
  getOrCreateSheet(CLIENTS_TAB_NAME, CLIENTS_HEADERS);
  getOrCreateSheet(JOBS_TAB_NAME, JOBS_HEADERS);
  getOrCreateSheet(REPORTS_TAB_NAME, REPORTS_HEADERS);
  getOrCreateSheet(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS);
  ensureHubHeaders(PRODUCTS_TAB_NAME, PRODUCTS_HEADERS);
  getTechnicians();
  ensureHubHeaders(TECHNICIANS_TAB_NAME, EMPLOYEE_HEADERS);
  getOrCreateSheet(CHEMICAL_MOVEMENTS_TAB_NAME, CHEMICAL_MOVEMENTS_HEADERS);
  getOrCreateSheet(CULL_TAB_NAME, CULL_HEADERS);
  const tpl = getOrCreateSheet(TEMPLATES_TAB_NAME, TEMPLATES_HEADERS);
  if (tpl.getLastRow() < 2) tpl.getRange(2, 1, TEMPLATE_SEED.length, 4).setValues(TEMPLATE_SEED);
  ensureHubHeaders(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS);
  seedSmsDocuments();
  getOrCreateSheet(SIGN_TAB_NAME, SIGN_HEADERS);
  seedFirearms();
  const rc = getOrCreateSheet(RATE_CARD_TAB_NAME, RATE_CARD_HEADERS);
  if (rc.getLastRow() < 2) rc.getRange(2, 1, 8, 4).setValues([
    ["Urban contract shooting", "hour", 250, "3 hour minimum per job"],
    ["Spotter / second shooter", "hour", 100, "3 hour minimum per job"],
    ["General pest work", "hour", 160, "3 hour minimum per job"],
    ["Admin, permits, planning, WA Police liaison", "hour", 125, ""],
    ["Materials", "each", "", "Cost plus 30%. Enter the amount on the fee line."],
    ["Rodenator gas", "shot", 10, ""],
    ["Travel time", "hour", 125, "Driver's time door to door, from Fremantle, return"],
    ["Vehicle", "km", 1.20, "Return kilometres from Fremantle. ATO 2026-27 vehicle rate is 91c/km; 1.20 adds a margin like materials."]
  ]);
  getSettings();
  const users = SpreadsheetApp.openById(SHEET_ID).getSheetByName(USERS_TAB_NAME);
  if (users.getLastRow() < 2) users.appendRow(["Courtney Kelly", "courtney@teranaenvironmental.com.au", "CHANGE-ME", "admin", "Active"]);
  Logger.log("Hub tabs ready. Set your passcode in the Users tab.");
}


/* ============================================================
   STAGE 2: website enquiries in, job reports out
   ============================================================ */
const NOTIFY_EMAIL = "courtney@teranaenvironmental.com.au";
const REPORTS_TAB_NAME = "Reports";
const REPORTS_HEADERS = [
  "Report ID", "Job ID", "Title", "Summary", "Work Carried Out", "Observations", "Recommendations",
  "Include Photos", "PDF URL", "PDF File ID", "Sent Date", "Sent To", "Created", "Updated", "Updated By"
];
const REPORT_FOLDER_NAME = "Job Reports";
const WEBSITE_SERVICE_MAP = {
  "Fox den detection": "Fox den detection", "Pest management plan or IPM program": "Pest management plan", "Field necropsy": "Field necropsy",
  "GIS and mapping": "GIS and mapping", "Monitoring and camera surveillance": "Monitoring", "Fox control": "Fox control", "Rabbit control": "Rabbit control",
  "Feral cat control": "Feral cat control", "Feral deer control": "Feral deer control", "Feral pig control": "Feral pig control", "Bird management": "Bird management",
  "Native fauna impact management": "Native fauna management", "Habitat creation": "Habitat creation", "Snake removal and relocation": "Snake removal",
  "Bee removal and relocation": "Bee removal", "Something else": "Other"
};

/* ---------- website enquiry and calculator forms ---------- */
function handleWebsiteEnquiry(f) {
  if (f._gotcha) return jsonResponse({ status: "success" }); // honeypot filled: a bot
  const email = String(f.email || "").trim();
  const name = String(f.name || "").trim();
  const isCalc = !!f.calculator;
  if (!email && !f.phone && !name) return jsonResponse({ status: "error", message: "No contact details." });

  // Client: reuse by email, otherwise create.
  const clients = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS);
  let client = email ? clients.find(c => String(c["Email"] || "").trim().toLowerCase() === email.toLowerCase()) : null;
  const now = new Date();
  if (!client) {
    const nameParts = name.split(/\s+/);
    client = { "Client ID": newId("C"), "Name": f.organisation ? String(f.organisation).trim() : (name || email), "Contact Name": name,
      "First Name": nameParts[0] || "", "Last Name": nameParts.slice(1).join(" "), "Email": email,
      "Phone": String(f.phone || "").trim(), "Address": String(f.property_location || "").trim(), "Client Type": "", "Notes": "Created from a website enquiry.",
      "Status": "Active", "Created": now, "Updated": now, "Updated By": "Website" };
    writeRecord(CLIENTS_TAB_NAME, CLIENTS_HEADERS, "Client ID", client);
  }

  const skip = { _subject: 1, _gotcha: 1, page: 1, name: 1, organisation: 1, email: 1, phone: 1, service: 1, message: 1, calculator: 1 };
  const extras = Object.keys(f).filter(k => !skip[k] && String(f[k]).trim() !== "").map(k => k.replace(/_/g, " ") + ": " + f[k]);
  const service = isCalc ? ({ rabbits: "Rabbit control", foxes: "Fox control", birdflu: "Bird management" }[f.calculator] || "Other") : (WEBSITE_SERVICE_MAP[f.service] || "Other");
  const title = (isCalc ? "Calculator enquiry: " : "Website enquiry: ") + service + (client["Name"] ? ", " + client["Name"] : "");
  const job = { "Job ID": newId("J"), "Client ID": client["Client ID"], "Client Name": client["Name"], "Title": title, "Service": service,
    "Site Name": "", "Site Address": String(f.property_location || "").trim(), "Latitude": "", "Longitude": "", "Status": "Enquiry", "Priority": "Normal",
    "Start Date": "", "End Date": "", "Assigned To": "", "Quote Value": "",
    "Description": String(f.message || "").trim(), "Next Action": "Reply to enquiry", "Next Action Date": Utilities.formatDate(now, Session.getScriptTimeZone(), "yyyy-MM-dd"),
    "Notes": ["From " + (f.page || "website"), name ? "Contact: " + name : "", email ? "Email: " + email : "", f.phone ? "Phone: " + f.phone : ""].concat(extras).filter(Boolean).join("\n"),
    "Created": now, "Updated": now, "Updated By": "Website" };
  writeRecord(JOBS_TAB_NAME, JOBS_HEADERS, "Job ID", job);

  try {
    MailApp.sendEmail({
      to: NOTIFY_EMAIL, replyTo: email || NOTIFY_EMAIL, name: "Terana website",
      subject: title,
      body: [job["Description"], "", job["Notes"], "", "Job " + job["Job ID"] + " has been added to the hub with status Enquiry."].join("\n")
    });
  } catch (mailErr) { /* the job is saved either way */ }
  return jsonResponse({ status: "success", jobId: job["Job ID"] });
}

/* ---------- firearms currently out of storage ---------- */
function deployedFirearms() {
  const moves = readTable(FIREARM_MOVEMENTS_TAB_NAME, FIREARM_MOVEMENTS_HEADERS);
  const latest = {};
  moves.forEach(m => {
    const key = String(m["Serial Number"] || m["Firearm / Item"] || "").trim();
    if (!key) return;
    const when = String(m["Date/Time"] || m["Server Timestamp"] || "");
    if (!latest[key] || when >= latest[key].when) latest[key] = { when, m };
  });
  const shots = readTable(SHOOTING_ACTIVITIES_TAB_NAME, SHOOTING_ACTIVITIES_HEADERS);
  const out = [];
  Object.keys(latest).forEach(key => {
    const m = latest[key].m;
    if (String(m["Movement Type"]).toLowerCase() !== "withdrawal") return;
    const since = latest[key].when;
    const used = shots.filter(a => String(a["Firearm Used"] || "").indexOf(String(m["Serial Number"] || "\u0000")) >= 0 || String(a["Firearm Used"] || "") === String(m["Firearm / Item"] || ""))
      .filter(a => String(a["Server Timestamp"] || "") >= String(m["Server Timestamp"] || ""))
      .reduce((t, a) => t + (Number(a["Rounds Used"]) || 0), 0);
    out.push({ item: m["Firearm / Item"], serial: m["Serial Number"], person: m["Person"], since, jobId: m["Job ID"] || "", jobTitle: m["Job Title"] || "", reason: m["Reason"] || "",
      ammoType: m["Type (if ammunition)"] || "", roundsTaken: Number(m["Rounds Taken"]) || 0, roundsUsed: used, roundsRemaining: Math.max(0, (Number(m["Rounds Taken"]) || 0) - used) });
  });
  return out;
}

/* ---------- jobs list for the field forms (minimal) ---------- */
function openJobsForForms() {
  return readTable(JOBS_TAB_NAME, JOBS_HEADERS)
    .filter(j => !["Completed", "Invoiced", "Cancelled"].includes(j["Status"]))
    .map(j => { let stages = []; try { stages = JSON.parse(j["Stages"] || "[]"); } catch (e) { }
      return { id: j["Job ID"], title: j["Title"], client: j["Client Name"] || "", site: j["Site Name"] || "", address: j["Site Address"] || "", stages: Array.isArray(stages) ? stages : [] }; });
}

/* A job log that names a stage marks that stage Done on the job. */
function markStageDone(jobId, stageName) {
  try {
    const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === jobId);
    if (!job) return;
    let stages = JSON.parse(job["Stages"] || "[]");
    if (!Array.isArray(stages)) return;
    let changed = false;
    stages.forEach(s => { if (s.name === stageName && s.status !== "Done") { s.status = "Done"; changed = true; } });
    if (!changed) return;
    job["Stages"] = JSON.stringify(stages); job["Updated"] = new Date(); job["Updated By"] = "Job log";
    if (job["Status"] === "Scheduled") job["Status"] = "In Progress";
    writeRecord(JOBS_TAB_NAME, JOBS_HEADERS, "Job ID", job);
  } catch (e) { }
}

/* ---------- reports ---------- */
function visitsForJob(jobId) {
  const visits = [];
  readTable(PEST_REPORT_TAB_NAME, PEST_REPORT_HEADERS).filter(r => r["Job ID"] === jobId).forEach(r => visits.push({
    kind: "Site visit", date: r["Date"], start: r["Onsite Start"], finish: r["Onsite Finish"], who: r["Technician"], site: r["Site / Client"],
    methods: r["Work Done"] || r["Job Type(s)"], stage: r["Stage"], target: r["Target Pest"], product: r["Product"], quantity: r["Quantity Used"], count: r["Number Trapped / Culled"],
    recommendations: r["Recommendations"], notes: r["Notes"], incidents: r["Incidents"], photos: splitLinks(r["Photo Links"]), captions: String(r["Photo Captions"] || "").split(" | "), ref: r["Submission ID"]
  }));
  readTable(FOX_DEN_TAB_NAME, FOX_DEN_HEADERS).filter(r => r["Job ID"] === jobId).forEach(r => visits.push({
    kind: "Survey entry", date: r["Date"], start: "", finish: "", who: r["Reporter"], site: r["Location"],
    methods: r["Entry Type"], target: r["Likely Species"], product: "", quantity: "", count: r["Entrance Count"],
    recommendations: "", notes: [r["Activity Status"], r["Signs Observed"], r["Notes"]].filter(Boolean).join(". "), incidents: r["Incidents"], photos: splitLinks(r["Photo Links"]), ref: r["Row Key"]
  }));
  visits.sort((a, b) => String(a.date || "").localeCompare(String(b.date || "")) || String(a.start || "").localeCompare(String(b.start || "")));
  return visits;
}
function splitLinks(s) { return String(s || "").split("|").map(x => x.trim()).filter(x => x.indexOf("http") === 0); }

function hubGetReport(jobId) {
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === jobId);
  if (!job) return jsonResponse({ status: "error", message: "Job not found." });
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === job["Client ID"]) || null;
  const report = readTable(REPORTS_TAB_NAME, REPORTS_HEADERS).find(r => r["Job ID"] === jobId) || null;
  return jsonResponse({ status: "success", job, client, report, visits: visitsForJob(jobId) });
}

function hubSaveReport(r, session) {
  if (!r["Job ID"]) return jsonResponse({ status: "error", message: "No job id." });
  const now = new Date();
  const existing = readTable(REPORTS_TAB_NAME, REPORTS_HEADERS).find(x => x["Job ID"] === r["Job ID"]);
  const record = Object.assign({}, existing || {}, r);
  if (!record["Report ID"]) record["Report ID"] = newId("R");
  if (!record["Created"]) record["Created"] = now;
  record["Updated"] = now; record["Updated By"] = session.name;
  writeRecord(REPORTS_TAB_NAME, REPORTS_HEADERS, "Report ID", record);
  return jsonResponse({ status: "success", report: readTable(REPORTS_TAB_NAME, REPORTS_HEADERS).find(x => x["Report ID"] === record["Report ID"]) });
}

function hubBuildReportPdf(reportId, session) {
  const report = readTable(REPORTS_TAB_NAME, REPORTS_HEADERS).find(x => x["Report ID"] === reportId);
  if (!report) return jsonResponse({ status: "error", message: "Save the draft first." });
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === report["Job ID"]);
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === job["Client ID"]) || {};
  const visits = visitsForJob(job["Job ID"]);
  const html = reportHtml(report, job, client, visits);
  const pdf = Utilities.newBlob(html, "text/html", "report.html").getAs("application/pdf");
  const safe = s => String(s || "").replace(/[^0-9a-zA-Z ,.-]/g, "").trim();
  const dateStr = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd");
  pdf.setName(dateStr + " " + safe(client["Name"] || "Client") + " " + safe(report["Title"] || job["Title"]) + ".pdf");
  const folder = client["Client ID"] ? getOrCreateSubFolder(clientFolder(client), "Reports") : getOrCreateSubFolder(getOrCreateNamedFolder(REPORT_FOLDER_NAME), safe(client["Name"] || "Unfiled"));
  if (report["PDF File ID"]) { try { DriveApp.getFileById(report["PDF File ID"]).setTrashed(true); } catch (e) { } }
  const file = folder.createFile(pdf);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  report["PDF URL"] = file.getUrl(); report["PDF File ID"] = file.getId();
  report["Updated"] = new Date(); report["Updated By"] = session.name;
  writeRecord(REPORTS_TAB_NAME, REPORTS_HEADERS, "Report ID", report);
  return jsonResponse({ status: "success", pdfUrl: report["PDF URL"], downloadUrl: "https://drive.google.com/uc?export=download&id=" + file.getId(), report });
}

function hubMarkReportSent(reportId, sentTo, session) {
  const report = readTable(REPORTS_TAB_NAME, REPORTS_HEADERS).find(x => x["Report ID"] === reportId);
  if (!report) return jsonResponse({ status: "error", message: "Report not found." });
  report["Sent Date"] = new Date(); report["Sent To"] = sentTo; report["Updated"] = new Date(); report["Updated By"] = session.name;
  writeRecord(REPORTS_TAB_NAME, REPORTS_HEADERS, "Report ID", report);
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === report["Job ID"]);
  if (job && !["Invoiced", "Cancelled"].includes(job["Status"])) {
    job["Status"] = "Completed"; job["Next Action"] = "Invoice"; job["Next Action Date"] = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd");
    job["Updated"] = new Date(); job["Updated By"] = session.name;
    writeRecord(JOBS_TAB_NAME, JOBS_HEADERS, "Job ID", job);
  }
  return jsonResponse({ status: "success", report, job });
}

function getOrCreateNamedFolder(name) {
  const it = DriveApp.getFoldersByName(name);
  return it.hasNext() ? it.next() : DriveApp.createFolder(name);
}
function getOrCreateSubFolder(parent, name) {
  const it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}
function driveIdFromUrl(url) { const m = String(url).match(/\/d\/([a-zA-Z0-9_-]+)/) || String(url).match(/[?&]id=([a-zA-Z0-9_-]+)/); return m ? m[1] : null; }
function photoDataUri(url) {
  try {
    const id = driveIdFromUrl(url); if (!id) return null;
    const blob = DriveApp.getFileById(id).getBlob();
    return "data:" + blob.getContentType() + ";base64," + Utilities.base64Encode(blob.getBytes());
  } catch (e) { return null; }
}
let _logoCache = null;
function logoDataUri() {
  if (_logoCache) return _logoCache;
  try {
    const r = UrlFetchApp.fetch("https://teranaenvironmental.com.au/assets/logo.png", { muteHttpExceptions: true });
    if (r.getResponseCode() === 200) _logoCache = "data:image/png;base64," + Utilities.base64Encode(r.getContent());
  } catch (e) { }
  return _logoCache;
}
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
function paras(s) { return String(s || "").split(/\n{2,}|\r\n\r\n/).map(p => "<p>" + esc(p).replace(/\n/g, "<br>") + "</p>").join(""); }
function fmtAU(d) { if (!d) return ""; const s = String(d).slice(0, 10); const dt = new Date(s + "T00:00:00"); return isNaN(dt) ? String(d) : Utilities.formatDate(dt, Session.getScriptTimeZone(), "d MMMM yyyy"); }

function reportHtml(report, job, client, visits) {
  const logo = logoDataUri();
  const includePhotos = String(report["Include Photos"] || "Yes") !== "No";
  const photos = [];
  if (includePhotos) visits.forEach(v => v.photos.forEach((p, i) => { if (photos.length < 16) photos.push({ url: p, date: v.date, site: v.site, caption: (v.captions || [])[i] || "" }); }));
  const visitRows = visits.map(v => `<tr><td>${esc(fmtAU(v.date))}</td><td>${esc([v.start, v.finish].filter(Boolean).join(" to "))}</td><td>${esc(v.who)}</td><td>${esc(v.methods)}${v.product ? "<br>" + esc(v.product) + (v.quantity ? ", " + esc(v.quantity) : "") : ""}</td><td>${esc(v.target)}</td><td class="num">${esc(v.count === 0 ? "0" : (v.count || ""))}</td></tr>`).join("");
  const totalCount = visits.reduce((a, v) => a + (Number(v.count) || 0), 0);
  const photoHtml = photos.map(p => { const d = photoDataUri(p.url); return d ? `<figure><img src="${d}"><figcaption>${p.caption ? esc(p.caption) + ". " : ""}${esc(fmtAU(p.date))}${p.site && !p.caption ? ", " + esc(p.site) : ""}</figcaption></figure>` : ""; }).join("");
  const today = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "d MMMM yyyy");
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    @page{size:A4;margin:18mm 16mm 20mm}
    body{font-family:Arial,Helvetica,sans-serif;color:#000;font-size:10.5pt;line-height:1.45;margin:0}
    .band{height:4px;background:#000;margin-bottom:14px}
    table.head{border:none;margin:0}
    table.head td{border:none;padding:0;vertical-align:top}
    .head img{width:150px}
    .head .meta{text-align:right;font-size:9.5pt;color:#4A4A4A}
    h1{font-size:20pt;font-weight:normal;letter-spacing:-0.02em;margin:18px 0 2px}
    .sub{color:#4A4A4A;margin:0 0 14px}
    h2{font-size:12.5pt;font-weight:bold;margin:18px 0 6px;padding-bottom:3px;border-bottom:1px solid #000}
    p{margin:0 0 8px}
    table{width:100%;border-collapse:collapse;font-size:9.5pt}
    th{text-align:left;border-bottom:1.5px solid #000;padding:4px 5px;font-weight:bold}
    td{border-bottom:1px solid #DADADA;padding:4px 5px;vertical-align:top}
    td.num,th.num{text-align:right}
    .facts td:first-child{width:34%;color:#4A4A4A}
    figure{display:inline-block;width:47%;margin:0 2% 8px 0;vertical-align:top}
    figure img{width:100%;height:auto;border:1px solid #DADADA}
    figcaption{font-size:8.5pt;color:#4A4A4A;margin-top:2px}
    .foot{margin-top:24px;font-size:8.5pt;color:#4A4A4A;border-top:1px solid #DADADA;padding-top:6px}
    .accent{color:#C1440E}
  </style></head><body>
  <div class="band"></div>
  <table class="head"><tr><td>${logo ? `<img src="${logo}">` : "<strong>TERANA ENVIRONMENTAL</strong>"}</td><td class="meta">Terana Environmental Pty Ltd<br>ABN 21 699 686 916<br>0450 303 434<br>courtney@teranaenvironmental.com.au</td></tr></table>
  <h1>${esc(report["Title"] || job["Title"])}</h1>
  <p class="sub">Prepared for ${esc(client["Name"] || job["Client Name"] || "the client")}${client["Contact Name"] ? ", attention " + esc(client["Contact Name"]) : ""}. ${esc(today)}.</p>
  <table class="facts">
    <tr><td>Job</td><td>${esc(job["Job ID"])}, ${esc(job["Service"] || "")}</td></tr>
    <tr><td>Site</td><td>${esc([job["Site Name"], job["Site Address"]].filter(Boolean).join(", ") || "")}</td></tr>
    <tr><td>Dates</td><td>${esc((job["Start Date"] && job["End Date"] && String(job["Start Date"]).slice(0,10) === String(job["End Date"]).slice(0,10)) ? fmtAU(job["Start Date"]) : ([fmtAU(job["Start Date"]), fmtAU(job["End Date"])].filter(Boolean).join(" to ") || (visits.length ? fmtAU(visits[0].date) : "")))}</td></tr>
    <tr><td>Technician</td><td>${esc(job["Assigned To"] || (visits[0] && visits[0].who) || "")}</td></tr>
  </table>
  ${report["Summary"] ? `<h2>Summary</h2>${paras(report["Summary"])}` : ""}
  <h2>Work carried out</h2>${paras(report["Work Carried Out"])}
  ${visits.length ? `<table><thead><tr><th>Date</th><th>On site</th><th>Technician</th><th>Method</th><th>Target</th><th class="num">Number</th></tr></thead><tbody>${visitRows}${totalCount ? `<tr><td colspan="5"><strong>Total</strong></td><td class="num"><strong>${totalCount}</strong></td></tr>` : ""}</tbody></table>` : ""}
  ${report["Observations"] ? `<h2>Observations</h2>${paras(report["Observations"])}` : ""}
  ${report["Recommendations"] ? `<h2>Recommendations</h2>${paras(report["Recommendations"])}` : ""}
  ${photoHtml ? `<h2>Photos</h2><div class="photos">${photoHtml}</div>` : ""}
  <div class="foot">Prepared by Terana Environmental Pty Ltd. Methods used follow the relevant codes of practice and product labels. Records of this work are held by Terana Environmental and are available on request.</div>
  </body></html>`;
}


/* ============================================================
   SHOOTING PERMISSIONS (written permission of the owner/occupier)
   ============================================================ */
const PERMISSIONS_TAB_NAME = "Permissions";
const PERMISSIONS_HEADERS = [
  "Permission ID", "Job ID", "Client ID", "Landholder Name", "Authority", "Property Address", "Purpose", "Species",
  "Valid From", "Valid To", "Permitted Areas", "Exclusion Areas", "Conditions", "Terana Licence", "Signed By", "Signed Date",
  "Carcass Disposal",
  "Signature File ID", "Map File ID", "PDF URL", "PDF File ID", "Created", "Updated", "Updated By",
  // Remote signing by link
  "Token", "Status", "Landholder Email", "Sent Date", "Signed How",
  "Scope", "Cancelled Date",   // Scope "Client" = standing permission for the client's land, open until cancelled or Valid To
  "KML URL", "GPX URL"   // map files of the permitted and exclusion areas, filed under the client's Maps folder
];
const PERMISSION_FOLDER_NAME = "Shooting Permissions";

function hubGetPermission(jobId, clientId) {
  if (jobId) {
    const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === jobId);
    if (!job) return jsonResponse({ status: "error", message: "Job not found." });
    const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === job["Client ID"]) || null;
    const permission = readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS).find(r => r["Job ID"] === jobId && r["Status"] !== "Void" && r["Status"] !== "Cancelled") || null;
    const standing = client ? permissionForClient(client["Client ID"]) : null;
    return jsonResponse({ status: "success", job, client, permission, standing });
  }
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === clientId);
  if (!client) return jsonResponse({ status: "error", message: "Client not found." });
  const jobs = readTable(JOBS_TAB_NAME, JOBS_HEADERS).filter(j => j["Client ID"] === clientId && j["Latitude"] !== "");
  return jsonResponse({ status: "success", job: null, client, permission: permissionForClient(clientId), pins: jobs.map(j => ({ lat: j["Latitude"], lng: j["Longitude"], title: j["Title"] })) });
}

function saveDataUrlToDrive(dataUrl, folder, name) {
  const m = String(dataUrl || "").match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
  if (!m) return null;
  const blob = Utilities.newBlob(Utilities.base64Decode(m[2]), m[1], name);
  const file = folder.createFile(blob);
  return file.getId();
}

function hubSavePermission(pm, signatureDataUrl, mapDataUrl, session, extra) {
  extra = extra || {};
  if (!pm["Job ID"] && !pm["Client ID"]) return jsonResponse({ status: "error", message: "No job or client." });
  const now = new Date();
  const job = pm["Job ID"] ? readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === pm["Job ID"]) : {};
  if (!job) return jsonResponse({ status: "error", message: "Job not found." });
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === (job["Client ID"] || pm["Client ID"])) || {};
  const all = readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS);
  const existing = pm["Permission ID"] ? all.find(x => x["Permission ID"] === pm["Permission ID"]) : pm["Job ID"] ? all.find(x => x["Job ID"] === pm["Job ID"] && x["Status"] !== "Void" && x["Status"] !== "Cancelled") : all.find(x => x["Scope"] === "Client" && x["Client ID"] === pm["Client ID"] && x["Status"] !== "Void" && x["Status"] !== "Cancelled");
  const record = Object.assign({}, existing || {}, pm);
  record["Scope"] = pm["Job ID"] ? "Job" : "Client";
  if (!record["Permission ID"]) record["Permission ID"] = newId("P");
  if (!record["Token"]) record["Token"] = Utilities.getUuid().replace(/-/g, "") + Utilities.getUuid().replace(/-/g, "").slice(0, 8);
  if (signatureDataUrl) { record["Status"] = "Signed"; record["Signed How"] = "In person with " + session.name; } else if (record["Status"] !== "Signed") record["Status"] = record["Status"] === "Sent" ? "Sent" : "Draft";
  record["Client ID"] = job["Client ID"] || client["Client ID"] || "";
  if (!record["Created"]) record["Created"] = now;
  record["Updated"] = now; record["Updated By"] = session.name;
  const safe = x => String(x || "").replace(/[^0-9a-zA-Z ,.-]/g, "").trim();
  const folder = client["Client ID"] ? getOrCreateSubFolder(clientFolder(client), "Firearm use") : getOrCreateSubFolder(getOrCreateNamedFolder(PERMISSION_FOLDER_NAME), safe(client["Name"] || job["Client Name"] || "Unfiled"));
  const stamp = Utilities.formatDate(now, Session.getScriptTimeZone(), "yyyy-MM-dd HHmm");
  if (signatureDataUrl) { const id = saveDataUrlToDrive(signatureDataUrl, folder, stamp + " signature.png"); if (id) record["Signature File ID"] = id; }
  if (mapDataUrl) { const id = saveDataUrlToDrive(mapDataUrl, folder, stamp + " map.png"); if (id) record["Map File ID"] = id; }
  // Map files for Google Earth and GPS units, under the client's Maps folder. Replaced each save.
  if (extra.kmlText && client["Client ID"]) {
    try {
      const maps = getOrCreateSubFolder(clientFolder(client), "Maps");
      const base = safeName(extra.exportName || (client["Name"] + " shooting areas"));
      [["kml", "application/vnd.google-earth.kml+xml", extra.kmlText, "KML URL"], ["gpx", "application/gpx+xml", extra.gpxText, "GPX URL"]].forEach(([ext, mime, text, col]) => {
        if (!text) return;
        const old = maps.getFilesByName(base + "." + ext); while (old.hasNext()) old.next().setTrashed(true);
        const f = maps.createFile(Utilities.newBlob(text, mime, base + "." + ext));
        record[col] = f.getUrl();
      });
    } catch (e) { Logger.log("Map files: " + e); }
  }
  // Build the PDF
  const html = permissionHtml(record, job, client, signatureDataUrl || fileDataUri(record["Signature File ID"]), mapDataUrl || fileDataUri(record["Map File ID"]));
  const pdf = Utilities.newBlob(html, "text/html", "permission.html").getAs("application/pdf");
  pdf.setName(stamp.slice(0, 10) + " " + safe(client["Name"] || job["Client Name"]) + " firearm use permission.pdf");
  if (record["PDF File ID"]) { try { DriveApp.getFileById(record["PDF File ID"]).setTrashed(true); } catch (e) { } }
  const file = folder.createFile(pdf);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  record["PDF URL"] = file.getUrl(); record["PDF File ID"] = file.getId();
  writeRecord(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS, "Permission ID", record);
  return jsonResponse({ status: "success", permission: readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS).find(x => x["Permission ID"] === record["Permission ID"]), downloadUrl: "https://drive.google.com/uc?export=download&id=" + file.getId() });
}

function fileDataUri(fileId) {
  if (!fileId) return "";
  try { const b = DriveApp.getFileById(fileId).getBlob(); return "data:" + b.getContentType() + ";base64," + Utilities.base64Encode(b.getBytes()); } catch (e) { return ""; }
}

function permissionHtml(r, job, client, signature, mapImg) {
  const logo = logoDataUri();
  let areas = [], excl = [];
  try { areas = JSON.parse(r["Permitted Areas"] || "[]"); } catch (e) { }
  try { excl = JSON.parse(r["Exclusion Areas"] || "[]"); } catch (e) { }
  const today = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "d MMMM yyyy");
  const authority = { owner: "the owner", occupier: "the occupier", representative: "an authorised representative of the owner or occupier" }[r["Authority"]] || (r["Authority"] || "the owner or occupier");
  const conds = String(r["Conditions"] || "").split(/\n+/).map(x => x.trim()).filter(Boolean);
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    @page{size:A4;margin:18mm 16mm 20mm}
    body{font-family:Arial,Helvetica,sans-serif;color:#000;font-size:10.5pt;line-height:1.5;margin:0}
    .band{height:4px;background:#000;margin-bottom:14px}
    table.head{border:none;margin:0;width:100%} table.head td{border:none;padding:0;vertical-align:top} .head img{width:150px} .head .meta{text-align:right;font-size:9.5pt;color:#4A4A4A}
    h1{font-size:19pt;font-weight:normal;letter-spacing:-0.02em;margin:18px 0 10px}
    h2{font-size:12pt;font-weight:bold;margin:16px 0 6px;padding-bottom:3px;border-bottom:1px solid #000}
    p{margin:0 0 8px}
    table.facts{width:100%;border-collapse:collapse;font-size:10pt} table.facts td{border-bottom:1px solid #DADADA;padding:4px 5px;vertical-align:top} table.facts td:first-child{width:34%;color:#4A4A4A}
    .map img{width:100%;border:1px solid #DADADA}
    .legend{font-size:9pt;color:#4A4A4A}
    .sig img{height:60px}
    .sigrow td{vertical-align:bottom;padding-top:18px}
    ol{margin:0 0 8px 18px;padding:0} li{margin-bottom:3px}
    .foot{margin-top:18px;font-size:8.5pt;color:#4A4A4A;border-top:1px solid #DADADA;padding-top:6px}
  </style></head><body>
  <div class="band"></div>
  <table class="head"><tr><td>${logo ? `<img src="${logo}">` : "<strong>TERANA ENVIRONMENTAL</strong>"}</td><td class="meta">Terana Environmental Pty Ltd<br>ABN 21 699 686 916<br>0450 303 434<br>courtney@teranaenvironmental.com.au</td></tr></table>
  <h1>Permission to use firearms for pest animal control</h1>
  <table class="facts">
    <tr><td>Land</td><td>${esc(r["Property Address"] || job["Site Address"] || "")}</td></tr>
    <tr><td>Landholder</td><td>${esc(r["Landholder Name"])}, ${esc(authority)}</td></tr>
    <tr><td>Client</td><td>${esc(client["Name"] || job["Client Name"] || "")}</td></tr>
    <tr><td>Purpose</td><td>${esc(r["Purpose"] || "Culling, euthanasia or other humane destruction of pest animals")}${r["Species"] ? ", " + esc(r["Species"]) : ""}</td></tr>
    <tr><td>Period</td><td>${esc(fmtAU(r["Valid From"]))}${r["Valid To"] ? " to " + esc(fmtAU(r["Valid To"])) : " until revoked"}</td></tr>
    <tr><td>Permission holder</td><td>Terana Environmental Pty Ltd and the licensed shooters it engages</td></tr>
    <tr><td>Carcass disposal</td><td>${esc(r["Carcass Disposal"] || "")}</td></tr>
    <tr><td>Job reference</td><td>${esc(job["Job ID"])}</td></tr>
  </table>
  <h2>Permission</h2>
  <p>I, ${esc(r["Landholder Name"])}, confirm that I am ${esc(authority)} of the land described above and that I am authorised to give this permission.</p>
  <p>I give Terana Environmental Pty Ltd and the licensed shooters it engages permission to enter the land and to use firearms on it for the purpose stated above, during the period stated above, within the permitted areas shown on the map${conds.length ? " and subject to the conditions below" : ""}.</p>
  <p>I may revoke this permission at any time by written notice to Terana Environmental, including by email or text message.</p>
  ${conds.length ? `<h2>Conditions</h2><ol>${conds.map(c => `<li>${esc(c)}</li>`).join("")}</ol>` : ""}
  <h2>Permitted areas</h2>
  ${mapImg ? `<div class="map"><img src="${mapImg}"></div>` : "<p>No map attached.</p>"}
  <p class="legend">${areas.length ? "Permitted: " + esc(areas.map((a, i) => a.name || ("Area " + (i + 1))).join(", ")) + ". " : ""}${excl.length ? "Excluded: " + esc(excl.map((a, i) => a.name || ("Exclusion " + (i + 1))).join(", ")) + "." : ""}</p>
  <h2>Signed</h2>
  <table class="facts sigrow"><tr><td style="width:50%;border:none">${signature ? `<div class="sig"><img src="${signature}"></div>` : "<div style='height:60px'></div>"}<div style="border-top:1px solid #000;padding-top:3px">${esc(r["Signed By"] || r["Landholder Name"])}, ${esc(authority)}<br>${esc(fmtAU(r["Signed Date"]) || today)}</div></td><td style="width:50%;border:none;padding-left:18px"><div style="height:60px"></div><div style="border-top:1px solid #000;padding-top:3px">For Terana Environmental Pty Ltd<br>${esc(today)}</div></td></tr></table>
  <div class="foot">Terana Environmental holds a Professional Shooter Business Licence under the Firearms Act 2024 (WA). Shooting is carried out by licensed shooters in line with the Act, the Firearms Regulations 2024, the relevant codes of practice${conds.length ? " and the conditions above" : ""}. Records of each shooting activity are kept for five years as required by regulation 81. This permission is kept with the job file.</div>
  </body></html>`;
}

/* ============================================================
   CHEMICALS: SDS register and manifest (Products tab, extended)
   ============================================================ */
const PRODUCTS_HEADERS = [
  "Product Name", "Active Constituent", "SDS Link",
  // Added Oct 2026 for the register and manifest.
  "SDS Issue Date", "Poison Schedule", "DG Class", "UN Number", "Pack Size", "Unit", "Quantity On Hand", "Storage Location", "Max Quantity", "APVMA Number", "Notes", "Status", "Updated", "Updated By",
  // Added Oct 2026 to match the paper SDS register.
  "Manufacturer / Supplier"
];
function hubSaveProduct(pr, session) {
  if (!String(pr["Product Name"] || "").trim()) return jsonResponse({ status: "error", message: "Product needs a name." });
  const sheet = ensureHubHeaders(PRODUCTS_TAB_NAME, PRODUCTS_HEADERS);
  const existing = readTable(PRODUCTS_TAB_NAME, PRODUCTS_HEADERS).find(x => x["Product Name"] === (pr["Original Name"] || pr["Product Name"]));
  const record = Object.assign({}, existing || {}, pr);
  delete record["Original Name"];
  ["Quantity On Hand", "Max Quantity", "Pack Size"].forEach(k => { if (record[k] === "" || record[k] == null) { record[k] = ""; return; } const n = Number(record[k]); record[k] = isNaN(n) ? record[k] : n; });
  if (!record["Status"]) record["Status"] = "In use";
  record["Updated"] = new Date(); record["Updated By"] = session.name;
  // Products tab is keyed by name; if the name changed, update the row found under the old name.
  const key = pr["Original Name"] || record["Product Name"];
  const row = findRowNumberByKey(sheet, PRODUCTS_HEADERS, "Product Name", key);
  const values = PRODUCTS_HEADERS.map(h => record[h] === undefined || record[h] === null ? "" : record[h]);
  if (row) sheet.getRange(row, 1, 1, PRODUCTS_HEADERS.length).setValues([values]);
  else sheet.getRange(sheet.getLastRow() + 1, 1, 1, PRODUCTS_HEADERS.length).setValues([values]);
  return jsonResponse({ status: "success", product: readTable(PRODUCTS_TAB_NAME, PRODUCTS_HEADERS).find(x => x["Product Name"] === record["Product Name"]) });
}


/* ============================================================
   CHEMICAL MOVEMENTS: stock in and out, written automatically
   from the Job log and manually from the Chemicals page.
   ============================================================ */
const CHEMICAL_MOVEMENTS_TAB_NAME = "Chemical Movements";
const CHEMICAL_MOVEMENTS_HEADERS = ["Date", "Product", "Type", "Quantity", "Unit", "Balance After", "Job ID", "Job Title", "Site / Client", "By", "Note", "Recorded"];

// Pull the number out of free text like "250 g", "1.5 L" or "2 x 500 g".
function parseQuantity(text) {
  const t = String(text || "").trim();
  const mult = t.match(/^(\d+(?:\.\d+)?)\s*[xX×]\s*(\d+(?:\.\d+)?)/);
  if (mult) return Number(mult[1]) * Number(mult[2]);
  const m = t.match(/-?\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : NaN;
}

function applyStockMove(productName, qtySigned, type, info) {
  const sheet = ensureHubHeaders(PRODUCTS_TAB_NAME, PRODUCTS_HEADERS);
  const row = findRowNumberByKey(sheet, PRODUCTS_HEADERS, "Product Name", productName);
  if (!row) return null;
  const width = sheet.getLastColumn();
  const hdr = sheet.getRange(1, 1, 1, width).getValues()[0].map(String);
  const col = n => hdr.indexOf(n) + 1;
  const current = Number(sheet.getRange(row, col("Quantity On Hand")).getValue() || 0);
  const unit = String(sheet.getRange(row, col("Unit")).getValue() || "");
  const packSize = Number(sheet.getRange(row, col("Pack Size")).getValue() || 0);
  const balance = Math.round((current + qtySigned) * 1000) / 1000;
  const packsText = packSize ? " (" + Math.floor(balance / packSize) + " x " + packSize + " " + unit + (Math.round((balance - Math.floor(balance / packSize) * packSize) * 1000) / 1000 ? " + " + Math.round((balance - Math.floor(balance / packSize) * packSize) * 1000) / 1000 + " " + unit + " open" : "") + ")" : "";
  sheet.getRange(row, col("Quantity On Hand")).setValue(balance);
  sheet.getRange(row, col("Updated")).setValue(new Date());
  if (info.by) sheet.getRange(row, col("Updated By")).setValue(info.by);
  const when = info.date || Utilities.formatDate(new Date(), "Australia/Perth", "yyyy-MM-dd");
  const line = when + ": " + (qtySigned < 0 ? "used " : "added ") + Math.abs(qtySigned) + (unit ? " " + unit : "") +
    (info.jobTitle ? " on " + info.jobTitle : "") + (info.jobId ? " (" + info.jobId + ")" : "") + (info.site && !info.jobTitle ? " at " + info.site : "") +
    (info.note ? ", " + info.note : "") + ". Balance " + balance + (unit ? " " + unit : "") + packsText;
  const notesCell = sheet.getRange(row, col("Notes"));
  const notes = String(notesCell.getValue() || "");
  notesCell.setValue((notes ? notes + "\n" : "") + line);
  const mv = getOrCreateSheet(CHEMICAL_MOVEMENTS_TAB_NAME, CHEMICAL_MOVEMENTS_HEADERS);
  mv.getRange(mv.getLastRow() + 1, 1, 1, CHEMICAL_MOVEMENTS_HEADERS.length).setValues([[when, productName, type, qtySigned, unit, balance, info.jobId || "", info.jobTitle || "", info.site || "", info.by || "", info.note || "", new Date()]]);
  return { balance, unit, line };
}

// Called from the Job log when a pesticide was applied.
function recordChemicalUse(v) {
  const qty = parseQuantity(v.quantityUsed);
  if (!v.product || isNaN(qty) || qty <= 0) return;
  if (/%/.test(String(v.quantityUsed))) return;   // a concentration, not an amount
  applyStockMove(v.product, -qty, "Used", { date: v.date, jobId: v.jobId, jobTitle: v.jobTitle, site: v.siteClient, by: v.technician, note: v.applicationMethod ? String(v.applicationMethod) : "" });
}

// Manual purchase, stocktake or disposal from the Chemicals page.
function hubStockMove(m, session) {
  const qty = Number(m.quantity);
  if (!m.product || isNaN(qty) || qty === 0) return jsonResponse({ status: "error", message: "Pick a product and enter an amount." });
  const type = m.type || "Adjusted";
  const signed = type === "Purchased" ? Math.abs(qty) : (type === "Used" || type === "Disposed") ? -Math.abs(qty) : qty;
  const out = applyStockMove(m.product, signed, type, { date: m.date, by: session.name, note: m.note || "" });
  if (!out) return jsonResponse({ status: "error", message: "Product not found." });
  return jsonResponse({ status: "success", balance: out.balance, unit: out.unit });
}

/* ============================================================
   SETTINGS: manifest header and emergency details (key / value)
   ============================================================ */
const SETTINGS_TAB_NAME = "Settings";
const SETTINGS_HEADERS = ["Key", "Value"];
const SETTINGS_DEFAULTS = {
  "Business Name": "Terana Environmental Pty Ltd", "Vehicle Registration": "", "Vehicle Description": "",
  "Responsible Person": "Courtney Kelly", "Emergency Contact Number": "0450 303 434",
  "Spill Kit Location": "Rear of vehicle", "Fire Extinguisher": "1.5 kg dry powder ABE, in front of passenger seat",
  "Manifest Storage Default": "Inside the original container, inside double locked cabinet on roof at rear of vehicle",
  "Anthropic API Key": ""   // for the Tidy wording button. Paste the key from console.anthropic.com. Leave blank to turn the button off.
};
function getSettings() {
  const sheet = getOrCreateSheet(SETTINGS_TAB_NAME, SETTINGS_HEADERS);
  const out = Object.assign({}, SETTINGS_DEFAULTS);
  const last = sheet.getLastRow();
  const have = {};
  if (last >= 2) sheet.getRange(2, 1, last - 1, 2).getValues().forEach(r => { if (r[0]) { out[String(r[0])] = String(r[1] || ""); have[String(r[0])] = true; } });
  const missing = Object.keys(SETTINGS_DEFAULTS).filter(k => !have[k]);
  if (missing.length) sheet.getRange(sheet.getLastRow() + 1, 1, missing.length, 2).setValues(missing.map(k => [k, SETTINGS_DEFAULTS[k]]));
  return out;
}
function publicSettings() { const s = getSettings(); const o = {}; Object.keys(s).forEach(k => { if (!/key|secret/i.test(k)) o[k] = s[k]; }); return o; }
function hubSaveSettings(settings, session) {
  const sheet = getOrCreateSheet(SETTINGS_TAB_NAME, SETTINGS_HEADERS);
  Object.keys(settings).forEach(k => {
    const row = findRowNumberByKey(sheet, SETTINGS_HEADERS, "Key", k);
    if (row) sheet.getRange(row, 2).setValue(settings[k]); else sheet.appendRow([k, settings[k]]);
  });
  return jsonResponse({ status: "success", settings: getSettings() });
}

/* ============================================================
   REGISTER OF EMPLOYEES: the Technicians tab, widened. Columns
   A to E are the ones the field forms already read, so they stay.
   ============================================================ */
const EMPLOYEE_HEADERS = [
  "Name", "LPMP Licence Number", "Status", "Firearms Licence Number", "Firearms Authorised",
  "Residential Address", "Date Of Birth", "Date Start of Employment", "Date End of Employment",
  "Phone", "Email", "Role", "Licence Expiry", "Firearms Licence Expiry", "Notes", "Updated", "Updated By"
];
function hubSaveEmployee(e, session) {
  if (!String(e["Name"] || "").trim()) return jsonResponse({ status: "error", message: "Employee needs a name." });
  const sheet = ensureHubHeaders(TECHNICIANS_TAB_NAME, EMPLOYEE_HEADERS);
  const key = e["Original Name"] || e["Name"];
  const existing = readTable(TECHNICIANS_TAB_NAME, EMPLOYEE_HEADERS).find(x => x["Name"] === key) || {};
  const record = Object.assign({}, existing, e); delete record["Original Name"];
  record["Updated"] = new Date(); record["Updated By"] = session.name;
  const width = sheet.getLastColumn();
  const hdr = sheet.getRange(1, 1, 1, width).getValues()[0].map(String);
  const values = hdr.map(h => record[h] === undefined || record[h] === null ? (existing[h] || "") : record[h]);
  const row = findRowNumberByKey(sheet, EMPLOYEE_HEADERS, "Name", key);
  if (row) sheet.getRange(row, 1, 1, width).setValues([values]);
  else sheet.getRange(sheet.getLastRow() + 1, 1, 1, width).setValues([values]);
  return jsonResponse({ status: "success", employee: readTable(TECHNICIANS_TAB_NAME, EMPLOYEE_HEADERS).find(x => x["Name"] === record["Name"]) });
}

/* ============================================================
   DOCUMENTS: policies, procedures and forms. Built-in documents
   live in the hub; add Drive links for anything else here.
   ============================================================ */
const DOCUMENTS_TAB_NAME = "Documents";
const DOCUMENTS_HEADERS = ["Title", "Category", "Link", "Version", "Review Date", "Notes", "Updated", "Updated By",
  // SMS register, added Oct 2026. Review Date = next review due; Last Reviewed + Review Months drive it.
  "Doc No", "Type", "Last Reviewed", "Review Months", "Owner", "Status", "Drive File ID", "Doc ID"];
// Courtney's existing SMS set in Drive (TE-WHS-...). Seeded once; edit or add rows in the Documents tab or the SMS page.
const SMS_SEED = [
  ["Emergency Response Plan", "SMS", "emergency-plan.html", "1", "", "Lives in the hub, opens on the phone", "TE-WHS-ERP-001", "Plan", "2026-10-15", 12],
  ["SWMS: Ground Culling Operations", "SMS", "https://drive.google.com/file/d/1k1ALu_SMsot3u23cWd2uleWWviWha2sV/view", "", "", "", "TE-WHS-SAF-001", "SWMS", "2026-08-11", 12],
  ["SWMS: Chemical Use", "SMS", "https://drive.google.com/file/d/18c5nuLTkcziwRmqXtet-Ls8_o82pZDU-/view", "", "", "", "TE-WHS-SAF-002", "SWMS", "2026-08-10", 12],
  ["SWMS: Conservation Dogs", "SMS", "https://drive.google.com/file/d/1Fjja_xL3QKlLHMPAlMP05Gej-IrbKpUV/view", "", "", "", "TE-WHS-SAF-003", "SWMS", "2026-08-11", 12],
  ["SWMS: Working in areas with Phytophthora", "SMS", "https://drive.google.com/file/d/1dVFB02HzsG61z8oP4hrmPzC5hI7JHJk2/view", "", "", "", "TE-WHS-SAF-004", "SWMS", "2026-08-11", 12],
  ["Procedure: Staff Field Hygiene", "SMS", "https://drive.google.com/file/d/1PElsLndGzXWrpEOioCgPsXknb7kuIOO6/view", "", "", "", "TE-WHS-PRO-001", "Procedure", "2026-08-11", 12],
  ["Procedure: Police notification", "SMS", "https://drive.google.com/file/d/1F4ZnDa6c2y0kaPqkYWV6PLapbu0o4kT8/view", "", "", "", "TE-WHS-PRO-002", "Procedure", "2025-12-01", 12],
  ["Pre-site screen: Phytophthora", "SMS", "https://drive.google.com/file/d/1xgbUgSaXSZUKrN4VIbMbxOk7anFvwnzX/view", "", "", "", "TE-WHS-SCR-001", "Pre-site screen", "2026-08-10", 12],
  ["Pre-site screen: General", "SMS", "https://drive.google.com/file/d/1q_c3jS8jpVUosntqEFeTSTse8HaPgNC0/view", "", "", "", "TE-WHS-SCR-002", "Pre-site screen", "2026-08-27", 12],
  ["Shoot Plan template", "SMS", "https://docs.google.com/document/d/1kdKUEey2ZfLNaORRtOqMMJFW7JKeFuyArDNLr39URuw/edit", "", "", "Copied per job from the job's Planning card", "TE-WHS-TPL-001", "Template", "2026-02-10", 12],
  ["JHA form template", "SMS", "https://drive.google.com/file/d/1MANouou7bHMQ83u_qQhwKTzNjzoLNQeu/view", "", "", "Site-specific JHA, copied per job from the Planning card", "TE-WHS-TPL-002", "Template", "2019-09-19", 12]
];
function nextReview(lastReviewed, months) {
  const d = lastReviewed ? new Date(String(lastReviewed).slice(0, 10) + "T00:00:00") : null; if (!d || isNaN(d)) return "";
  d.setMonth(d.getMonth() + (Number(months) || 12));
  return Utilities.formatDate(d, "Australia/Perth", "yyyy-MM-dd");
}
function seedSmsDocuments() {
  const sheet = ensureHubHeaders(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS);
  const existing = readTable(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS);
  const have = {}; existing.forEach(r => { if (r["Doc No"]) have[r["Doc No"]] = true; if (r["Title"]) have[r["Title"]] = true; });
  SMS_SEED.forEach(row => {
    if (have[row[6]] || have[row[0]]) return;
    const rec = { "Title": row[0], "Category": row[1], "Link": row[2], "Version": row[3], "Notes": row[5], "Doc No": row[6], "Type": row[7], "Last Reviewed": row[8], "Review Months": row[9], "Review Date": nextReview(row[8], row[9]), "Owner": "Courtney Kelly", "Status": "Current", "Drive File ID": driveIdFromUrl(row[2]) || "", "Doc ID": newId("D"), "Updated": new Date(), "Updated By": "setup" };
    writeRecord(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS, "Doc ID", rec);
  });
  // Give any older rows an id so they can be signed against.
  readTable(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS).forEach(r => { if (!r["Doc ID"]) { r["Doc ID"] = newId("D"); writeRecord(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS, "Title", r); } });
}
function hubSaveDocument(d, session) {
  if (!String(d["Title"] || "").trim()) return jsonResponse({ status: "error", message: "Document needs a title." });
  ensureHubHeaders(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS);
  const all = readTable(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS);
  const existing = (d["Doc ID"] && all.find(x => x["Doc ID"] === d["Doc ID"])) || (d["Original Title"] && all.find(x => x["Title"] === d["Original Title"])) || null;
  const record = Object.assign({}, existing || {}, d); delete record["Original Title"];
  if (!record["Doc ID"]) record["Doc ID"] = newId("D");
  if (!record["Status"]) record["Status"] = "Current";
  if (record["Last Reviewed"]) record["Review Date"] = nextReview(record["Last Reviewed"], record["Review Months"] || 12);
  record["Drive File ID"] = driveIdFromUrl(record["Link"] || "") || "";
  record["Updated"] = new Date(); record["Updated By"] = session.name;
  writeRecord(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS, "Doc ID", record);
  return jsonResponse({ status: "success", document: record });
}
function hubMarkReviewed(docId, session, note) {
  const r = readTable(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS).find(x => x["Doc ID"] === docId);
  if (!r) return jsonResponse({ status: "error", message: "Document not found." });
  const today = Utilities.formatDate(new Date(), "Australia/Perth", "yyyy-MM-dd");
  r["Last Reviewed"] = today; r["Review Date"] = nextReview(today, r["Review Months"] || 12);
  if (note) r["Notes"] = (r["Notes"] ? r["Notes"] + "\n" : "") + today + ": reviewed by " + session.name + (note === true ? "" : ", " + note);
  r["Updated"] = new Date(); r["Updated By"] = session.name;
  writeRecord(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS, "Doc ID", r);
  return jsonResponse({ status: "success", document: r });
}
function hubDeleteDocument(docId, session) {
  const sheet = ensureHubHeaders(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS);
  const row = findRowNumberByKey(sheet, DOCUMENTS_HEADERS, "Doc ID", docId);
  if (!row) return jsonResponse({ status: "error", message: "Not found." });
  sheet.deleteRow(row); return jsonResponse({ status: "success" });
}
// Copy a template (Shoot Plan, JHA) into the job's Drive folder and hand back the link.
function hubCopyTemplate(docId, jobId, session) {
  const tpl = readTable(DOCUMENTS_TAB_NAME, DOCUMENTS_HEADERS).find(x => x["Doc ID"] === docId);
  if (!tpl || !tpl["Drive File ID"]) return jsonResponse({ status: "error", message: "That template has no Drive file." });
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === jobId);
  if (!job) return jsonResponse({ status: "error", message: "Job not found." });
  const folder = jobPhotoFolder(jobId, job["Title"], job["Site Address"], job["Start Date"] || "");
  const name = safeName((tpl["Type"] === "Template" ? tpl["Title"].replace(/ template$/i, "") : tpl["Title"]) + " - " + (job["Client Name"] || "") + " - " + job["Title"]);
  const made = toGoogleDoc(tpl["Drive File ID"], name, folder);
  if (made.error) return jsonResponse({ status: "error", message: made.error });
  // Fill the site line on SWMS-style documents so the copy is job specific.
  try { fillDocCell(made.id, /^SITE\s*\/\s*PROJECT NAME/i, [job["Site Address"], job["Site Name"], job["Client Name"]].filter(Boolean).join(", ")); } catch (e) { Logger.log("Site fill: " + e); }
  return jsonResponse({ status: "success", url: made.url, id: made.id, name, converted: made.converted });
}
// Copy a Drive file as a Google Doc so the hub can write names and signatures into it.
// A .docx master is converted on the way (needs the Drive API service turned on in the script editor).
function toGoogleDoc(fileId, name, folder) {
  const file = DriveApp.getFileById(fileId);
  if (file.getMimeType() === MimeType.GOOGLE_DOCS) { const c = file.makeCopy(name, folder); return { id: c.getId(), url: c.getUrl(), converted: false }; }
  if (typeof Drive === "undefined") return { error: "This master is a Word file. To make a signable copy, either save the master as a Google Doc once (open it in Drive, File > Save as Google Docs, then update the link on the SMS page), or turn on the Drive API service in the script editor (Services, plus, Drive API, Add)." };
  try {
    let res;
    try { res = Drive.Files.copy({ name, parents: [folder.getId()], mimeType: MimeType.GOOGLE_DOCS }, fileId); }   // v3
    catch (e1) { res = Drive.Files.copy({ title: name, parents: [{ id: folder.getId() }], mimeType: MimeType.GOOGLE_DOCS }, fileId, { convert: true }); }   // v2
    const c = DriveApp.getFileById(res.id);
    return { id: c.getId(), url: c.getUrl(), converted: true };
  } catch (e) { return { error: "Could not convert the Word file to a Google Doc: " + e.message }; }
}
// Find the table cell whose text matches, then write into the next cell on that row.
function fillDocCell(docId, labelRe, value) {
  const doc = DocumentApp.openById(docId); const body = doc.getBody();
  const tables = body.getTables();
  for (let t = 0; t < tables.length; t++) {
    const tb = tables[t];
    for (let r = 0; r < tb.getNumRows(); r++) {
      const row = tb.getRow(r);
      for (let c = 0; c < row.getNumCells(); c++) {
        if (labelRe.test(row.getCell(c).getText().trim())) { const target = row.getCell(Math.min(c + 1, row.getNumCells() - 1)); if (target !== row.getCell(c)) { target.setText(value); doc.saveAndClose(); return true; } }
      }
    }
  }
  doc.saveAndClose(); return false;
}
/* Write a name, signature image and date into the SWMS sign-off tables.
   Worker: first empty "Name:" / "Signature:" pair in the WORKER SIGNOFF table.
   Authoriser: the "PERSON AUTHORISING USE OF SWMS" row. */
function stampDocSignature(docId, name, signatureDataUrl, role, when) {
  const m = String(signatureDataUrl || "").match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
  const sigBlob = m ? Utilities.newBlob(Utilities.base64Decode(m[2]), m[1], "signature.png") : null;
  const doc = DocumentApp.openById(docId); const body = doc.getBody();
  const dateStr = Utilities.formatDate(when || new Date(), "Australia/Perth", "d/M/yyyy");
  const putSig = (cell) => { cell.setText(""); if (sigBlob) { const img = cell.appendImage(sigBlob); const w = 150; img.setWidth(w); img.setHeight(Math.round(w * 260 / 900)); } };
  const tables = body.getTables(); let done = false;
  if (/author/i.test(role || "")) {
    for (let t = 0; t < tables.length && !done; t++) { const tb = tables[t];
      for (let r = 0; r < tb.getNumRows() && !done; r++) { const row = tb.getRow(r);
        if (/PERSON AUTHORISING/i.test(row.getCell(0).getText())) {
          const next = tb.getRow(Math.min(r + 1, tb.getNumRows() - 1));
          for (let c = 0; c < next.getNumCells(); c++) { const txt = next.getCell(c).getText().trim(); if (/^Name:?$/i.test(txt)) next.getCell(c).setText("Name: " + name); else if (/^Signature:?$/i.test(txt)) putSig(next.getCell(c)); else if (/^Date:?$/i.test(txt)) next.getCell(c).setText("Date: " + dateStr); }
          done = true;
        }
      }
    }
  } else {
    for (let t = 0; t < tables.length && !done; t++) { const tb = tables[t];
      if (!/WORKER SIGN/i.test(tb.getRow(0).getText())) continue;
      for (let r = 1; r < tb.getNumRows() && !done; r++) { const row = tb.getRow(r);
        for (let c = 0; c + 1 < row.getNumCells() && !done; c++) {
          if (/^Name:?$/i.test(row.getCell(c).getText().trim()) && /^Signature:?$/i.test(row.getCell(c + 1).getText().trim())) {
            row.getCell(c).setText("Name: " + name + "  " + dateStr); putSig(row.getCell(c + 1)); done = true;
          }
        }
      }
    }
  }
  if (!done) { body.appendParagraph(""); body.appendParagraph((/author/i.test(role || "") ? "Authorised by: " : "Signed by: ") + name + ", " + dateStr); if (sigBlob) { const img = body.appendImage(sigBlob); img.setWidth(150); img.setHeight(43); } }
  doc.saveAndClose();
  return done;
}


/* ============================================================
   DRIVE FILING: "Terana Clients / <client> / Jobs / <date title>"
   Photos, reports, permissions and fox den surveys all land under
   the client's folder. Anything without a job falls back to the
   old "Field Survey Photos" folder.
   ============================================================ */
const CLIENTS_FOLDER_NAME = "Terana Clients";
function safeName(x) { return String(x || "").replace(/[\\/:*?"<>|]/g, "").trim() || "Unnamed"; }
function clientFolder(client) {
  if (client["Drive Folder ID"]) { try { return DriveApp.getFolderById(client["Drive Folder ID"]); } catch (e) { } }
  const folder = getOrCreateSubFolder(getOrCreateNamedFolder(CLIENTS_FOLDER_NAME), safeName(client["Name"]));
  if (client["Client ID"]) {
    try {
      const sheet = ensureHubHeaders(CLIENTS_TAB_NAME, CLIENTS_HEADERS);
      const row = findRowNumberByKey(sheet, CLIENTS_HEADERS, "Client ID", client["Client ID"]);
      if (row) {
        const hdr = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0].map(String);
        sheet.getRange(row, hdr.indexOf("Drive Folder ID") + 1).setValue(folder.getId());
        sheet.getRange(row, hdr.indexOf("Drive Folder URL") + 1).setValue(folder.getUrl());
      }
    } catch (e) { Logger.log("Folder id save: " + e); }
  }
  return folder;
}
function clientFolderForJob(jobId) {
  if (!jobId) return null;
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === jobId);
  if (!job) return null;
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === job["Client ID"]);
  return client ? clientFolder(client) : null;
}
function jobPhotoFolder(jobId, jobTitle, site, dateStr) {
  const cf = clientFolderForJob(jobId);
  if (!cf) return getOrCreatePhotoFolder();
  const day = String(dateStr || Utilities.formatDate(new Date(), "Australia/Perth", "yyyy-MM-dd")).slice(0, 10);
  return getOrCreateSubFolder(getOrCreateSubFolder(cf, "Jobs"), day + " " + safeName(jobTitle || site || jobId));
}


/* ============================================================
   DOCUMENTS FOR SIGNATURE: proposals, site screens, anything a
   client signs. Signed on the operator's phone, or by a link that
   needs no login (the link carries a random token). The signed PDF
   files under Terana Clients / <client> / Signed forms.
   ============================================================ */
const SIGN_TAB_NAME = "Signatures";
const SIGN_HEADERS = ["Sign ID", "Job ID", "Client ID", "Type", "Title", "Body", "Signer Name", "Signer Email", "Signer Role", "Status", "Token",
  "Sent Date", "Signed Date", "Signed Name", "Signed How", "Signature File ID", "PDF URL", "PDF File ID", "Created", "Created By", "Updated",
  "Fees",   // JSON [{item, qty, unit, rate, amount}], shown as a schedule of fees in the PDF
  "Include Permission",   // Yes: the job's shooting permission is appended and signed with the same signature
  "Answers",   // JSON {question: answer} for "? " lines the client fills in
  "Scope", "Valid To", "Cancelled Date",   // Scope "Client" = standing agreement; "SMS" = read-and-understood acknowledgement of an SMS document
  "Doc ID",   // the SMS document acknowledged (Documents tab Doc ID)
  "Target Doc ID", "Sign Role", "Target Doc URL", "Doc PDF URL",   // Doc PDF URL = snapshot of the whole SWMS as signed, saved to Drive each time   // Google Doc that the name and signature are written into (a job copy of a SWMS), and whether as Worker or Authoriser
  "Include Inspection"];   // Yes: the latest site inspection from the Job log (notes, recommendations, photos) is added to the letter
function slimSign(d) { const o = Object.assign({}, d); delete o["Body"]; delete o["Fees"]; return o; }
function isLive(r) { if (r["Status"] === "Void" || r["Status"] === "Cancelled") return false; const to = String(r["Valid To"] || "").slice(0, 10); return !to || to >= Utilities.formatDate(new Date(), "Australia/Perth", "yyyy-MM-dd"); }
// The job's own permission, or the client's standing one.
function permissionForJob(jobId) {
  const all = readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS);
  const own = all.find(x => x["Job ID"] === jobId && x["Status"] !== "Void" && x["Status"] !== "Cancelled");
  if (own) return own;
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === jobId);
  if (!job || !job["Client ID"]) return null;
  return all.find(x => x["Scope"] === "Client" && x["Client ID"] === job["Client ID"] && x["Status"] === "Signed" && isLive(x)) || null;
}
// Latest Job log entry for the job, preferring one that was a site inspection. Up to 4 photos as data URIs.
function inspectionForJob(jobId) {
  if (!jobId) return null;
  const visits = visitsForJob(jobId).filter(v => v.kind === "Site visit");
  if (!visits.length) return null;
  const insp = visits.filter(v => /inspection/i.test(String(v.methods || "")));
  const v = (insp.length ? insp : visits)[(insp.length ? insp : visits).length - 1];
  const photos = [], captions = [];
  (v.photos || []).slice(0, 4).forEach((u, i) => { const id = driveIdFromUrl(u); const d = id ? fileDataUri(id) : ""; if (d) { photos.push(d); captions.push((v.captions || [])[i] || ""); } });
  return { date: v.date, who: v.who, methods: v.methods, target: v.target, notes: v.notes, recommendations: v.recommendations, photos, captions };
}
function inspectionText(ins) {
  if (!ins) return "";
  const lines = ["## What we found on site", "Site inspection " + (ins.date ? Utilities.formatDate(new Date(ins.date), "Australia/Perth", "d MMMM yyyy") : "") + (ins.who ? " by " + ins.who : "") + (ins.target ? ". Target: " + ins.target : "") + "."];
  if (ins.notes) lines.push("", ins.notes);
  if (ins.recommendations) lines.push("", "## Recommended approach", ins.recommendations);
  return lines.join("\n");
}
function permissionForClient(clientId) { return readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS).find(x => x["Scope"] === "Client" && x["Client ID"] === clientId && x["Status"] !== "Void" && x["Status"] !== "Cancelled") || null; }
function slimAgreement(d) { return { "Sign ID": d["Sign ID"], "Client ID": d["Client ID"], "Job ID": d["Job ID"], "Type": d["Type"], "Title": d["Title"], "Status": d["Status"], "Scope": d["Scope"], "Signed Date": d["Signed Date"], "Signed Name": d["Signed Name"], "Valid To": d["Valid To"], "PDF URL": d["PDF URL"] }; }
const RATE_CARD_TAB_NAME = "Rate Card";
const RATE_CARD_HEADERS = ["Item", "Unit", "Rate ex GST", "Notes"];
function feesHtml(feesJson, esc) {
  let fees = []; try { fees = JSON.parse(feesJson || "[]"); } catch (e) { }
  fees = fees.filter(f => f && (f.item || f.amount));
  if (!fees.length) return "";
  const n = x => Number(x) || 0;
  const sub = fees.reduce((t, f) => t + (f.amount !== "" && f.amount != null ? n(f.amount) : n(f.qty) * n(f.rate)), 0);
  const gst = Math.round(sub * 10) / 100, tot = sub + gst;
  const money = x => "$" + n(x).toLocaleString("en-AU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `<h2>Schedule of fees</h2><table class="fees"><thead><tr><th>Item</th><th class="num">Qty</th><th>Unit</th><th class="num">Rate</th><th class="num">Amount</th></tr></thead><tbody>
    ${fees.map(f => { const amt = f.amount !== "" && f.amount != null ? n(f.amount) : n(f.qty) * n(f.rate); return `<tr><td>${esc(f.item)}</td><td class="num">${esc(f.qty || "")}</td><td>${esc(f.unit || "")}</td><td class="num">${f.rate !== "" && f.rate != null ? money(f.rate) : ""}</td><td class="num">${money(amt)}</td></tr>`; }).join("")}
    <tr class="tot"><td colspan="4">Subtotal ex GST</td><td>${money(sub)}</td></tr><tr class="tot"><td colspan="4">GST</td><td>${money(gst)}</td></tr><tr class="tot grand"><td colspan="4">Total inc GST</td><td>${money(tot)}</td></tr></tbody></table>`;
}

function hubSaveSignDoc(d, signatureDataUrl, session) {
  if ((!d["Job ID"] && !d["Client ID"] && !d["Doc ID"]) || !String(d["Title"] || "").trim()) return jsonResponse({ status: "error", message: "Needs a job, client or document, and a title." });
  const now = new Date();
  const existing = d["Sign ID"] ? readTable(SIGN_TAB_NAME, SIGN_HEADERS).find(x => x["Sign ID"] === d["Sign ID"]) : null;
  if (existing && existing["Status"] === "Signed") return jsonResponse({ status: "error", message: "Already signed. Make a new document instead." });
  const record = Object.assign({}, existing || {}, d);
  const job = record["Job ID"] ? (readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === record["Job ID"]) || {}) : {};
  record["Client ID"] = job["Client ID"] || record["Client ID"] || "";
  if (!record["Scope"]) record["Scope"] = record["Doc ID"] ? "SMS" : record["Job ID"] ? "Job" : "Client";
  if (record["Scope"] === "Client") record["Job ID"] = "";
  if (record["Target Doc URL"] && !record["Target Doc ID"]) record["Target Doc ID"] = driveIdFromUrl(record["Target Doc URL"]) || "";
  if (!record["Sign ID"]) record["Sign ID"] = newId("S");
  if (!record["Token"]) record["Token"] = Utilities.getUuid().replace(/-/g, "") + Utilities.getUuid().replace(/-/g, "").slice(0, 8);
  if (!record["Created"]) { record["Created"] = now; record["Created By"] = session.name; }
  if (!record["Status"]) record["Status"] = "Draft";
  record["Updated"] = now;
  if (signatureDataUrl) finishSigning(record, job, signatureDataUrl, d["Signed Name"] || record["Signer Name"], "In person with " + session.name);
  writeRecord(SIGN_TAB_NAME, SIGN_HEADERS, "Sign ID", record);
  return jsonResponse({ status: "success", doc: slimSign(record) });
}
function hubMarkSignSent(signId, session) {
  const r = readTable(SIGN_TAB_NAME, SIGN_HEADERS).find(x => x["Sign ID"] === signId);
  if (!r) return jsonResponse({ status: "error", message: "Not found." });
  if (r["Status"] !== "Signed") { r["Status"] = "Sent"; r["Sent Date"] = new Date(); r["Updated"] = new Date(); writeRecord(SIGN_TAB_NAME, SIGN_HEADERS, "Sign ID", r); }
  return jsonResponse({ status: "success", doc: slimSign(r) });
}
function hubVoidSignDoc(signId, session) {
  const r = readTable(SIGN_TAB_NAME, SIGN_HEADERS).find(x => x["Sign ID"] === signId);
  if (!r) return jsonResponse({ status: "error", message: "Not found." });
  r["Status"] = "Void"; r["Updated"] = new Date(); writeRecord(SIGN_TAB_NAME, SIGN_HEADERS, "Sign ID", r);
  return jsonResponse({ status: "success" });
}
// Public read for the signing page. Only the token identifies the document; nothing else is exposed.
function publicSignDoc(token) {
  if (!token || token.length <= 20) return jsonResponse({ status: "error", message: "This signing link is not valid." });
  const pm = readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS).find(x => x["Token"] === token);
  if (pm) return publicPermissionDoc(pm);
  const r = readTable(SIGN_TAB_NAME, SIGN_HEADERS).find(x => x["Token"] === token);
  if (!r || r["Status"] === "Void") return jsonResponse({ status: "error", message: "This signing link is not valid." });
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === r["Job ID"]) || {};
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === r["Client ID"]) || {};
  let body = r["Body"], mapImage = "", photos = [], captions = [];
  if (r["Include Inspection"] === "Yes" && r["Job ID"]) { const ins = inspectionForJob(r["Job ID"]); if (ins) { body = inspectionText(ins) + "\n\n" + body; photos = ins.photos; captions = ins.captions; } }
  if (r["Include Permission"] === "Yes") { const pm = r["Job ID"] ? permissionForJob(r["Job ID"]) : permissionForClient(r["Client ID"]); if (pm) { body += "\n\n# Permission to use firearms for pest animal control\n" + permissionBodyText(pm, job, client); mapImage = fileDataUri(pm["Map File ID"]); } }
  let answers = {}; try { answers = JSON.parse(r["Answers"] || "{}"); } catch (e) { }
  return jsonResponse({ status: "success", doc: { title: r["Title"], body, mapImage, photos, captions, answers, fees: r["Fees"] || "", type: r["Type"], signerName: r["Signer Name"], signerRole: r["Signer Role"], status: r["Status"], signedDate: r["Signed Date"], pdfUrl: r["Status"] === "Signed" ? r["PDF URL"] : "", client: client["Name"] || job["Client Name"] || "", job: job["Title"] || "", site: job["Site Address"] || "" } });
}
function signComplete(p) {
  const token = String(p.t || "");
  if (token.length > 20) { const pm = readTable(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS).find(x => x["Token"] === token); if (pm) return permissionSignComplete(pm, p); }
  const r = token.length > 20 ? readTable(SIGN_TAB_NAME, SIGN_HEADERS).find(x => x["Token"] === token) : null;
  if (!r || r["Status"] === "Void") return jsonResponse({ status: "error", message: "This signing link is not valid." });
  if (r["Status"] === "Signed") return jsonResponse({ status: "error", message: "This document has already been signed." });
  if (!p.signatureDataUrl || !String(p.signedName || "").trim()) return jsonResponse({ status: "error", message: "Please type your name and sign." });
  if (p.answers && typeof p.answers === "object") r["Answers"] = JSON.stringify(p.answers);
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === r["Job ID"]) || {};
  finishSigning(r, job, p.signatureDataUrl, String(p.signedName).trim(), "By link");
  r["Updated"] = new Date();
  writeRecord(SIGN_TAB_NAME, SIGN_HEADERS, "Sign ID", r);
  try { MailApp.sendEmail(NOTIFY_EMAIL, "Signed: " + r["Title"] + " (" + (job["Client Name"] || "") + ")", r["Signed Name"] + " signed " + r["Title"] + " for " + (job["Title"] || r["Job ID"]) + ".\n\nPDF: " + r["PDF URL"]); } catch (e) { }
  return jsonResponse({ status: "success", pdfUrl: r["PDF URL"] });
}
function finishSigning(record, job, signatureDataUrl, signedName, how) {
  const now = new Date();
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === record["Client ID"]) || {};
  const folder = record["Scope"] === "SMS" && !client["Client ID"] ? getOrCreateSubFolder(getOrCreateNamedFolder("Terana SMS"), "Signed acknowledgements") : client["Client ID"] ? getOrCreateSubFolder(clientFolder(client), record["Scope"] === "Client" ? "Agreements" : "Signed forms") : getOrCreateNamedFolder("Signed forms");
  const stamp = Utilities.formatDate(now, "Australia/Perth", "yyyy-MM-dd HHmm");
  const sigId = saveDataUrlToDrive(signatureDataUrl, folder, stamp + " signature " + safeName(record["Title"]) + ".png");
  record["Signature File ID"] = sigId || ""; record["Signed Name"] = signedName || record["Signer Name"] || "";
  record["Signed Date"] = now; record["Signed How"] = how; record["Status"] = "Signed";
  if (record["Target Doc ID"]) {
    try {
      stampDocSignature(record["Target Doc ID"], record["Signed Name"], signatureDataUrl, record["Sign Role"] || "Worker", now);
      // A PDF of the whole document as it stands after this signature, next to the document in Drive.
      const src = DriveApp.getFileById(record["Target Doc ID"]);
      const parents = src.getParents(); const dest = parents.hasNext() ? parents.next() : folder;
      const snap = dest.createFile(src.getAs("application/pdf").setName(src.getName() + " signed " + Utilities.formatDate(now, "Australia/Perth", "yyyy-MM-dd HHmm") + " " + safeName(record["Signed Name"]) + ".pdf"));
      record["Doc PDF URL"] = snap.getUrl();
    } catch (e) { Logger.log("Stamp into doc failed: " + e); }
  }
  let pm = null;
  if (record["Include Permission"] === "Yes") {
    pm = record["Job ID"] ? permissionForJob(record["Job ID"]) : permissionForClient(record["Client ID"]);
    if (pm && pm["Status"] !== "Signed") finishPermissionSigning(pm, job, client, signatureDataUrl, record["Signed Name"], how);
  }
  const html = signDocHtml(record, job, client, signatureDataUrl, pm);
  const pdf = Utilities.newBlob(html, "text/html", "signed.html").getAs("application/pdf");
  pdf.setName(stamp.slice(0, 10) + " " + safeName(client["Name"] || job["Client Name"] || "Client") + " " + safeName(record["Title"]) + " signed.pdf");
  const file = folder.createFile(pdf);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  record["PDF URL"] = file.getUrl(); record["PDF File ID"] = file.getId();
}
function signDocHtml(r, job, client, signature, pm) {
  const logo = logoDataUri();
  const permSection = pm ? permissionSectionHtml(pm, job, client) : "";
  const ins = r["Include Inspection"] === "Yes" ? inspectionForJob(r["Job ID"]) : null;
  const esc = x => String(x == null ? "" : x).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  let answers = {}; try { answers = JSON.parse(r["Answers"] || "{}"); } catch (e) { }
  const paras = (function (text) {
    const out = []; let para = [], list = [];
    const flushP = () => { if (para.length) { out.push("<p>" + para.map(esc).join("<br>") + "</p>"); para = []; } };
    const flushL = () => { if (list.length) { out.push("<ul>" + list.map(l => "<li>" + esc(l) + "</li>").join("") + "</ul>"); list = []; } };
    String(text || "").split(/\n/).forEach(raw => {
      const l = raw.trim();
      if (!l) { flushP(); flushL(); return; }
      if (/^#+ /.test(l)) { flushP(); flushL(); out.push("<h2>" + esc(l.replace(/^#+ /, "")) + "</h2>"); return; }
      if (/^\? /.test(l)) { flushP(); flushL(); const q = l.replace(/^\? /, ""); out.push(`<table class="qa"><tr><td class="qq">${esc(q)}</td></tr><tr><td class="qa">${esc(answers[q] || "") || "&nbsp;"}</td></tr></table>`); return; }
      if (/^[-*] /.test(l)) { flushP(); list.push(l.replace(/^[-*] /, "")); return; }
      flushL(); para.push(l);
    });
    flushP(); flushL();
    return out.join("");
  })(r["Body"]);
  const insParas = ins ? (function (text) { return text.split(/\n/).map(l => l.trim()).filter(Boolean).map(l => /^#+ /.test(l) ? "<h2>" + esc(l.replace(/^#+ /, "")) + "</h2>" : "<p>" + esc(l) + "</p>").join(""); })(inspectionText(ins)) : "";
  const photoRow = ins && ins.photos.length ? `<table class="photos"><tr>${ins.photos.map((p, i) => `<td><img src="${p}"><div class="cap">${esc(ins.captions[i] || "")}</div></td>`).join("")}</tr></table>` : "";
  const when = Utilities.formatDate(new Date(r["Signed Date"] || new Date()), "Australia/Perth", "d MMMM yyyy");
  const whenTime = Utilities.formatDate(new Date(r["Signed Date"] || new Date()), "Australia/Perth", "h:mm a");
  const issued = Utilities.formatDate(new Date(r["Created"] || new Date()), "Australia/Perth", "d MMMM yyyy");
  const clientName = client["Name"] || job["Client Name"] || "";
  const contact = [client["Contact Name"], client["Email"], client["Phone"] || client["Mobile"]].filter(Boolean);
  const addr = client["Address"] || [client["Street"], client["City"], client["State"], client["Postcode"]].filter(Boolean).join(" ");
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    @page{size:A4;margin:16mm 16mm 18mm}
    body{font-family:Arial,Helvetica,sans-serif;color:#000;font-size:10.5pt;line-height:1.5;margin:0}
    .band{height:5px;background:#000}
    .band2{height:3px;background:#C1440E;margin-bottom:16px}
    table{border-collapse:collapse}
    table.head{width:100%;margin-bottom:6px}table.head td{vertical-align:top;padding:0}
    .kicker{font-size:8.5pt;letter-spacing:.12em;text-transform:uppercase;color:#C1440E;font-weight:bold;margin:0 0 2px}
    h1{font-size:19pt;margin:0 0 2px;line-height:1.15}
    .issued{color:#555;font-size:9pt;margin:0}
    table.parties{width:100%;margin:14px 0 10px;border-top:1px solid #000;border-bottom:1px solid #000}
    table.parties td{width:50%;vertical-align:top;padding:8px 10px 8px 0;font-size:9.5pt}
    table.parties td+td{border-left:1px solid #ddd;padding-left:12px}
    .lbl{font-size:8pt;letter-spacing:.08em;text-transform:uppercase;color:#555;margin:0 0 2px}
    h2{font-size:11pt;margin:14px 0 4px;padding-bottom:2px;border-bottom:1px solid #ddd}
    p{margin:0 0 7px}ul{margin:0 0 7px 18px;padding:0}li{margin:1px 0}
    table.photos{width:100%;margin:0 0 10px}table.photos td{width:25%;padding:0 4px 0 0;vertical-align:top}table.photos img{width:100%;border:1px solid #000}table.photos .cap{font-size:8.5pt;color:#444;padding:2px 0 0}
    table.fees{width:100%;margin:4px 0 10px}table.fees th{background:#000;color:#fff;font-size:9pt;padding:5px 7px;text-align:left}
    table.fees td{border-bottom:1px solid #ddd;padding:5px 7px;font-size:10pt;text-align:left;vertical-align:top}
    table.fees .num{text-align:right;white-space:nowrap}
    table.fees tr.tot td{border-bottom:none;text-align:right;padding:3px 7px}table.fees tr.tot td:first-child{color:#555}
    table.fees tr.grand td{border-top:2px solid #000;font-weight:bold;padding-top:5px}
    table.sig{width:100%;margin-top:22px}table.sig td{width:50%;vertical-align:top;padding:0 14px 0 0}
    .sigbox{border:1px solid #000;height:70px;padding:4px 8px}.sigbox img{height:60px}
    .sigmeta{font-size:9pt;margin-top:4px}.sigmeta b{display:block;font-size:10pt}
    .stamp{border:1.5px solid #C1440E;color:#C1440E;font-size:8.5pt;letter-spacing:.08em;text-transform:uppercase;padding:3px 8px;display:inline-block;margin-top:6px}
    .foot{margin-top:26px;font-size:8pt;color:#555;border-top:1px solid #000;padding-top:5px}
  </style></head><body><div class="band"></div><div class="band2"></div>
  <table class="head"><tr><td><p class="kicker">${esc(r["Type"] || "Document")}</p><h1>${esc(r["Title"])}</h1><p class="issued">Issued ${esc(issued)}${job["Job ID"] ? ", reference " + esc(job["Job ID"]) : ""}</p></td><td style="text-align:right;width:150px">${logo ? `<img src="${logo}" style="height:58px">` : "<strong>TERANA ENVIRONMENTAL</strong>"}</td></tr></table>
  <table class="parties"><tr><td><p class="lbl">Prepared for</p><strong>${esc(clientName)}</strong>${contact.length ? "<br>" + contact.map(esc).join("<br>") : ""}${addr ? "<br>" + esc(addr) : ""}</td><td><p class="lbl">Prepared by</p><strong>Terana Environmental Pty Ltd</strong><br>ABN 21 699 686 916<br>courtney@teranaenvironmental.com.au<br>0450 303 434${job["Site Address"] ? `<p class="lbl" style="margin-top:8px">Site</p>${esc(job["Site Address"])}` : ""}</td></tr></table>
  ${insParas}${photoRow}
  ${paras}
  ${feesHtml(r["Fees"], esc)}
  ${permSection}
  <table class="sig"><tr><td><div class="sigbox">${signature ? `<img src="${signature}">` : ""}</div><div class="sigmeta"><b>${esc(r["Signed Name"] || r["Signer Name"] || "")}</b>${r["Signer Role"] ? esc(r["Signer Role"]) + ", " : ""}for ${esc(clientName)}<br>${esc(when)}${r["Signed Date"] ? ", " + esc(whenTime) : ""}</div>${r["Signed How"] ? `<span class="stamp">Signed ${esc(r["Signed How"].replace(/^In person with .*/, "in person").replace(/^By link$/, "electronically by link"))}</span>` : ""}</td>
  <td><div class="sigbox"></div><div class="sigmeta"><b>Courtney Kelly</b>Director, Terana Environmental Pty Ltd<br>${esc(issued)}</div></td></tr></table>
  <div class="foot">Terana Environmental Pty Ltd, ABN 21 699 686 916. Licensed pest management, professional shooting and wildlife services, Perth and regional WA. Document ${esc(r["Sign ID"])}, ${esc(r["Signed How"] || "unsigned")}.</div>
  </body></html>`;
}


/* ============================================================
   ARMOURY: firearms on Business Licence 10044996 (Professional
   Shooter). Written into the Firearms tab on setup if the tab is
   empty or still holds the example row. Edit the tab afterwards.
   ============================================================ */
const ARMOURY = [
  ["Howa", "1500", "B480871", "B", ".308 Winchester", "Rifle, bolt action repeater"],
  ["Sako", "90", "JH2414", "B", ".223 Remington", "Rifle, bolt action repeater"],
  ["Sako", "90", "EL5945", "B", ".308 Winchester", "Rifle, bolt action repeater"],
  ["CZ", "452 Lux", "B804977", "A", ".22 Long Rifle", "Rifle, bolt action repeater"],
  ["FX", "Impact MK4", "2225917", "A", ".22 air", "Air rifle. Co-user licence 10020151"],
  ["FX", "Impact MK4 barrel", "178B", "E", ".25 air", "Part, rifle barrel only"],
  ["Remington", "870", "A670711M", "C", "12 gauge", "Shotgun, pump action repeater, single barrel"]
];
function seedFirearms() {
  rewriteFirearmsTab();
  const sheet = SpreadsheetApp.openById(SHEET_ID).getSheetByName(FIREARMS_TAB_NAME);
  const first = String(sheet.getRange(2, 1).getValue() || "");
  if (sheet.getLastRow() >= 2 && !/^Example/i.test(first)) return;   // real data already there, leave it alone
  if (sheet.getLastRow() >= 2) sheet.deleteRow(2);
  // Make, Model, Calibre, Serial, Cat, Description, Licence, Status
  sheet.getRange(2, 1, ARMOURY.length, 8).setValues(ARMOURY.map(a => [a[0], a[1], a[4], a[2], a[3], a[5], "10044996", "In service"]));
}


/* ---------- shooting permission signed by link ---------- */
function permissionSignComplete(r, p) {
  if (r["Status"] === "Signed") return jsonResponse({ status: "error", message: "This permission has already been signed." });
  if (!p.signatureDataUrl || !String(p.signedName || "").trim()) return jsonResponse({ status: "error", message: "Please type your name and sign." });
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === r["Job ID"]) || {};
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === r["Client ID"]) || {};
  finishPermissionSigning(r, job, client, p.signatureDataUrl, String(p.signedName).trim(), "By link");
  try { MailApp.sendEmail(NOTIFY_EMAIL, "Signed: firearm use permission (" + (job["Client Name"] || "") + ")", r["Signed By"] + " signed the firearm use permission for " + (job["Title"] || r["Job ID"]) + ".\n\nPDF: " + r["PDF URL"]); } catch (e) { }
  return jsonResponse({ status: "success", pdfUrl: r["PDF URL"] });
}
function finishPermissionSigning(r, job, client, signatureDataUrl, signedName, how) {
  const now = new Date();
  const folder = client["Client ID"] ? getOrCreateSubFolder(clientFolder(client), "Firearm use") : getOrCreateNamedFolder(PERMISSION_FOLDER_NAME);
  const stamp = Utilities.formatDate(now, "Australia/Perth", "yyyy-MM-dd HHmm");
  const sigId = saveDataUrlToDrive(signatureDataUrl, folder, stamp + " signature.png");
  if (sigId) r["Signature File ID"] = sigId;
  r["Signed By"] = signedName; r["Signed Date"] = now; r["Status"] = "Signed"; r["Signed How"] = how; r["Updated"] = now;
  const html = permissionHtml(r, job, client, signatureDataUrl, fileDataUri(r["Map File ID"]));
  const pdf = Utilities.newBlob(html, "text/html", "permission.html").getAs("application/pdf");
  pdf.setName(stamp.slice(0, 10) + " " + safeName(client["Name"] || job["Client Name"] || "Client") + " firearm use permission.pdf");
  if (r["PDF File ID"]) { try { DriveApp.getFileById(r["PDF File ID"]).setTrashed(true); } catch (e) { } }
  const file = folder.createFile(pdf);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  r["PDF URL"] = file.getUrl(); r["PDF File ID"] = file.getId();
  writeRecord(PERMISSIONS_TAB_NAME, PERMISSIONS_HEADERS, "Permission ID", r);
}
// What the signing page shows for a permission: the same facts and wording as the PDF, with the map.
function publicPermissionDoc(r) {
  const job = readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === r["Job ID"]) || {};
  const client = readTable(CLIENTS_TAB_NAME, CLIENTS_HEADERS).find(c => c["Client ID"] === r["Client ID"]) || {};
  const body = permissionBodyText(r, job, client);
  return jsonResponse({ status: "success", doc: { kind: "permission", title: "Permission to use firearms for pest animal control", body, fees: "", mapImage: fileDataUri(r["Map File ID"]), signerName: r["Landholder Name"], status: r["Status"] === "Signed" ? "Signed" : "Sent", signedDate: r["Signed Date"], pdfUrl: r["Status"] === "Signed" ? r["PDF URL"] : "", client: client["Name"] || job["Client Name"] || "", job: job["Title"] || "", site: job["Site Address"] || "" } });
}
function permissionBodyText(r, job, client) {
  const authority = { owner: "the owner", occupier: "the occupier", representative: "an authorised representative of the owner or occupier" }[r["Authority"]] || (r["Authority"] || "the owner or occupier");
  const conds = String(r["Conditions"] || "").split(/\n+/).map(x => x.trim()).filter(Boolean);
  const fmt = d => d ? Utilities.formatDate(new Date(d), "Australia/Perth", "d MMMM yyyy") : "";
  let areas = [], excl = []; try { areas = JSON.parse(r["Permitted Areas"] || "[]"); } catch (e) { } try { excl = JSON.parse(r["Exclusion Areas"] || "[]"); } catch (e) { }
  const body = [
    "## Details",
    "Land: " + (r["Property Address"] || job["Site Address"] || ""),
    "Landholder: " + r["Landholder Name"] + ", " + authority,
    "Client: " + (client["Name"] || job["Client Name"] || ""),
    "Purpose: " + (r["Purpose"] || "Culling, euthanasia or other humane destruction of pest animals") + (r["Species"] ? ", " + r["Species"] : ""),
    "Period: " + fmt(r["Valid From"]) + (r["Valid To"] ? " to " + fmt(r["Valid To"]) : " until revoked"),
    "Permission holder: Terana Environmental Pty Ltd and the licensed shooters it engages",
    r["Carcass Disposal"] ? "Carcass disposal: " + r["Carcass Disposal"] : "",
    "",
    "## Permission",
    "I, " + r["Landholder Name"] + ", confirm that I am " + authority + " of the land described above and that I am authorised to give this permission.",
    "",
    "I give Terana Environmental Pty Ltd and the licensed shooters it engages permission to enter the land and to use firearms on it for the purpose stated above, during the period stated above, within the permitted areas shown on the map" + (conds.length ? " and subject to the conditions below." : "."),
    "",
    "I may revoke this permission at any time by written notice to Terana Environmental, including by email or text message.",
    conds.length ? "\n## Conditions\n" + conds.map(c => "- " + c).join("\n") : "",
    "",
    "## Permitted areas",
    (areas.length ? "Permitted: " + areas.map((a, i) => a.name || ("Area " + (i + 1))).join(", ") + ". " : "") + (excl.length ? "Excluded: " + excl.map((a, i) => a.name || ("Exclusion " + (i + 1))).join(", ") + "." : "")
  ].filter(x => x !== null).join("\n");
  return body;
}

// The shooting permission as a section inside a signed letter (same wording as the standalone permission PDF).
function permissionSectionHtml(r, job, client) {
  const esc = x => String(x == null ? "" : x).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fmtAU = d => d ? Utilities.formatDate(new Date(d), "Australia/Perth", "d MMMM yyyy") : "";
  const authority = { owner: "the owner", occupier: "the occupier", representative: "an authorised representative of the owner or occupier" }[r["Authority"]] || (r["Authority"] || "the owner or occupier");
  const conds = String(r["Conditions"] || "").split(/\n+/).map(x => x.trim()).filter(Boolean);
  let areas = [], excl = []; try { areas = JSON.parse(r["Permitted Areas"] || "[]"); } catch (e) { } try { excl = JSON.parse(r["Exclusion Areas"] || "[]"); } catch (e) { }
  const mapImg = fileDataUri(r["Map File ID"]);
  return `<div class="permsec"><h1>Permission to use firearms for pest animal control</h1>
  <table class="facts">
    <tr><td>Land</td><td>${esc(r["Property Address"] || job["Site Address"] || "")}</td></tr>
    <tr><td>Landholder</td><td>${esc(r["Landholder Name"])}, ${esc(authority)}</td></tr>
    <tr><td>Purpose</td><td>${esc(r["Purpose"] || "Culling, euthanasia or other humane destruction of pest animals")}${r["Species"] ? ", " + esc(r["Species"]) : ""}</td></tr>
    <tr><td>Period</td><td>${esc(fmtAU(r["Valid From"]))}${r["Valid To"] ? " to " + esc(fmtAU(r["Valid To"])) : " until revoked"}</td></tr>
    <tr><td>Permission holder</td><td>Terana Environmental Pty Ltd and the licensed shooters it engages</td></tr>
    <tr><td>Carcass disposal</td><td>${esc(r["Carcass Disposal"] || "")}</td></tr>
  </table>
  <p>I, ${esc(r["Landholder Name"])}, confirm that I am ${esc(authority)} of the land described above and that I am authorised to give this permission.</p>
  <p>I give Terana Environmental Pty Ltd and the licensed shooters it engages permission to enter the land and to use firearms on it for the purpose stated above, during the period stated above, within the permitted areas shown on the map${conds.length ? " and subject to the conditions below" : ""}.</p>
  <p>I may revoke this permission at any time by written notice to Terana Environmental, including by email or text message.</p>
  ${conds.length ? `<h2>Conditions</h2><ol>${conds.map(c => `<li>${esc(c)}</li>`).join("")}</ol>` : ""}
  <h2>Permitted areas</h2>
  ${mapImg ? `<div class="map"><img src="${mapImg}"></div>` : "<p>No map attached.</p>"}
  <p class="legend">${areas.length ? "Permitted: " + esc(areas.map((a, i) => a.name || ("Area " + (i + 1))).join(", ")) + ". " : ""}${excl.length ? "Excluded: " + esc(excl.map((a, i) => a.name || ("Exclusion " + (i + 1))).join(", ")) + "." : ""}</p>
  <p class="legend">Terana Environmental holds a Professional Shooter Business Licence under the Firearms Act 2024 (WA). Records of each shooting activity are kept for five years as required by regulation 81. The signature at the end of this document applies to this permission.</p></div>`;
}


/* ============================================================
   CULL REGISTER: one row per species per Job log entry, so the
   year's totals by species, client and place add up in the hub.
   ============================================================ */
const CULL_TAB_NAME = "Cull Register";
const CULL_HEADERS = ["Date", "Species", "Count", "Method", "Job ID", "Job Title", "Client", "Site", "Locality", "Latitude", "Longitude", "Technician", "Reason", "Submission ID", "Recorded"];
function recordCulls(v) {
  const culls = Array.isArray(v.culls) ? v.culls.filter(c => c && c.species && Number(c.count) > 0) : [];
  if (!culls.length) return;
  const sheet = getOrCreateSheet(CULL_TAB_NAME, CULL_HEADERS);
  // Retried offline submissions resend the same Submission ID: don't double count.
  if (v.submissionId && findRowNumberByKey(sheet, CULL_HEADERS, "Submission ID", v.submissionId)) return;
  const job = v.jobId ? (readTable(JOBS_TAB_NAME, JOBS_HEADERS).find(j => j["Job ID"] === v.jobId) || {}) : {};
  const gps = String(v.gpsPoint || "").match(/(-?\d+\.\d+)[, ]+(-?\d+\.\d+)/);
  const lat = gps ? gps[1] : (job["Latitude"] || ""), lng = gps ? gps[2] : (job["Longitude"] || "");
  const locality = (String(job["Site Address"] || v.siteClient || "").match(/,\s*([^,0-9]+?)\s*(WA|Western Australia)?\s*\d{0,4}\s*$/i) || [])[1] || "";
  const rows = culls.map(c => [v.date || Utilities.formatDate(new Date(), "Australia/Perth", "yyyy-MM-dd"), c.species, Number(c.count), c.method || "", v.jobId || "", v.jobTitle || job["Title"] || "", job["Client Name"] || v.siteClient || "", job["Site Address"] || v.siteClient || "", locality.trim(), lat, lng, v.technician || "", v.cullReason || "", v.submissionId || "", new Date()]);
  sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, CULL_HEADERS.length).setValues(rows);
}


/* ============================================================
   TIDY WORDING: sends a block of the user's own field notes to
   Claude and returns a cleaned version for them to check. Facts,
   numbers, species, dates and names are to stay as written.
   ============================================================ */
const TEMPLATES_TAB_NAME = "Report Templates";
const TEMPLATES_HEADERS = ["Service", "Section", "Example", "Notes"];
const TEMPLATE_SEED = [
  ["Any", "Summary", "Terana attended the site on the dates below to carry out a feral pigeon reduction program in the main storage shed. Numbers were reduced from an estimated 60 birds to fewer than 10, and the remaining birds have dispersed. Proofing of the eastern eave gaps is recommended to prevent re-establishment.", "Two or three sentences: what was done, the result in numbers, the one thing the client should do next."],
  ["Any", "Work carried out", "14 October 2026, 7.30 pm to 11.00 pm. Night shoot of the main shed and adjoining lean-to using a suppressed .22 air rifle. 38 feral pigeons culled and removed from site. Spent pellets collected. Roosting ledges on the eastern wall were cleared of nesting material and treated with a disinfectant spray. Site left clean and secure.", "One paragraph per visit, in date order. Date and times first, then method, then counts, then clean up. Past tense, third person, no opinions here."],
  ["Any", "Observations", "Nesting material was concentrated along the eastern eave, where a 40 mm gap runs the length of the roofline. Fresh droppings under the grain conveyor indicate the birds are feeding on spillage. No evidence of rodent activity was found. A pair of welcome swallows is nesting above the office door and was left undisturbed.", "What was seen that matters: entry points, food sources, non-target species, hazards. Specific places and measurements."],
  ["Any", "Recommendations", "1. Seal the eastern eave gap with galvanised mesh or flashing before the next breeding season.\n2. Sweep spilt grain from under the conveyor daily; this is the main food source.\n3. A follow-up visit in four weeks to cull any returning birds and confirm proofing is holding.", "Numbered, most important first. Each one is an action the client can do or book. Say why in half a sentence where it helps."],
  ["Rabbit control", "Work carried out", "Pre-feeding of plain oats along the creek line and home paddock warrens was carried out on 2 and 5 October to establish uptake. Oats were taken at all 14 warrens. On 9 October, 1080 oat bait was laid by hand at the same stations in line with the label and the Code of Practice. Warning signs were placed at all property entries. Carcass searches were done on 11 and 13 October.", "Pre-feed, bait, signage, carcass search, in order, with dates and station counts."],
  ["Fox control", "Work carried out", "Six soft-jaw foot-hold traps were set along the northern fence line and creek crossing on 3 October and checked each morning before 8 am. Two adult foxes were trapped and humanely euthanised by firearm on 4 and 6 October. Traps were lifted on 8 October.", "Trap type, number, locations, check times, outcomes per day, traps lifted."],
  ["Any", "Letter", "Terana Environmental confirms its engagement to carry out the work below. Fees are set out in the schedule. Work outside this scope will be quoted before it starts.", "Plain, direct, no legal padding. Short paragraphs."]
];
function templateFor(service, section) {
  const rows = readTable(TEMPLATES_TAB_NAME, TEMPLATES_HEADERS);
  const sec = String(section || "").toLowerCase();
  const match = rows.find(r => String(r["Service"]).toLowerCase() === String(service || "").toLowerCase() && String(r["Section"]).toLowerCase() === sec)
    || rows.find(r => /^any$/i.test(String(r["Service"])) && String(r["Section"]).toLowerCase() === sec);
  return match || null;
}
function hubTidyText(text, kind, session, service, section) {
  const key = getSettings()["Anthropic API Key"];
  if (!key) return jsonResponse({ status: "error", message: "No API key. Paste one into the Settings tab, row Anthropic API Key." });
  text = String(text || "").trim();
  if (!text) return jsonResponse({ status: "error", message: "Nothing to tidy." });
  if (text.length > 12000) return jsonResponse({ status: "error", message: "That block is too long. Tidy it in parts." });
  const system = "You tidy field notes written by an Australian pest and wildlife management technician so they read well in a client report or letter. " +
    "Fix spelling, grammar, punctuation and sentence flow. Use plain Australian English, third person where the notes already are, sentence case. " +
    "Keep every fact exactly: numbers, counts, species, product names, dates, times, places, people, measurements. Do not add facts, opinions, recommendations or filler. Do not remove information. " +
    "Keep the same structure: if the input has headings, bullets or lines starting with ? or ##, keep those markers and their order. Keep it about the same length. " +
    "Never use em dashes or en dashes; use commas or full stops. Return only the tidied text, no preamble, no quotes." + (kind ? " This text is a " + kind + "." : "");
  const tpl = templateFor(service, section);
  const styleNote = tpl ? "\n\nMatch the tone, structure and level of detail of this example from Terana's own reports (the facts in it are unrelated to the current job, use only its style):\n---\n" + tpl["Example"] + "\n---" + (tpl["Notes"] ? "\nHouse rules for this section: " + tpl["Notes"] : "") : "";
  try {
    const res = UrlFetchApp.fetch("https://api.anthropic.com/v1/messages", {
      method: "post", contentType: "application/json", muteHttpExceptions: true,
      headers: { "x-api-key": key, "anthropic-version": "2023-06-01" },
      payload: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 2000, system: system + styleNote, messages: [{ role: "user", content: text }] })
    });
    const code = res.getResponseCode(); const body = JSON.parse(res.getContentText() || "{}");
    if (code !== 200) return jsonResponse({ status: "error", message: "Tidy failed (" + code + "): " + ((body.error && body.error.message) || "check the API key and credit") });
    const out = (body.content || []).filter(c => c.type === "text").map(c => c.text).join("").trim();
    if (!out) return jsonResponse({ status: "error", message: "Empty reply from the model." });
    return jsonResponse({ status: "success", text: out });
  } catch (e) { return jsonResponse({ status: "error", message: "Tidy failed: " + e.message }); }
}
