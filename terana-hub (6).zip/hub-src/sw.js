/**
 * Service worker for Terana Hub and the field tools.
 * Caches the app shell on first load so the form keeps working
 * offline, even after the browser is fully closed and reopened.
 *
 * Bump CACHE_NAME when you change any cached file so old caches
 * get cleared out and the new version loads.
 */
const CACHE_NAME = "terana-hub-v40";
const PRECACHE_URLS = [
  "./field-report.html",
  "./pest-report.html",
  "./firearm-log.html",
  "./index.html",
  "./sign.html",
  "./emergency-plan.html",
  "./hub.css",
  "./hub.js",
  "./logo.png",
  "./work-sans-400.woff",
  "./work-sans-600.woff",
  "./vendor/leaflet/leaflet.js",
  "./vendor/leaflet/leaflet.css",
  "./vendor/qrcode.js",
  "./terana-logo.png",
  "./manifest.webmanifest",
  "./icon-192.png",
  "./icon-512.png",
  "./icon-512-maskable.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;

  // Never intercept non-GET requests — this lets Sheet submissions
  // (POST to the Apps Script URL) go straight to the network as normal,
  // so the page's own offline-queue logic handles failures correctly.
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  if (url.origin === self.location.origin && /\/sign\.html$/.test(url.pathname)) {
    // Signing page: always fresh when online (clients open it from an email link).
    event.respondWith(fetch(req).then((res) => { if (res && res.status === 200) { const c = res.clone(); caches.open(CACHE_NAME).then((cache) => cache.put(req, c)); } return res; }).catch(() => caches.match(req)));
    return;
  }
  if (url.origin === self.location.origin && req.mode === "navigate") {
    // A page navigation inside the hub: if the path doesn't exist (a bad link), land on the hub instead of a dead Netlify 404 page.
    event.respondWith(fetch(req).then((res) => res.status === 404 ? (caches.match("./index.html").then((c) => c || res)) : res).catch(() => caches.match(req).then((c) => c || caches.match("./index.html"))));
    return;
  }
  if (url.origin === self.location.origin) {
    // App shell: serve from cache instantly if we have it (works offline),
    // and refresh the cache in the background when online.
    event.respondWith(
      caches.match(req).then((cached) => {
        const networkFetch = fetch(req)
          .then((res) => {
            if (res && res.status === 200) {
              const resClone = res.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
            }
            return res;
          })
          .catch(() => cached);
        return cached || networkFetch;
      })
    );
  } else if (url.hostname.endsWith("openstreetmap.org") || url.hostname.endsWith("komoot.io") || url.hostname.endsWith("arcgisonline.com")) {
    // Map tiles and address lookups: network only, never cached, or the
    // cache would fill with map images.
    return;
  } else {
    // Cross-origin (Google Fonts etc.): prefer fresh network, fall back
    // to whatever was cached before if there's no connection.
    event.respondWith(
      fetch(req)
        .then((res) => {
          const resClone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
          return res;
        })
        .catch(() => caches.match(req))
    );
  }
});
