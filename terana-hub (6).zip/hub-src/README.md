# Terana Environmental, Field Tools and Hub

A small static, installable (PWA) site. `index.html` is Terana Hub (staff login, dashboard, jobs, clients, job map) and it links to three mobile-first field tools used by field crews to log survey observations, GPS points, photos, pesticide/trapping activity, and firearm movements: including while working with limited or no signal.

## Key technologies

- Plain HTML, CSS, and vanilla JavaScript: no framework or build step.
- Google Apps Script Web App as the shared backend: form submissions are sent via `fetch` directly to a single Google Apps Script endpoint that routes by form type and writes rows into the appropriate tab of a shared Google Sheet.
- On-device IndexedDB queueing so entries submitted while offline (including photo attachments) are saved and retried once connectivity returns.
- A web app manifest and service worker so the site can be installed and keeps working offline after first load.

## Structure

- `index.html`: landing page linking to the three field tools.
- `field-report.html`: Fox Den Survey form, including the offline queue and sync logic.
- `pest-report.html`: Pest Management Report (quick log and full flow).
- `firearm-log.html`: Firearm Log (withdrawal/return and shooting activity).
- `terana-logo.png`: brand logo shown in the header of every page.
- `manifest.webmanifest`, `sw.js`, `icon-*.png`: PWA install/offline support.
- `AppsScript-Code.gs`: source for the shared Google Apps Script backend (pasted into the Sheet's Apps Script editor manually; not deployed by Netlify).
- `SETUP_INSTRUCTIONS.md`: setup and verification steps for the Sheet, Apps Script deployment, and reference data tabs.

## Running locally

Because this is a static site with no server-side code, it can be opened directly in a browser, or served locally with any static file server, e.g.:

```bash
npx serve .
```

Then visit `http://localhost:3000` (or the port shown) to view the site.
